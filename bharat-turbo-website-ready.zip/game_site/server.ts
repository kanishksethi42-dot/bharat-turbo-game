import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import type { RawData } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const SHARD_SOFT_CAP = 250;
const AOI_CELL_SIZE = 150;
const MAX_PEERS_PER_PLAYER = 48;

interface CharacterNetConfig {
  archetype: string;
  outfitColor: string;
  skinTone: string;
  headgear: string;
  eyewear: string;
}

interface PlayerNetState {
  id: string;
  name: string;
  shardId: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  speed: number;
  vehicleId: string;
  vehicleColor: string;
  onFoot: boolean;
  wantedLevel: number;
  characterConfig: CharacterNetConfig;
  lastSeen: number;
}

interface ClientSession {
  ws: WebSocket;
  player: PlayerNetState;
}

interface ShardDefinition {
  baseId: string;
  label: string;
  district: string;
  region: string;
}

const SHARD_CATALOG: ShardDefinition[] = [
  { baseId: 'IN-GLOBAL', label: 'All 50 Rajasthan Districts', district: 'jaipur', region: 'Rajasthan State' },
  { baseId: 'IN-WEST', label: 'Thar Desert · Jaisalmer & Jodhpur', district: 'jaisalmer', region: 'Marwar West' },
  { baseId: 'IN-NORTH', label: 'Bikaner · Sikar & Alwar Corridor', district: 'bikaner', region: 'Shekhawati North' },
  { baseId: 'IN-PINK', label: 'Jaipur Pink City & Ajmer HQ', district: 'jaipur', region: 'Central Capital' },
  { baseId: 'IN-SOUTH', label: 'Udaipur Lake Pichola & Kota Chambal', district: 'udaipur', region: 'Mewar & Hadoti' },
];

// Active shards map: shardId -> Map<playerId, ClientSession>
const shards = new Map<string, Map<string, ClientSession>>();
for (const def of SHARD_CATALOG) {
  shards.set(`${def.baseId}-01`, new Map());
}

function getOrAssignShard(requestedBaseOrFull: string): string {
  // Exact match if under soft cap
  if (shards.has(requestedBaseOrFull)) {
    const map = shards.get(requestedBaseOrFull)!;
    if (map.size < SHARD_SOFT_CAP) {
      return requestedBaseOrFull;
    }
  }
  const baseId = requestedBaseOrFull.replace(/-\d+$/, '');
  for (let i = 1; i <= 64; i++) {
    const candidate = `${baseId}-${String(i).padStart(2, '0')}`;
    let map = shards.get(candidate);
    if (!map) {
      map = new Map();
      shards.set(candidate, map);
      return candidate;
    }
    if (map.size < SHARD_SOFT_CAP) {
      return candidate;
    }
  }
  const fallback = `${baseId}-01`;
  if (!shards.has(fallback)) shards.set(fallback, new Map());
  return fallback;
}

function getTotalConcurrentPlayers(): number {
  let total = 0;
  for (const map of shards.values()) {
    total += map.size;
  }
  return total;
}

function getLobbySummaries() {
  const list: Array<{
    shardId: string;
    baseId: string;
    label: string;
    district: string;
    region: string;
    players: number;
    capacity: number;
  }> = [];

  for (const [shardId, map] of shards.entries()) {
    const baseId = shardId.replace(/-\d+$/, '');
    const def = SHARD_CATALOG.find((d) => d.baseId === baseId) ?? SHARD_CATALOG[0];
    list.push({
      shardId,
      baseId,
      label: def.label,
      district: def.district,
      region: def.region,
      players: map.size,
      capacity: SHARD_SOFT_CAP,
    });
  }
  return list;
}

function cellKey(x: number, z: number): string {
  const cx = Math.floor(x / AOI_CELL_SIZE);
  const cz = Math.floor(z / AOI_CELL_SIZE);
  return `${cx}:${cz}`;
}

function broadcastShardSnapshots(): void {
  const now = Date.now();
  for (const [shardId, sessions] of shards.entries()) {
    if (sessions.size === 0) continue;

    // Spatial hash bucket per shard for O(N) AOI lookup even at high density
    const grid = new Map<string, PlayerNetState[]>();
    for (const [pid, session] of sessions.entries()) {
      if (now - session.player.lastSeen > 30000 || session.ws.readyState !== WebSocket.OPEN) {
        sessions.delete(pid);
        continue;
      }
      const key = cellKey(session.player.x, session.player.z);
      let bucket = grid.get(key);
      if (!bucket) {
        bucket = [];
        grid.set(key, bucket);
      }
      bucket.push(session.player);
    }

    if (sessions.size === 0) continue;

    for (const session of sessions.values()) {
      if (session.ws.readyState !== WebSocket.OPEN) continue;
      const p = session.player;
      const cx = Math.floor(p.x / AOI_CELL_SIZE);
      const cz = Math.floor(p.z / AOI_CELL_SIZE);

      const nearby: PlayerNetState[] = [];
      for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          const bucket = grid.get(`${cx + dx}:${cz + dz}`);
          if (!bucket) continue;
          for (const other of bucket) {
            if (other.id !== p.id) {
              nearby.push(other);
            }
          }
        }
      }

      // Sort by squared distance and cap peers for stable mobile/desktop frame rate
      if (nearby.length > MAX_PEERS_PER_PLAYER) {
        nearby.sort((a, b) => {
          const da = (a.x - p.x) ** 2 + (a.z - p.z) ** 2;
          const db = (b.x - p.x) ** 2 + (b.z - p.z) ** 2;
          return da - db;
        });
        nearby.length = MAX_PEERS_PER_PLAYER;
      }

      session.ws.send(
        JSON.stringify({
          type: 'shard:state',
          shardId,
          shardPlayers: sessions.size,
          totalConcurrent: getTotalConcurrentPlayers(),
          peers: nearby.map((n) => ({
            id: n.id,
            name: n.name,
            x: Math.round(n.x * 100) / 100,
            y: Math.round(n.y * 100) / 100,
            z: Math.round(n.z * 100) / 100,
            yaw: Math.round(n.yaw * 1000) / 1000,
            speed: Math.round(n.speed),
            vehicleId: n.vehicleId,
            vehicleColor: n.vehicleColor,
            onFoot: n.onFoot,
            wantedLevel: n.wantedLevel,
            characterConfig: n.characterConfig,
          })),
        }),
      );
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      totalConcurrentPlayers: getTotalConcurrentPlayers(),
      activeShards: shards.size,
    });
  });

  app.get('/api/lobbies', (_req, res) => {
    res.json({
      totalConcurrentPlayers: getTotalConcurrentPlayers(),
      maxPerShard: SHARD_SOFT_CAP,
      lobbies: getLobbySummaries(),
    });
  });

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    let currentSession: ClientSession | null = null;

    ws.on('message', (raw: RawData) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString()) as Record<string, unknown>;
      } catch {
        return;
      }

      const type = String(msg.type || '');

      if (type === 'lobby:join') {
        const playerId = String(msg.playerId || `drv_${Math.random().toString(36).slice(2, 10)}`).slice(0, 64);
        const name = String(msg.name || 'Driver').slice(0, 32);
        const requestedShard = String(msg.shardId || 'IN-GLOBAL-01').slice(0, 32);
        const assignedShard = getOrAssignShard(requestedShard);

        // Leave previous shard if switching
        if (currentSession) {
          const prevMap = shards.get(currentSession.player.shardId);
          prevMap?.delete(currentSession.player.id);
        }

        const charCfg = (msg.characterConfig as CharacterNetConfig | undefined) ?? {
          archetype: 'racer',
          outfitColor: '#f59e0b',
          skinTone: '#c68642',
          headgear: 'fade',
          eyewear: 'aviators',
        };

        const player: PlayerNetState = {
          id: playerId,
          name,
          shardId: assignedShard,
          x: Number(msg.x) || -210,
          y: Number(msg.y) || 0,
          z: Number(msg.z) || 210,
          yaw: Number(msg.yaw) || 0,
          speed: 0,
          vehicleId: String(msg.vehicleId || 'ferrari_sf90').slice(0, 32),
          vehicleColor: String(msg.vehicleColor || '#dc2626').slice(0, 16),
          onFoot: Boolean(msg.onFoot),
          wantedLevel: Number(msg.wantedLevel) || 0,
          characterConfig: charCfg,
          lastSeen: Date.now(),
        };

        currentSession = { ws, player };
        shards.get(assignedShard)!.set(playerId, currentSession);

        ws.send(
          JSON.stringify({
            type: 'lobby:joined',
            playerId,
            shardId: assignedShard,
            shardPlayers: shards.get(assignedShard)!.size,
            totalConcurrent: getTotalConcurrentPlayers(),
          }),
        );
        return;
      }

      if (!currentSession) return;
      currentSession.player.lastSeen = Date.now();

      if (type === 'player:update') {
        const p = currentSession.player;
        if (typeof msg.x === 'number') p.x = msg.x;
        if (typeof msg.y === 'number') p.y = msg.y;
        if (typeof msg.z === 'number') p.z = msg.z;
        if (typeof msg.yaw === 'number') p.yaw = msg.yaw;
        if (typeof msg.speed === 'number') p.speed = msg.speed;
        if (typeof msg.vehicleId === 'string') p.vehicleId = msg.vehicleId.slice(0, 32);
        if (typeof msg.vehicleColor === 'string') p.vehicleColor = msg.vehicleColor.slice(0, 16);
        if (typeof msg.onFoot === 'boolean') p.onFoot = msg.onFoot;
        if (typeof msg.wantedLevel === 'number') p.wantedLevel = msg.wantedLevel;
        if (typeof msg.name === 'string') p.name = msg.name.slice(0, 32);
        if (msg.characterConfig && typeof msg.characterConfig === 'object') {
          p.characterConfig = msg.characterConfig as CharacterNetConfig;
        }
        return;
      }

      if (type === 'chat:send') {
        const text = String(msg.text || '').trim().slice(0, 160);
        if (!text) return;
        const shardMap = shards.get(currentSession.player.shardId);
        if (!shardMap) return;
        const payload = JSON.stringify({
          type: 'chat:message',
          id: `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          senderId: currentSession.player.id,
          senderName: currentSession.player.name,
          text,
          timestamp: Date.now(),
        });
        for (const peer of shardMap.values()) {
          if (peer.ws.readyState === WebSocket.OPEN) {
            peer.ws.send(payload);
          }
        }
        return;
      }

      if (type === 'prop:smash') {
        const propId = Number(msg.propId);
        if (!Number.isFinite(propId)) return;
        const shardMap = shards.get(currentSession.player.shardId);
        if (!shardMap) return;
        const payload = JSON.stringify({
          type: 'prop:smashed',
          propId,
          vx: Number(msg.vx) || 0,
          vz: Number(msg.vz) || 0,
        });
        for (const peer of shardMap.values()) {
          if (peer.ws.readyState === WebSocket.OPEN && peer.player.id !== currentSession.player.id) {
            peer.ws.send(payload);
          }
        }
      }
    });

    ws.on('close', () => {
      if (currentSession) {
        const shardMap = shards.get(currentSession.player.shardId);
        shardMap?.delete(currentSession.player.id);
        currentSession = null;
      }
    });
  });

  // 15 Hz server-authoritative spatial snapshot broadcast
  setInterval(broadcastShardSnapshots, 66);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Bharat Turbo server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
