# Bharat Turbo — Open-World India 3D

This project includes the original React + Three.js game, its landing/title screen, gameplay HUD, local save system, and a Node server for multiplayer WebSocket sessions. The landing screen already includes the **Enter Jaipur Roam** button, which launches the game in the same page.

## Run locally

Requirements: Node.js 22 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed in the terminal (usually `http://localhost:3000`).

## Production build

```bash
npm install
npm run build
npm start
```

The Express server serves the built website and the multiplayer WebSocket endpoint at `/ws`. The health endpoint is `/api/health`.

## Deploy online (Render)

1. Create a GitHub repository and upload the contents of this project.
2. In Render, create a **New Web Service** and connect that repository.
3. Render can use the included `render.yaml`; otherwise set:
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
   - Health check path: `/api/health`
4. Deploy. Render will provide a public HTTPS website URL.

The server uses the same origin for the website, API, and WebSocket multiplayer connection, so deploy it as a persistent Node web service rather than a static-only site.

## Optional Firebase features

The game can save progress locally in the browser. Google sign-in and cloud saves depend on the Firebase project configuration and its Authentication / Firestore rules being enabled and correctly configured. Add the deployed domain to Firebase Authentication's authorised domains before enabling Google sign-in. Never put private service-account credentials in frontend files.

## Notes

- The game is rendered in the browser using WebGL / Three.js. A modern desktop or mobile browser with WebGL support is recommended.
- The first load may take a little time while assets and the 3D world initialise.
- Multiplayer requires the deployed Node server to remain running; it will not work on static-only hosting.
