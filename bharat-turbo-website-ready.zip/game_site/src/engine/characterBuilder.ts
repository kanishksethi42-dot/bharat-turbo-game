import * as THREE from 'three';
import type { CharacterConfig, WeaponId } from '../types/game';
import type { ProceduralTexturePack } from './proceduralTextures';

export interface CharacterRig {
  root: THREE.Group;
  torso: THREE.Group;
  headGroup: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  muzzleFlash: THREE.Mesh;
  updateConfig: (cfg: CharacterConfig) => void;
  setWeapon: (weaponId: WeaponId) => void;
  triggerMuzzleFlash: () => void;
  animateWalk: (speed: number, time: number, airborne: boolean, aiming?: boolean) => void;
}

export function buildCharacterModel(
  initialConfig: CharacterConfig,
  textures: ProceduralTexturePack,
): CharacterRig {
  const root = new THREE.Group();

  // Contact shadow at ground y=0.02
  const shadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.15, 1.15),
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      depthWrite: false,
      opacity: 0.48,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;
  root.add(shadow);

  const outfitMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialConfig.outfitColor),
    roughness: 0.62,
    metalness: 0.12,
  });

  const pantsMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.78,
    metalness: 0.05,
  });

  const skinMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialConfig.skinTone),
    roughness: 0.58,
    metalness: 0.02,
  });

  const accentMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.35,
    metalness: 0.45,
  });

  const visorMat = new THREE.MeshStandardMaterial({
    color: 0x0ea5e9,
    emissive: 0x0284c7,
    emissiveIntensity: 0.65,
    roughness: 0.12,
    metalness: 0.88,
  });

  // Legs (pivot at hip y = 0.85)
  const makeLeg = (xOffset: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(xOffset, 0.85, 0);
    const upper = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.72, 0.24), pantsMat);
    upper.position.y = -0.36;
    upper.castShadow = true;
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.34), accentMat);
    shoe.position.set(0, -0.78, -0.04);
    shoe.castShadow = true;
    legPivot.add(upper, shoe);
    return legPivot;
  };

  const leftLeg = makeLeg(-0.15);
  const rightLeg = makeLeg(0.15);
  root.add(leftLeg, rightLeg);

  // Torso group
  const torso = new THREE.Group();
  torso.position.set(0, 0.88, 0);

  const jacket = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.66, 0.32), outfitMat);
  jacket.position.y = 0.33;
  jacket.castShadow = true;
  torso.add(jacket);

  const trim = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.56, 0.34), accentMat);
  trim.position.set(0, 0.33, 0);
  torso.add(trim);

  const royalSash = new THREE.Mesh(
    new THREE.BoxGeometry(0.6, 0.18, 0.35),
    new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.32,
      metalness: 0.68,
    }),
  );
  royalSash.position.set(0, 0.08, 0);
  torso.add(royalSash);

  const cyberPack = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.44, 0.14), visorMat);
  cyberPack.position.set(0, 0.36, 0.2);
  torso.add(cyberPack);

  // Arms (pivot at shoulder)
  const makeArm = (xOffset: number) => {
    const armPivot = new THREE.Group();
    armPivot.position.set(xOffset, 0.6, 0);
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.52, 0.2), outfitMat);
    sleeve.position.y = -0.24;
    sleeve.castShadow = true;
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 10), skinMat);
    hand.position.y = -0.54;
    armPivot.add(sleeve, hand);
    return armPivot;
  };
  const leftArm = makeArm(-0.39);
  const rightArm = makeArm(0.39);

  // 3D Composite Weapon Models attached to Right Hand
  const weaponMount = new THREE.Group();
  weaponMount.position.set(0, -0.54, -0.08);
  const gunSteelMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.28 });
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.72, metalness: 0.08 });
  const rpgGreenMat = new THREE.MeshStandardMaterial({ color: 0x365314, roughness: 0.55, metalness: 0.25 });

  const pistolGroup = new THREE.Group();
  const pSlide = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, 0.28), gunSteelMat);
  pSlide.position.set(0, 0.02, -0.1);
  const pGrip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.14, 0.07), gunSteelMat);
  pGrip.position.set(0, -0.06, 0);
  pistolGroup.add(pSlide, pGrip);

  const smgGroup = new THREE.Group();
  const smgBody = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.11, 0.42), gunSteelMat);
  smgBody.position.set(0, 0.02, -0.16);
  const smgMag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.18, 0.06), gunSteelMat);
  smgMag.position.set(0, -0.1, -0.2);
  smgMag.rotation.x = 0.25;
  smgGroup.add(smgBody, smgMag);

  const shotgunGroup = new THREE.Group();
  const sgBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.03, 0.64, 8), gunSteelMat);
  sgBarrel.rotation.x = Math.PI / 2;
  sgBarrel.position.set(0, 0.03, -0.26);
  const sgStock = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.28), woodMat);
  sgStock.position.set(0, 0.0, 0.06);
  shotgunGroup.add(sgBarrel, sgStock);

  const akGroup = new THREE.Group();
  const akBody = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.52), gunSteelMat);
  akBody.position.set(0, 0.02, -0.2);
  const akBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 0.34, 8), gunSteelMat);
  akBarrel.rotation.x = Math.PI / 2;
  akBarrel.position.set(0, 0.04, -0.58);
  const akMag = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.2, 0.07), woodMat);
  akMag.position.set(0, -0.1, -0.22);
  akMag.rotation.x = 0.32;
  const akStock = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.1, 0.24), woodMat);
  akStock.position.set(0, 0, 0.12);
  akGroup.add(akBody, akBarrel, akMag, akStock);

  const rpgGroup = new THREE.Group();
  const rpgTube = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 1.05, 10), rpgGreenMat);
  rpgTube.rotation.x = Math.PI / 2;
  rpgTube.position.set(0, 0.08, -0.18);
  const rpgWarhead = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.24, 10), woodMat);
  rpgWarhead.rotation.x = -Math.PI / 2;
  rpgWarhead.position.set(0, 0.08, -0.76);
  rpgGroup.add(rpgTube, rpgWarhead);

  const muzzleFlash = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 6, 6),
    new THREE.MeshBasicMaterial({ color: 0xfef08a }),
  );
  muzzleFlash.position.set(0, 0.03, -0.55);
  muzzleFlash.visible = false;

  weaponMount.add(pistolGroup, smgGroup, shotgunGroup, akGroup, rpgGroup, muzzleFlash);
  rightArm.add(weaponMount);
  torso.add(leftArm, rightArm);

  // Head + customizable headgear + eyewear
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.72, 0);

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.36, 0.34), skinMat);
  head.position.y = 0.18;
  head.castShadow = true;
  headGroup.add(head);

  const hairFade = new THREE.Mesh(
    new THREE.BoxGeometry(0.36, 0.14, 0.36),
    new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.85,
    }),
  );
  hairFade.position.set(0, 0.36, 0.02);

  const helmetGroup = new THREE.Group();
  const helmetShell = new THREE.Mesh(new THREE.SphereGeometry(0.24, 16, 14), accentMat);
  helmetShell.position.set(0, 0.21, 0);
  const helmetGlass = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.14, 0.22), visorMat);
  helmetGlass.position.set(0, 0.22, -0.15);
  helmetGroup.add(helmetShell, helmetGlass);

  const turbanGroup = new THREE.Group();
  const turbanBase = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.09, 10, 18), outfitMat);
  turbanBase.rotation.x = Math.PI / 2;
  turbanBase.position.set(0, 0.34, 0);
  const turbanTop = new THREE.Mesh(
    new THREE.SphereGeometry(0.2, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55),
    outfitMat,
  );
  turbanTop.position.set(0, 0.31, 0);
  turbanGroup.add(turbanBase, turbanTop);

  const capGroup = new THREE.Group();
  const capCrown = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.14, 0.36), outfitMat);
  capCrown.position.set(0, 0.36, 0);
  const capBrim = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.04, 0.2), accentMat);
  capBrim.position.set(0, 0.31, -0.22);
  capGroup.add(capCrown, capBrim);

  headGroup.add(hairFade, helmetGroup, turbanGroup, capGroup);

  const aviators = new THREE.Mesh(
    new THREE.BoxGeometry(0.32, 0.09, 0.08),
    new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.9,
      roughness: 0.12,
    }),
  );
  aviators.position.set(0, 0.22, -0.18);

  const cyberVisor = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.11, 0.1), visorMat);
  cyberVisor.position.set(0, 0.22, -0.18);

  const bandana = new THREE.Mesh(
    new THREE.BoxGeometry(0.36, 0.13, 0.36),
    new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.75,
    }),
  );
  bandana.position.set(0, 0.09, -0.02);

  headGroup.add(aviators, cyberVisor, bandana);
  torso.add(headGroup);
  root.add(torso);

  let muzzleFlashTimer = 0;

  function updateConfig(cfg: CharacterConfig) {
    outfitMat.color.set(cfg.outfitColor);
    skinMat.color.set(cfg.skinTone);
    pantsMat.color.set(cfg.archetype === 'royal' ? 0xf1f5f9 : cfg.archetype === 'maverick' ? 0x111827 : 0x1e293b);

    royalSash.visible = cfg.archetype === 'royal';
    cyberPack.visible = cfg.archetype === 'cyber';
    trim.visible = cfg.archetype !== 'royal';

    hairFade.visible = cfg.headgear === 'fade';
    helmetGroup.visible = cfg.headgear === 'helmet';
    turbanGroup.visible = cfg.headgear === 'turban';
    capGroup.visible = cfg.headgear === 'cap';

    aviators.visible = cfg.eyewear === 'aviators';
    cyberVisor.visible = cfg.eyewear === 'visor';
    bandana.visible = cfg.eyewear === 'bandana';
  }

  function setWeapon(weaponId: WeaponId) {
    pistolGroup.visible = weaponId === 'pistol';
    smgGroup.visible = weaponId === 'smg';
    shotgunGroup.visible = weaponId === 'shotgun';
    akGroup.visible = weaponId === 'ak47';
    rpgGroup.visible = weaponId === 'rpg';
    muzzleFlash.position.z =
      weaponId === 'pistol'
        ? -0.32
        : weaponId === 'smg'
        ? -0.42
        : weaponId === 'rpg'
        ? -0.82
        : -0.78;
  }

  function triggerMuzzleFlash() {
    muzzleFlashTimer = 0.06;
    muzzleFlash.visible = true;
    muzzleFlash.scale.setScalar(0.85 + Math.random() * 0.55);
  }

  updateConfig(initialConfig);
  setWeapon('pistol');

  function animateWalk(speed: number, time: number, airborne: boolean, aiming = false) {
    if (muzzleFlashTimer > 0) {
      muzzleFlashTimer -= 0.016;
      if (muzzleFlashTimer <= 0) muzzleFlash.visible = false;
    }
    if (airborne) {
      leftLeg.rotation.x = 0.35;
      rightLeg.rotation.x = -0.25;
      leftArm.rotation.x = -0.6;
      rightArm.rotation.x = aiming ? 1.45 : -0.6;
      return;
    }
    const moveRatio = Math.min(1, speed / 9);
    const swing = Math.sin(time * 11) * 0.65 * moveRatio;
    leftLeg.rotation.x = swing;
    rightLeg.rotation.x = -swing;
    leftArm.rotation.x = -swing * 0.85;
    rightArm.rotation.x = aiming ? 1.45 : swing * 0.85;
    torso.position.y = 0.88 + Math.abs(Math.sin(time * 11)) * 0.05 * moveRatio;
  }

  return {
    root,
    torso,
    headGroup,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    muzzleFlash,
    updateConfig,
    setWeapon,
    triggerMuzzleFlash,
    animateWalk,
  };
}
