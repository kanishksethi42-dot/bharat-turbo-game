import * as THREE from 'three';

export interface ProceduralTexturePack {
  asphaltMap: THREE.CanvasTexture;
  asphaltBump: THREE.CanvasTexture;
  asphaltRoughness: THREE.CanvasTexture;
  terrainMap: THREE.CanvasTexture;
  sandstoneMap: THREE.CanvasTexture;
  haveliMap: THREE.CanvasTexture;
  blueCityMap: THREE.CanvasTexture;
  shopSignMap: THREE.CanvasTexture;
  glassTowerMap: THREE.CanvasTexture;
  glassTowerEmissive: THREE.CanvasTexture;
  carbonMap: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  highwaySignNorth: THREE.CanvasTexture;
  highwaySignSouth: THREE.CanvasTexture;
  policeStationSign: THREE.CanvasTexture;
  bankSignMap: THREE.CanvasTexture;
  hospitalSignMap: THREE.CanvasTexture;
  homeSignMap: THREE.CanvasTexture;
  airportSignMap: THREE.CanvasTexture;
  runwayMap: THREE.CanvasTexture;
  dmartSignMap: THREE.CanvasTexture;
  decathlonSignMap: THREE.CanvasTexture;
  ammunationSignMap: THREE.CanvasTexture;
  clothSignMap: THREE.CanvasTexture;
  barberSignMap: THREE.CanvasTexture;
  petrolSignMap: THREE.CanvasTexture;
  paanSignMap: THREE.CanvasTexture;
  grocerySignMap: THREE.CanvasTexture;
  hotelSignMap: THREE.CanvasTexture;
  schoolSignMap: THREE.CanvasTexture;
  officeSignMap: THREE.CanvasTexture;
  fireStationSignMap: THREE.CanvasTexture;
  metroSignMap: THREE.CanvasTexture;
  railSignMap: THREE.CanvasTexture;
  stadiumSignMap: THREE.CanvasTexture;
  jewelrySignMap: THREE.CanvasTexture;
  sweetSignMap: THREE.CanvasTexture;
  electronicsSignMap: THREE.CanvasTexture;
  pharmacySignMap: THREE.CanvasTexture;
  chaiSignMap: THREE.CanvasTexture;
  showroomFerrariSign: THREE.CanvasTexture;
  showroomBugattiSign: THREE.CanvasTexture;
  showroomSuvSign: THREE.CanvasTexture;
  showroomMarutiSign: THREE.CanvasTexture;
  showroomBikeSign: THREE.CanvasTexture;
  dispose: () => void;
}

function makeHighwaySignTexture(
  line1: string,
  line2: string,
  bgHex: string,
  aniso: number,
  borderHex = '#ffffff',
  accentHex = '#fde047',
): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 160;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = bgHex;
  ctx.fillRect(0, 0, 512, 160);
  ctx.strokeStyle = borderHex;
  ctx.lineWidth = 8;
  ctx.strokeRect(10, 10, 492, 140);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 34px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(line1, 256, 68);
  ctx.fillStyle = accentHex;
  ctx.font = 'bold 24px sans-serif';
  ctx.fillText(line2, 256, 118);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = aniso;
  return tex;
}

export function createProceduralTextures(renderer: THREE.WebGLRenderer): ProceduralTexturePack {
  const maxAniso = Math.min(8, renderer.capabilities.getMaxAnisotropy() || 1);

  // 1. High-Frequency Asphalt Road Albedo + Bump + Wetness Roughness
  const asphaltCanvas = document.createElement('canvas');
  asphaltCanvas.width = 512;
  asphaltCanvas.height = 512;
  const actx = asphaltCanvas.getContext('2d')!;
  actx.fillStyle = '#1b1f27';
  actx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 16000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const v = 18 + Math.floor(Math.random() * 34);
    actx.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
    actx.fillRect(x, y, 2, 2);
  }
  actx.fillStyle = 'rgba(8,10,14,0.28)';
  actx.fillRect(72, 0, 52, 512);
  actx.fillRect(156, 0, 52, 512);
  actx.fillRect(304, 0, 52, 512);
  actx.fillRect(388, 0, 52, 512);

  actx.fillStyle = '#f59e0b';
  actx.fillRect(247, 0, 5, 512);
  actx.fillRect(260, 0, 5, 512);

  actx.fillStyle = '#f1f5f9';
  for (let y = 12; y < 512; y += 64) {
    actx.fillRect(126, y, 7, 34);
    actx.fillRect(379, y, 7, 34);
  }
  actx.fillStyle = '#cbd5e1';
  actx.fillRect(16, 0, 8, 512);
  actx.fillRect(488, 0, 8, 512);

  const asphaltMap = new THREE.CanvasTexture(asphaltCanvas);
  asphaltMap.colorSpace = THREE.SRGBColorSpace;
  asphaltMap.wrapS = THREE.RepeatWrapping;
  asphaltMap.wrapT = THREE.RepeatWrapping;
  asphaltMap.anisotropy = maxAniso;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 256;
  bumpCanvas.height = 256;
  const bctx = bumpCanvas.getContext('2d')!;
  bctx.fillStyle = '#808080';
  bctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 9000; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const g = 90 + Math.floor(Math.random() * 90);
    bctx.fillStyle = `rgb(${g},${g},${g})`;
    bctx.fillRect(x, y, 2, 2);
  }
  const asphaltBump = new THREE.CanvasTexture(bumpCanvas);
  asphaltBump.wrapS = THREE.RepeatWrapping;
  asphaltBump.wrapT = THREE.RepeatWrapping;
  asphaltBump.anisotropy = maxAniso;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = 256;
  roughCanvas.height = 256;
  const rctx = roughCanvas.getContext('2d')!;
  rctx.fillStyle = '#dcdce0';
  rctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 4500; i++) {
    const px = Math.random() * 256;
    const py = Math.random() * 256;
    const g = 205 + Math.floor(Math.random() * 42);
    rctx.fillStyle = `rgb(${g},${g},${g})`;
    rctx.fillRect(px, py, 3, 3);
  }
  const asphaltRoughness = new THREE.CanvasTexture(roughCanvas);
  asphaltRoughness.wrapS = THREE.RepeatWrapping;
  asphaltRoughness.wrapT = THREE.RepeatWrapping;
  asphaltRoughness.anisotropy = maxAniso;

  // 2. Rajasthan Golden-Ochre Desert Scrub & Aravalli Earth Ground Map
  const terrainCanvas = document.createElement('canvas');
  terrainCanvas.width = 512;
  terrainCanvas.height = 512;
  const tctx = terrainCanvas.getContext('2d')!;
  tctx.fillStyle = '#5c4932';
  tctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 14000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = Math.random();
    tctx.fillStyle =
      r > 0.62
        ? 'rgba(196,154,92,0.22)'
        : r > 0.3
        ? 'rgba(72,90,52,0.2)'
        : 'rgba(84,56,34,0.24)';
    tctx.fillRect(x, y, 4, 4);
  }
  tctx.strokeStyle = 'rgba(255,235,205,0.04)';
  tctx.lineWidth = 1;
  for (let g = 0; g < 512; g += 32) {
    tctx.beginPath();
    tctx.moveTo(g, 0);
    tctx.lineTo(g, 512);
    tctx.stroke();
    tctx.beginPath();
    tctx.moveTo(0, g);
    tctx.lineTo(512, g);
    tctx.stroke();
  }
  const terrainMap = new THREE.CanvasTexture(terrainCanvas);
  terrainMap.colorSpace = THREE.SRGBColorSpace;
  terrainMap.wrapS = THREE.RepeatWrapping;
  terrainMap.wrapT = THREE.RepeatWrapping;
  terrainMap.repeat.set(130, 130);
  terrainMap.anisotropy = maxAniso;

  // 3. Carved Sandstone Block Map
  const sandCanvas = document.createElement('canvas');
  sandCanvas.width = 256;
  sandCanvas.height = 256;
  const sctx = sandCanvas.getContext('2d')!;
  sctx.fillStyle = '#d49464';
  sctx.fillRect(0, 0, 256, 256);
  for (let row = 0; row < 16; row++) {
    const y = row * 16;
    sctx.fillStyle = row % 2 === 0 ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.06)';
    sctx.fillRect(0, y, 256, 2);
    const offset = (row % 2) * 16;
    for (let col = 0; col < 8; col++) {
      sctx.fillRect((col * 32 + offset) % 256, y, 2, 16);
    }
  }
  for (let i = 0; i < 2000; i++) {
    sctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,235,200,0.07)' : 'rgba(60,30,10,0.08)';
    sctx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
  }
  const sandstoneMap = new THREE.CanvasTexture(sandCanvas);
  sandstoneMap.colorSpace = THREE.SRGBColorSpace;
  sandstoneMap.wrapS = THREE.RepeatWrapping;
  sandstoneMap.wrapT = THREE.RepeatWrapping;
  sandstoneMap.anisotropy = maxAniso;

  // 3B. Ornate Rajasthani Haveli & Pink City Jharokha Arch Facade Map
  const haveliCanvas = document.createElement('canvas');
  haveliCanvas.width = 256;
  haveliCanvas.height = 256;
  const hctx = haveliCanvas.getContext('2d')!;
  hctx.fillStyle = '#cf6d63';
  hctx.fillRect(0, 0, 256, 256);
  for (let row = 0; row < 4; row++) {
    const y0 = row * 64;
    hctx.fillStyle = '#f8e6d0';
    hctx.fillRect(0, y0, 256, 6);
    hctx.fillStyle = '#993b33';
    hctx.fillRect(0, y0 + 6, 256, 4);
    for (let col = 0; col < 4; col++) {
      const x0 = col * 64 + 10;
      hctx.fillStyle = '#f8e6d0';
      hctx.fillRect(x0 - 3, y0 + 16, 44, 40);
      hctx.fillStyle = '#1e1b2e';
      hctx.fillRect(x0 + 2, y0 + 24, 34, 30);
      hctx.beginPath();
      hctx.arc(x0 + 19, y0 + 24, 17, Math.PI, 0);
      hctx.fill();
      if ((row + col) % 2 === 0) {
        hctx.fillStyle = 'rgba(251, 191, 36, 0.55)';
        hctx.fillRect(x0 + 8, y0 + 28, 22, 22);
      }
      hctx.fillStyle = '#d97706';
      hctx.fillRect(x0 + 18, y0 + 20, 2, 34);
    }
  }
  const haveliMap = new THREE.CanvasTexture(haveliCanvas);
  haveliMap.colorSpace = THREE.SRGBColorSpace;
  haveliMap.wrapS = THREE.RepeatWrapping;
  haveliMap.wrapT = THREE.RepeatWrapping;
  haveliMap.anisotropy = maxAniso;

  // 3C. Heritage Lime-Wash Wall Texture
  const blueCanvas = document.createElement('canvas');
  blueCanvas.width = 256;
  blueCanvas.height = 256;
  const blctx = blueCanvas.getContext('2d')!;
  blctx.fillStyle = '#3b82f6';
  blctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 3000; i++) {
    blctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.08)' : 'rgba(23,37,84,0.1)';
    blctx.fillRect(Math.random() * 256, Math.random() * 256, 4, 4);
  }
  for (let row = 0; row < 4; row++) {
    const y0 = row * 64;
    blctx.fillStyle = '#e0f2fe';
    blctx.fillRect(0, y0, 256, 4);
    for (let col = 0; col < 4; col++) {
      const x0 = col * 64 + 14;
      blctx.fillStyle = '#f8fafc';
      blctx.fillRect(x0 - 2, y0 + 16, 36, 36);
      blctx.fillStyle = '#0f172a';
      blctx.fillRect(x0 + 2, y0 + 20, 28, 28);
    }
  }
  const blueCityMap = new THREE.CanvasTexture(blueCanvas);
  blueCityMap.colorSpace = THREE.SRGBColorSpace;
  blueCityMap.wrapS = THREE.RepeatWrapping;
  blueCityMap.wrapT = THREE.RepeatWrapping;
  blueCityMap.anisotropy = maxAniso;

  const shopSignMap = makeHighwaySignTexture(
    'LITTLE JAIPUR BAZAAR',
    'HANDICRAFTS · DHABA · OPEN 24H',
    '#7c2d12',
    maxAniso,
  );

  // 4. Modern Glass Skyscraper Curtain Wall + Emissive Window Map
  const glassCanvas = document.createElement('canvas');
  glassCanvas.width = 256;
  glassCanvas.height = 512;
  const gctx = glassCanvas.getContext('2d')!;
  gctx.fillStyle = '#0f172a';
  gctx.fillRect(0, 0, 256, 512);

  const emCanvas = document.createElement('canvas');
  emCanvas.width = 256;
  emCanvas.height = 512;
  const ectx = emCanvas.getContext('2d')!;
  ectx.fillStyle = '#000000';
  ectx.fillRect(0, 0, 256, 512);

  for (let row = 0; row < 32; row++) {
    for (let col = 0; col < 16; col++) {
      const lit = Math.random() > 0.44;
      const warm = Math.random() > 0.65;
      const winColor = lit ? (warm ? '#fde68a' : '#38bdf8') : '#1e293b';
      gctx.fillStyle = winColor;
      gctx.fillRect(col * 16 + 2, row * 16 + 2, 12, 11);
      if (lit) {
        ectx.fillStyle = warm ? '#fbbf24' : '#0ea5e9';
        ectx.fillRect(col * 16 + 3, row * 16 + 3, 10, 9);
      }
    }
  }
  const glassTowerMap = new THREE.CanvasTexture(glassCanvas);
  glassTowerMap.colorSpace = THREE.SRGBColorSpace;
  glassTowerMap.wrapS = THREE.RepeatWrapping;
  glassTowerMap.wrapT = THREE.RepeatWrapping;
  glassTowerMap.anisotropy = maxAniso;

  const glassTowerEmissive = new THREE.CanvasTexture(emCanvas);
  glassTowerEmissive.colorSpace = THREE.SRGBColorSpace;
  glassTowerEmissive.wrapS = THREE.RepeatWrapping;
  glassTowerEmissive.wrapT = THREE.RepeatWrapping;
  glassTowerEmissive.anisotropy = maxAniso;

  // 5. Carbon Fiber Weave
  const carbonCanvas = document.createElement('canvas');
  carbonCanvas.width = 64;
  carbonCanvas.height = 64;
  const cctx = carbonCanvas.getContext('2d')!;
  cctx.fillStyle = '#111827';
  cctx.fillRect(0, 0, 64, 64);
  for (let y = 0; y < 64; y += 8) {
    for (let x = 0; x < 64; x += 8) {
      cctx.fillStyle = (x + y) % 16 === 0 ? '#1f2937' : '#0b0f17';
      cctx.fillRect(x, y, 4, 4);
      cctx.fillRect(x + 4, y + 4, 4, 4);
    }
  }
  const carbonMap = new THREE.CanvasTexture(carbonCanvas);
  carbonMap.colorSpace = THREE.SRGBColorSpace;
  carbonMap.wrapS = THREE.RepeatWrapping;
  carbonMap.wrapT = THREE.RepeatWrapping;
  carbonMap.repeat.set(8, 8);

  // 6. Soft Radial Contact Shadow
  const shadowCanvas = document.createElement('canvas');
  shadowCanvas.width = 128;
  shadowCanvas.height = 128;
  const shctx = shadowCanvas.getContext('2d')!;
  const grad = shctx.createRadialGradient(64, 64, 8, 64, 64, 62);
  grad.addColorStop(0, 'rgba(0,0,0,0.78)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0.38)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  shctx.fillStyle = grad;
  shctx.fillRect(0, 0, 128, 128);
  const contactShadowMap = new THREE.CanvasTexture(shadowCanvas);

  // 7. Little Jaipur Gantries, Civic Buildings, Stores & Brand Showrooms
  const highwaySignNorth = makeHighwaySignTexture(
    'LITTLE JAIPUR  |  AMER  |  JAL MAHAL',
    'PINK CITY EXPRESSWAY · OBEY TRAFFIC SIGNALS',
    '#9d174d',
    maxAniso,
  );
  const highwaySignSouth = makeHighwaySignTexture(
    'LITTLE JAIPUR  |  SMS STADIUM  |  AIRPORT',
    'JLN MARG · TONK ROAD · PATRIKA GATE',
    '#1e3a8a',
    maxAniso,
  );

  const policeCanvas = document.createElement('canvas');
  policeCanvas.width = 512;
  policeCanvas.height = 160;
  const pctx = policeCanvas.getContext('2d')!;
  pctx.fillStyle = '#0f172a';
  pctx.fillRect(0, 0, 512, 160);
  pctx.fillStyle = '#dc2626';
  pctx.fillRect(0, 0, 256, 16);
  pctx.fillStyle = '#2563eb';
  pctx.fillRect(256, 0, 256, 16);
  pctx.fillStyle = '#dc2626';
  pctx.fillRect(0, 144, 256, 16);
  pctx.fillStyle = '#2563eb';
  pctx.fillRect(256, 144, 256, 16);
  pctx.fillStyle = '#ffffff';
  pctx.font = 'bold 40px sans-serif';
  pctx.textAlign = 'center';
  pctx.fillText('JAIPUR POLICE HQ', 256, 74);
  pctx.fillStyle = '#fbbf24';
  pctx.font = 'bold 24px sans-serif';
  pctx.fillText('COMMISSIONERATE · HELIPAD & LOCKUP', 256, 120);
  const policeStationSign = new THREE.CanvasTexture(policeCanvas);
  policeStationSign.colorSpace = THREE.SRGBColorSpace;
  policeStationSign.anisotropy = maxAniso;

  const bankSignMap = makeHighwaySignTexture('STATE BANK OF JAIPUR', '24x7 ATM · SAFE VAULT · HEIST TARGET', '#064e3b', maxAniso);
  const hospitalSignMap = makeHighwaySignTexture('+ SMS MEDICAL HOSPITAL +', '24x7 TRAUMA CARE · MAX-HP UPGRADES', '#991b1b', maxAniso);
  const homeSignMap = makeHighwaySignTexture('C-SCHEME ROYAL HAVELI', 'PLAYER HOME · GARAGE · REST & SAVE', '#78350f', maxAniso);
  const airportSignMap = makeHighwaySignTexture("JAIPUR INT'L AIRPORT (JAI)", 'SANGANER TERMINAL · FLYABLE PRIVATE JET', '#0c4a6e', maxAniso);

  const dmartSignMap = makeHighwaySignTexture('DMart SUPERMART', 'DAILY GROCERIES · REPAIR KIT · JERRYCAN', '#15803d', maxAniso, '#facc15', '#fef08a');
  const decathlonSignMap = makeHighwaySignTexture('DECATHLON JAIPUR', 'SPORTS GEAR · SPRINT SHOES · ARMOR', '#0369a1', maxAniso, '#ffffff', '#7dd3fc');
  const ammunationSignMap = makeHighwaySignTexture('AMMU-NATION JAIPUR', 'WEAPONS · HEAVY ORDNANCE · BODY ARMOR', '#7f1d1d', maxAniso, '#f59e0b', '#fde047');
  const clothSignMap = makeHighwaySignTexture('JOHARI CLOTH & FASHION', 'ROYAL SHERWANI · JACKETS · KURTA SETS', '#701a75', maxAniso, '#f472b6', '#fbcfe8');
  const barberSignMap = makeHighwaySignTexture('ROYAL JAIPUR BARBER', 'HAIRCUTS · BEARD TRIM · STYLING SALON', '#1e293b', maxAniso, '#ef4444', '#38bdf8');
  const petrolSignMap = makeHighwaySignTexture('INDIAN OIL PETROL PUMP', 'PETROL · DIESEL · NITRO · FREE AIR', '#ea580c', maxAniso, '#1d4ed8', '#fef08a');
  const paanSignMap = makeHighwaySignTexture('ROYAL BANARASI PAAN', 'SAFFRON MEETHA PAAN · NITRO & HP BOOST', '#047857', maxAniso, '#fde047', '#ffffff');
  const grocerySignMap = makeHighwaySignTexture('GUPTA KIRANA & GROCERY', 'SNACKS · WATER · RATIONS · ROBBERY', '#b45309', maxAniso);
  const hotelSignMap = makeHighwaySignTexture('RAMBAGH HERITAGE HOTEL', 'LUXURY SUITE REST · CLEAR HEAT · JOBS', '#78350f', maxAniso, '#fbbf24');
  const schoolSignMap = makeHighwaySignTexture('SMS PUBLIC SCHOOL', 'JAIPUR ACADEMY · TEACH & EARN CASH', '#1e40af', maxAniso);
  const officeSignMap = makeHighwaySignTexture('JAIPUR TECH & SECRETARIAT', 'CORPORATE SHIFTS · WORK OR ROB VAULT', '#0f172a', maxAniso, '#38bdf8', '#a5f3fc');
  const fireStationSignMap = makeHighwaySignTexture('JAIPUR FIRE BRIGADE HQ', 'FIRE TENDERS · WATER CANNON · RESCUE', '#b91c1c', maxAniso, '#facc15', '#fef08a');
  const metroSignMap = makeHighwaySignTexture('JAIPUR METRO STATION', 'PINK & ORANGE LINE · RAPID TRANSIT', '#be185d', maxAniso, '#ffffff', '#fbcfe8');
  const railSignMap = makeHighwaySignTexture('JAIPUR JUNCTION RAILWAY', 'INDIAN RAILWAYS · EXPRESS TRAINS', '#1d4ed8', maxAniso, '#facc15', '#ffffff');
  const stadiumSignMap = makeHighwaySignTexture('SAWAI MANSINGH STADIUM', 'CRICKET ARENA · VIP BOXES · HEIST', '#065f46', maxAniso, '#34d399', '#fde047');
  const jewelrySignMap = makeHighwaySignTexture('GEM PALACE JEWELERS', 'JOHARI BAZAAR · GOLD & DIAMOND VAULT', '#713f12', maxAniso, '#fbbf24', '#fef08a');
  const sweetSignMap = makeHighwaySignTexture('LMB MITHAI BHANDAR', 'GHEWAR · PYAAZ KACHORI · LASSI', '#c2410c', maxAniso, '#fde047');
  const electronicsSignMap = makeHighwaySignTexture('PINK CITY ELECTRONICS', 'GADGETS · GPS SCANNERS · HIGH LOOT', '#1e1b4b', maxAniso, '#22d3ee', '#67e8f9');
  const pharmacySignMap = makeHighwaySignTexture('+ APOLLO MEDICOS 24x7 +', 'MEDKITS · STAMINA TONICS · FIRST AID', '#0f766e', maxAniso, '#ffffff', '#99f6e4');
  const chaiSignMap = makeHighwaySignTexture('GULAB JI CHAI TAPRI', 'MASALA CHAI · BUN MASKA · ENERGY', '#9a3412', maxAniso, '#fbbf24');

  const showroomFerrariSign = makeHighwaySignTexture('FERRARI & LAMBORGHINI', 'EXOTIC HYPERCAR SHOWROOM · MI ROAD', '#991b1b', maxAniso, '#fbbf24');
  const showroomBugattiSign = makeHighwaySignTexture('BUGATTI & KOENIGSEGG', 'JLN MEGACAR GALLERY · WORLD TRADE PARK', '#1e3a8a', maxAniso, '#38bdf8');
  const showroomSuvSign = makeHighwaySignTexture('MAHINDRA & TOYOTA SUV', 'THAR 4x4 · FORTUNER LEGENDER · SHOWROOM', '#334155', maxAniso, '#ef4444');
  const showroomMarutiSign = makeHighwaySignTexture('MARUTI & HONDA MOTORS', 'CITY SEDAN · SWIFT · ALTO · TAXI · VAN', '#0f766e', maxAniso, '#e2e8f0');
  const showroomBikeSign = makeHighwaySignTexture('ROYAL ENFIELD & KTM', 'BULLET 350 · DUKE 390 · ACTIVA · E-AUTO', '#c2410c', maxAniso, '#fde047');

  // 8. Asphalt Airport Runway 09/27 Texture
  const rwCanvas = document.createElement('canvas');
  rwCanvas.width = 1024;
  rwCanvas.height = 256;
  const rwCtx = rwCanvas.getContext('2d')!;
  rwCtx.fillStyle = '#1e2430';
  rwCtx.fillRect(0, 0, 1024, 256);
  for (let i = 0; i < 6500; i++) {
    const v = 22 + Math.floor(Math.random() * 24);
    rwCtx.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
    rwCtx.fillRect(Math.random() * 1024, Math.random() * 256, 2, 2);
  }
  rwCtx.fillStyle = '#f8fafc';
  rwCtx.fillRect(0, 10, 1024, 5);
  rwCtx.fillRect(0, 241, 1024, 5);
  rwCtx.fillStyle = '#facc15';
  rwCtx.fillRect(0, 22, 1024, 2);
  rwCtx.fillRect(0, 232, 1024, 2);
  rwCtx.fillStyle = '#f8fafc';
  for (let y = 34; y <= 210; y += 22) {
    rwCtx.fillRect(14, y, 42, 10);
    rwCtx.fillRect(968, y, 42, 10);
  }
  rwCtx.font = 'bold 42px sans-serif';
  rwCtx.textAlign = 'center';
  rwCtx.textBaseline = 'middle';
  rwCtx.save();
  rwCtx.translate(92, 128);
  rwCtx.rotate(Math.PI / 2);
  rwCtx.fillText('09', 0, 0);
  rwCtx.restore();
  rwCtx.save();
  rwCtx.translate(932, 128);
  rwCtx.rotate(-Math.PI / 2);
  rwCtx.fillText('27', 0, 0);
  rwCtx.restore();
  for (let x = 140; x < 884; x += 48) {
    rwCtx.fillRect(x, 124, 26, 8);
  }
  const runwayMap = new THREE.CanvasTexture(rwCanvas);
  runwayMap.colorSpace = THREE.SRGBColorSpace;
  runwayMap.anisotropy = maxAniso;

  const pack: ProceduralTexturePack = {
    asphaltMap,
    asphaltBump,
    asphaltRoughness,
    terrainMap,
    sandstoneMap,
    haveliMap,
    blueCityMap,
    shopSignMap,
    glassTowerMap,
    glassTowerEmissive,
    carbonMap,
    contactShadowMap,
    highwaySignNorth,
    highwaySignSouth,
    policeStationSign,
    bankSignMap,
    hospitalSignMap,
    homeSignMap,
    airportSignMap,
    runwayMap,
    dmartSignMap,
    decathlonSignMap,
    ammunationSignMap,
    clothSignMap,
    barberSignMap,
    petrolSignMap,
    paanSignMap,
    grocerySignMap,
    hotelSignMap,
    schoolSignMap,
    officeSignMap,
    fireStationSignMap,
    metroSignMap,
    railSignMap,
    stadiumSignMap,
    jewelrySignMap,
    sweetSignMap,
    electronicsSignMap,
    pharmacySignMap,
    chaiSignMap,
    showroomFerrariSign,
    showroomBugattiSign,
    showroomSuvSign,
    showroomMarutiSign,
    showroomBikeSign,
    dispose: () => {
      asphaltMap.dispose();
      asphaltBump.dispose();
      asphaltRoughness.dispose();
      terrainMap.dispose();
      sandstoneMap.dispose();
      haveliMap.dispose();
      blueCityMap.dispose();
      shopSignMap.dispose();
      glassTowerMap.dispose();
      glassTowerEmissive.dispose();
      carbonMap.dispose();
      contactShadowMap.dispose();
      highwaySignNorth.dispose();
      highwaySignSouth.dispose();
      policeStationSign.dispose();
      bankSignMap.dispose();
      hospitalSignMap.dispose();
      homeSignMap.dispose();
      airportSignMap.dispose();
      runwayMap.dispose();
      dmartSignMap.dispose();
      decathlonSignMap.dispose();
      ammunationSignMap.dispose();
      clothSignMap.dispose();
      barberSignMap.dispose();
      petrolSignMap.dispose();
      paanSignMap.dispose();
      grocerySignMap.dispose();
      hotelSignMap.dispose();
      schoolSignMap.dispose();
      officeSignMap.dispose();
      fireStationSignMap.dispose();
      metroSignMap.dispose();
      railSignMap.dispose();
      stadiumSignMap.dispose();
      jewelrySignMap.dispose();
      sweetSignMap.dispose();
      electronicsSignMap.dispose();
      pharmacySignMap.dispose();
      chaiSignMap.dispose();
      showroomFerrariSign.dispose();
      showroomBugattiSign.dispose();
      showroomSuvSign.dispose();
      showroomMarutiSign.dispose();
      showroomBikeSign.dispose();
    },
  };
  return pack;
}
