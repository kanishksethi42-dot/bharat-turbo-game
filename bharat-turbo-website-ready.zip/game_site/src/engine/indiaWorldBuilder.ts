import * as THREE from 'three';
import {
  JAIPUR_CIRCLES,
  JAIPUR_EW_ROADS,
  JAIPUR_LOCALITIES,
  JAIPUR_METRO_STATIONS,
  JAIPUR_NS_ROADS,
  JAIPUR_RAIL_STATIONS,
  JAIPUR_TRAFFIC_LIGHTS,
  POLICE_STATION,
  WORLD_FACILITIES,
  type BuildingCategory,
  type EnterableBuildingInfo,
  type VehicleId,
} from '../types/game';
import type { ProceduralTexturePack } from './proceduralTextures';
import {
  buildIndianExpressTrain,
  buildJetAircraft,
  buildMetroTrain,
  buildVehicleModel,
} from './vehicleBuilder';

export interface BuildingCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
}

export interface BlueprintBuilding {
  x: number;
  z: number;
  w: number;
  d: number;
  kind?:
    | 'city'
    | 'bank'
    | 'hospital'
    | 'home'
    | 'police'
    | 'landmark'
    | 'airport'
    | 'fire'
    | 'showroom'
    | 'petrol'
    | 'store'
    | 'stadium'
    | 'metro'
    | 'railway';
}

export interface StuntRamp {
  x: number;
  z: number;
  halfW: number;
  halfL: number;
  yaw: number;
  height: number;
}

export type PropKind = 'lamp' | 'stall' | 'cone' | 'bollard';

export interface DestructibleProp {
  id: number;
  kind: PropKind;
  mesh: THREE.Group;
  originX: number;
  originZ: number;
  x: number;
  z: number;
  radius: number;
  colorHex: number;
  smashed: boolean;
  respawnTimer: number;
}

export interface TrafficLightRig {
  id: string;
  label: string;
  x: number;
  z: number;
  phaseOffset: number;
  ewRedMat: THREE.MeshStandardMaterial;
  ewAmberMat: THREE.MeshStandardMaterial;
  ewGreenMat: THREE.MeshStandardMaterial;
  nsRedMat: THREE.MeshStandardMaterial;
  nsAmberMat: THREE.MeshStandardMaterial;
  nsGreenMat: THREE.MeshStandardMaterial;
}

export interface IndiaWorldHandles {
  worldGroup: THREE.Group;
  asphaltMaterial: THREE.MeshStandardMaterial;
  roadNetworkMeshes: THREE.Mesh[];
  techGlassMat: THREE.MeshStandardMaterial;
  waterUniforms: { uTime: { value: number } };
  neonMaterials: THREE.MeshStandardMaterial[];
  buildings: BuildingCollider[];
  blueprintBuildings: BlueprintBuilding[];
  facilityRings: THREE.Mesh[];
  airportRadars: THREE.Object3D[];
  trafficLights: TrafficLightRig[];
  enterableBuildings: EnterableBuildingInfo[];
  showroomTurntables: THREE.Object3D[];
  metroTrain: THREE.Group;
  expressTrain: THREE.Group;
  fireHqPos: { x: number; z: number };
  ramps: StuntRamp[];
  destructibles: DestructibleProp[];
  groundHeightAt: (x: number, z: number) => number;
  isOnBridgeAt: (x: number, z: number) => boolean;
  resetProp: (prop: DestructibleProp) => void;
}

export function buildIndiaWorld(textures: ProceduralTexturePack, isSoftwareGl: boolean): IndiaWorldHandles {
  const worldGroup = new THREE.Group();
  const buildings: BuildingCollider[] = [];
  const blueprintBuildings: BlueprintBuilding[] = [];
  const facilityRings: THREE.Mesh[] = [];
  const airportRadars: THREE.Object3D[] = [];
  const trafficLights: TrafficLightRig[] = [];
  const enterableBuildings: EnterableBuildingInfo[] = [];
  const showroomTurntables: THREE.Object3D[] = [];
  const ramps: StuntRamp[] = [];
  const destructibles: DestructibleProp[] = [];
  const neonMaterials: THREE.MeshStandardMaterial[] = [];
  const roadNetworkMeshes: THREE.Mesh[] = [];

  // Shared Architectural Materials
  const sandstoneMat = new THREE.MeshStandardMaterial({
    map: textures.sandstoneMap,
    color: 0xe6b88a,
    roughness: 0.78,
    metalness: 0.05,
  });
  const goldenStoneMat = new THREE.MeshStandardMaterial({
    map: textures.sandstoneMap,
    color: 0xf4c266,
    roughness: 0.74,
    metalness: 0.06,
  });
  const pinkHaveliMat = new THREE.MeshStandardMaterial({
    map: textures.haveliMap,
    color: 0xf4a89f,
    roughness: 0.72,
    metalness: 0.05,
  });
  const pinkSolidMat = new THREE.MeshStandardMaterial({
    map: textures.sandstoneMap,
    color: 0xd96b64,
    roughness: 0.74,
    metalness: 0.04,
  });
  const whiteMarbleMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.38,
    metalness: 0.08,
  });
  const terracottaMat = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    roughness: 0.8,
  });
  const concreteMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.65,
    metalness: 0.14,
  });
  const darkSteelMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.4,
    metalness: 0.78,
  });
  const cableMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.22,
    metalness: 0.88,
  });
  const lawnMat = new THREE.MeshStandardMaterial({
    color: 0x1e5c34,
    roughness: 0.92,
    metalness: 0.0,
  });
  const pitchTurfMat = new THREE.MeshStandardMaterial({
    color: 0x228b22,
    roughness: 0.88,
    metalness: 0.0,
  });
  const shopSignMat = new THREE.MeshStandardMaterial({
    map: textures.shopSignMap,
    emissiveMap: textures.shopSignMap,
    emissive: new THREE.Color(0xffffff),
    emissiveIntensity: 0.35,
    roughness: 0.45,
  });
  const techGlassMat = new THREE.MeshStandardMaterial({
    map: textures.glassTowerMap,
    emissiveMap: textures.glassTowerEmissive,
    emissive: new THREE.Color(0xffffff),
    emissiveIntensity: 0.75,
    roughness: 0.16,
    metalness: 0.82,
    envMapIntensity: 1.5,
  });
  const showroomGlassMat = new THREE.MeshPhysicalMaterial({
    color: 0x7dd3fc,
    roughness: 0.08,
    metalness: 0.2,
    transparent: true,
    opacity: 0.45,
    transmission: 0.25,
  });
  const warmLanternMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xf59e0b,
    emissiveIntensity: 2.2,
  });
  const syntaxTankMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7,
    roughness: 0.45,
  });
  neonMaterials.push(warmLanternMat);

  // 1. Full-Scale Little Jaipur Valley Terrain (6800 x 6800m; playable -1500..1500)
  const terrainGeo = new THREE.PlaneGeometry(6800, 6800, 1, 1);
  terrainGeo.rotateX(-Math.PI / 2);
  const terrainMat = new THREE.MeshStandardMaterial({
    map: textures.terrainMap,
    color: 0xffffff,
    roughness: 0.92,
    metalness: 0.03,
  });
  const terrain = new THREE.Mesh(terrainGeo, terrainMat);
  terrain.receiveShadow = true;
  worldGroup.add(terrain);

  // Authentic Jaipur Urban District Ground Pads (+0.014 Y offset)
  const regionalPads: Array<{ x: number; z: number; w: number; d: number; color: number; grass?: boolean }> = [
    { x: 90, z: -210, w: 660, d: 340, color: 0x8f5149 }, // Walled Pink City Terracotta District
    { x: 100, z: 65, w: 120, d: 115, color: 0x1f5c35, grass: true }, // Ram Niwas Bagh Gardens
    { x: 65, z: 455, w: 180, d: 170, color: 0x1e5c34, grass: true }, // Central Park Polo Grounds
    { x: 160, z: 840, w: 110, d: 110, color: 0x225a37, grass: true }, // Jawahar Circle Garden
    { x: -585, z: 710, w: 170, d: 150, color: 0x1d6b3b, grass: true }, // Mansarovar City Park
    { x: -885, z: 225, w: 150, d: 120, color: 0x1e6036, grass: true }, // Vaishali Chitrakoot Sports Ground
    { x: -595, z: -475, w: 150, d: 120, color: 0x1e6036, grass: true }, // Vidyadhar Nagar Stadium Lawn
    { x: -120, z: 190, w: 380, d: 210, color: 0x565d68 }, // MI Road & C-Scheme Urban Core
    { x: -480, z: 140, w: 220, d: 180, color: 0x525b66 }, // Jaipur Junction Station Zone
    { x: 420, z: 580, w: 220, d: 210, color: 0x475569 }, // Malviya Nagar & WTP Tech Plaza
  ];
  for (const pad of regionalPads) {
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(pad.w, pad.d),
      pad.grass
        ? lawnMat
        : new THREE.MeshStandardMaterial({
            map: textures.terrainMap,
            color: pad.color,
            roughness: 0.92,
            metalness: 0.0,
          }),
    );
    m.rotation.x = -Math.PI / 2;
    m.position.set(pad.x, 0.014, pad.z);
    m.receiveShadow = true;
    worldGroup.add(m);
  }

  // 2. Animated Water Bodies: Man Sagar Lake (Jal Mahal) & Dravyavati Riverfront
  const waterUniforms = { uTime: { value: 0 } };
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x0369a1,
    roughness: 0.14,
    metalness: 0.72,
    envMapIntensity: 1.35,
  });
  if (!isSoftwareGl) {
    waterMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = waterUniforms.uTime;
      shader.vertexShader = `uniform float uTime;\n` + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         transformed.z += sin(position.x * 0.07 + uTime * 1.5) * 0.12 + cos(position.y * 0.08 + uTime * 1.1) * 0.11;`,
      );
    };
  }

  // Man Sagar Lake (between nsRoads 160 & 420 and ewRoads -960 & -560)
  const manSagarLake = new THREE.Mesh(new THREE.PlaneGeometry(184, 178, 22, 18), waterMat);
  manSagarLake.rotation.x = -Math.PI / 2;
  manSagarLake.position.set(290, 0.028, -750);
  manSagarLake.receiveShadow = true;
  worldGroup.add(manSagarLake);

  const jalPromenade = new THREE.Mesh(new THREE.BoxGeometry(14, 0.65, 182), sandstoneMat);
  jalPromenade.position.set(192, 0.32, -750);
  jalPromenade.receiveShadow = true;
  worldGroup.add(jalPromenade);

  // Jal Mahal (Water Palace)
  const jalMahal = new THREE.Group();
  jalMahal.position.set(290, 0.2, -750);
  const jmBase = new THREE.Mesh(new THREE.BoxGeometry(34, 2.2, 30), sandstoneMat);
  jmBase.position.y = 1.1;
  const jmPalace = new THREE.Mesh(new THREE.BoxGeometry(26, 7.2, 22), pinkHaveliMat);
  jmPalace.position.y = 5.6;
  jmPalace.castShadow = !isSoftwareGl;
  const jmCenterChhatri = new THREE.Mesh(new THREE.BoxGeometry(10, 3.8, 10), whiteMarbleMat);
  jmCenterChhatri.position.y = 11.1;
  const jmDome = new THREE.Mesh(
    new THREE.SphereGeometry(4.2, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.6),
    whiteMarbleMat,
  );
  jmDome.position.y = 13.0;
  jalMahal.add(jmBase, jmPalace, jmCenterChhatri, jmDome);
  for (const cx of [-9, 9]) {
    for (const cz of [-7, 7]) {
      const chhatri = new THREE.Mesh(
        new THREE.SphereGeometry(1.8, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.6),
        goldenStoneMat,
      );
      chhatri.position.set(cx, 9.8, cz);
      jalMahal.add(chhatri);
    }
  }
  worldGroup.add(jalMahal);
  buildings.push({ minX: 272, maxX: 308, minZ: -766, maxZ: -734, height: 15 });
  blueprintBuildings.push({ x: 290, z: -750, w: 34, d: 30, kind: 'landmark' });

  // Dravyavati Riverfront Channel
  const dravyavatiRiver = new THREE.Mesh(new THREE.PlaneGeometry(340, 108, 22, 12), waterMat);
  dravyavatiRiver.rotation.x = -Math.PI / 2;
  dravyavatiRiver.position.set(-60, 0.028, 710);
  dravyavatiRiver.receiveShadow = true;
  worldGroup.add(dravyavatiRiver);

  // 3. Aravalli Hills Surrounding Jaipur
  const hillMat = new THREE.MeshStandardMaterial({ color: 0x5c4a38, roughness: 0.94 });
  const ridgeMat = new THREE.MeshStandardMaterial({ color: 0x4b3f35, roughness: 0.95 });

  for (let i = 0; i < 64; i++) {
    const angle = (i / 64) * Math.PI * 2;
    const dist = 1660 + (i % 4) * 95;
    const h = 94 + ((i * 23) % 98);
    const w = 195 + ((i * 31) % 105);
    const isNorthEastAravalli = Math.sin(angle) < -0.25 || Math.cos(angle) > 0.35;
    const ridge = new THREE.Mesh(new THREE.ConeGeometry(w, h, 5), isNorthEastAravalli ? hillMat : ridgeMat);
    ridge.position.set(Math.cos(angle) * dist, h * 0.42, Math.sin(angle) * dist);
    ridge.rotation.y = i * 0.65;
    worldGroup.add(ridge);
  }

  const spurCoords: Array<[number, number, number, number]> = [
    [-260, -1140, 68, 38],
    [-80, -1160, 74, 44],
    [350, -1150, 72, 42],
    [540, -1080, 66, 36],
    [600, -780, 64, 34],
    [940, -320, 62, 34],
    [960, -120, 58, 30],
    [1180, -580, 70, 40],
  ];
  for (const [dx, dz, rad, dh] of spurCoords) {
    const hill = new THREE.Mesh(new THREE.ConeGeometry(rad, dh, 7), hillMat);
    hill.position.set(dx, dh * 0.42, dz);
    hill.scale.set(1.25, 1, 0.9);
    hill.receiveShadow = true;
    worldGroup.add(hill);
  }

  // 4. Authentic Jaipur Urban Road Network (Matte Mineral Asphalt — zero shiny glare)
  const asphaltMaterial = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.asphaltMap,
    bumpMap: textures.asphaltBump,
    bumpScale: 0.035,
    roughnessMap: textures.asphaltRoughness,
    roughness: 0.94,
    metalness: 0.0,
    envMapIntensity: 0.16,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const addRoadStrip = (
    cx: number,
    cz: number,
    width: number,
    length: number,
    rotY = 0,
    y = 0.045,
    polyFactor = -1,
  ) => {
    const mat = asphaltMaterial.clone();
    const texClone = textures.asphaltMap.clone();
    texClone.needsUpdate = true;
    texClone.repeat.set(Math.max(1, Math.round(width / 16)), Math.max(1, Math.round(length / 11)));
    mat.map = texClone;
    const bumpClone = textures.asphaltBump.clone();
    bumpClone.needsUpdate = true;
    bumpClone.repeat.copy(texClone.repeat);
    mat.bumpMap = bumpClone;
    const roughClone = textures.asphaltRoughness.clone();
    roughClone.needsUpdate = true;
    roughClone.repeat.copy(texClone.repeat);
    mat.roughnessMap = roughClone;
    mat.polygonOffsetFactor = polyFactor;
    mat.polygonOffsetUnits = polyFactor;

    const road = new THREE.Mesh(new THREE.PlaneGeometry(width, length), mat);
    road.rotation.x = -Math.PI / 2;
    road.rotation.z = rotY;
    road.position.set(cx, y, cz);
    road.receiveShadow = true;
    worldGroup.add(road);
    roadNetworkMeshes.push(road);
  };

  for (const rz of JAIPUR_EW_ROADS) {
    addRoadStrip(0, rz, 20, 3040, Math.PI / 2, 0.045, -1);
  }
  for (const rx of JAIPUR_NS_ROADS) {
    if (rx === -60) {
      addRoadStrip(-60, -455, 20, 2130, 0, 0.056, -2);
      addRoadStrip(-60, 1165, 20, 710, 0, 0.056, -2);
    } else {
      addRoadStrip(rx, 0, 20, 3040, 0, 0.056, -2);
    }
  }

  // Police HQ & Airport Connector Links
  addRoadStrip(POLICE_STATION.x, 111, 14, 58, 0, 0.064, -3);
  addRoadStrip(240, 1084, 18, 48, 0, 0.064, -3);

  // 4B. 14 Authentic Jaipur Circles (Chaupars & Roundabouts with Central Chhatris/Statues/Fountains)
  for (const circle of JAIPUR_CIRCLES) {
    const cGrp = new THREE.Group();
    cGrp.position.set(circle.x, 0, circle.z);

    // Outer asphalt roundabout apron so lanes cleanly curve around center monument
    const outerR = circle.radius + 11;
    const islandR = Math.max(4.5, Math.min(9.5, circle.radius * 0.38));

    const roadRing = new THREE.Mesh(new THREE.RingGeometry(islandR - 0.5, outerR, 36), asphaltMaterial);
    roadRing.rotation.x = -Math.PI / 2;
    roadRing.position.y = 0.062;
    roadRing.receiveShadow = true;
    cGrp.add(roadRing);
    roadNetworkMeshes.push(roadRing);

    const curbRing = new THREE.Mesh(
      new THREE.CylinderGeometry(islandR, islandR + 0.5, 0.45, 24),
      sandstoneMat,
    );
    curbRing.position.y = 0.22;
    cGrp.add(curbRing);

    const grassTop = new THREE.Mesh(new THREE.CircleGeometry(islandR - 0.6, 24), lawnMat);
    grassTop.rotation.x = -Math.PI / 2;
    grassTop.position.y = 0.46;
    cGrp.add(grassTop);

    const accentMat = new THREE.MeshStandardMaterial({
      color: circle.accent,
      emissive: circle.accent,
      emissiveIntensity: 0.75,
      roughness: 0.35,
    });
    neonMaterials.push(accentMat);

    if (circle.monument === 'patrika') {
      // Jawahar Circle central concentric garden + fountain
      const outerPark = new THREE.Mesh(new THREE.RingGeometry(islandR, circle.radius + 3, 36), lawnMat);
      outerPark.rotation.x = -Math.PI / 2;
      outerPark.position.y = 0.04;
      cGrp.add(outerPark);
      const outerDrive = new THREE.Mesh(new THREE.RingGeometry(circle.radius + 3, circle.radius + 22, 40), asphaltMaterial);
      outerDrive.rotation.x = -Math.PI / 2;
      outerDrive.position.y = 0.064;
      cGrp.add(outerDrive);
      roadNetworkMeshes.push(outerDrive);
      const fountainRing = new THREE.Mesh(new THREE.TorusGeometry(4.5, 0.45, 8, 24), whiteMarbleMat);
      fountainRing.rotation.x = Math.PI / 2;
      fountainRing.position.y = 0.85;
      const jet = new THREE.Mesh(new THREE.ConeGeometry(1.1, 4.8, 10), accentMat);
      jet.position.y = 2.9;
      cGrp.add(fountainRing, jet);
    } else if (circle.monument === 'statue') {
      const ped = new THREE.Mesh(new THREE.BoxGeometry(3.6, 2.8, 3.6), whiteMarbleMat);
      ped.position.y = 1.85;
      const canopy = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 3.0, 0.5, 12), pinkHaveliMat);
      canopy.position.y = 6.2;
      const dome = new THREE.Mesh(new THREE.SphereGeometry(2.2, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.58), whiteMarbleMat);
      dome.position.y = 6.5;
      for (const ang of [0, Math.PI / 2, Math.PI, (Math.PI * 3) / 2]) {
        const col = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 3.2, 8), whiteMarbleMat);
        col.position.set(Math.cos(ang) * 2.1, 4.6, Math.sin(ang) * 2.1);
        cGrp.add(col);
      }
      cGrp.add(ped, canopy, dome);
    } else if (circle.monument === 'chhatri') {
      const base = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 3.1, 1.4, 10), sandstoneMat);
      base.position.y = 1.1;
      const roof = new THREE.Mesh(new THREE.SphereGeometry(2.3, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.58), goldenStoneMat);
      roof.position.y = 5.4;
      for (let k = 0; k < 4; k++) {
        const a = (k * Math.PI) / 2;
        const p = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 3.6, 8), sandstoneMat);
        p.position.set(Math.cos(a) * 1.7, 3.6, Math.sin(a) * 1.7);
        cGrp.add(p);
      }
      cGrp.add(base, roof);
    } else if (circle.monument === 'fountain') {
      const bowl1 = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 2.2, 1.1, 16), whiteMarbleMat);
      bowl1.position.y = 1.0;
      const spire = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.9, 3.6, 12), pinkHaveliMat);
      spire.position.y = 2.8;
      const crown = new THREE.Mesh(new THREE.SphereGeometry(0.85, 10, 8), accentMat);
      crown.position.y = 5.0;
      cGrp.add(bowl1, spire, crown);
    } else if (circle.monument === 'clock') {
      const tower = new THREE.Mesh(new THREE.BoxGeometry(2.6, 7.2, 2.6), sandstoneMat);
      tower.position.y = 4.0;
      const face = new THREE.Mesh(new THREE.BoxGeometry(2.85, 1.6, 2.85), accentMat);
      face.position.y = 6.2;
      const cap = new THREE.Mesh(new THREE.ConeGeometry(2.0, 2.2, 4), goldenStoneMat);
      cap.rotation.y = Math.PI / 4;
      cap.position.y = 8.6;
      cGrp.add(tower, face, cap);
    } else {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 1.3, 7.5, 12), pinkSolidMat);
      pillar.position.y = 4.1;
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.9, 10, 8), accentMat);
      orb.position.y = 8.3;
      cGrp.add(pillar, orb);
    }

    worldGroup.add(cGrp);
    const colR = Math.max(2.4, islandR * 0.55);
    buildings.push({
      minX: circle.x - colR,
      maxX: circle.x + colR,
      minZ: circle.z - colR,
      maxZ: circle.z + colR,
      height: 8.5,
    });
  }

  // 4C. 18 Working 3D Traffic Signal Intersections (strictly outside road lanes)
  const poleGreyMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.75 });
  const housingBlackMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5, metalness: 0.4 });
  for (let idx = 0; idx < JAIPUR_TRAFFIC_LIGHTS.length; idx++) {
    const tl = JAIPUR_TRAFFIC_LIGHTS[idx];
    const ewRedMat = new THREE.MeshStandardMaterial({ color: 0x450a0a, emissive: 0xef4444, emissiveIntensity: 0.1 });
    const ewAmberMat = new THREE.MeshStandardMaterial({ color: 0x451a03, emissive: 0xf59e0b, emissiveIntensity: 0.1 });
    const ewGreenMat = new THREE.MeshStandardMaterial({ color: 0x052e16, emissive: 0x22c55e, emissiveIntensity: 2.5 });
    const nsRedMat = new THREE.MeshStandardMaterial({ color: 0x450a0a, emissive: 0xef4444, emissiveIntensity: 2.5 });
    const nsAmberMat = new THREE.MeshStandardMaterial({ color: 0x451a03, emissive: 0xf59e0b, emissiveIntensity: 0.1 });
    const nsGreenMat = new THREE.MeshStandardMaterial({ color: 0x052e16, emissive: 0x22c55e, emissiveIntensity: 0.1 });

    const tlGroup = new THREE.Group();
    tlGroup.position.set(tl.x, 0, tl.z);

    const buildCornerPost = (
      cx: number,
      cz: number,
      armRotY: number,
      rMat: THREE.MeshStandardMaterial,
      aMat: THREE.MeshStandardMaterial,
      gMat: THREE.MeshStandardMaterial,
    ) => {
      const postGrp = new THREE.Group();
      postGrp.position.set(cx, 0, cz);
      postGrp.rotation.y = armRotY;
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.24, 6.2, 8), poleGreyMat);
      mast.position.y = 3.1;
      const arm = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.22, 0.22), poleGreyMat);
      arm.position.set(1.8, 5.95, 0);
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.65, 1.55, 0.55), housingBlackMat);
      box.position.set(3.2, 5.3, 0);
      const lensGeo = new THREE.SphereGeometry(0.16, 8, 8);
      const lRed = new THREE.Mesh(lensGeo, rMat);
      lRed.position.set(3.2, 5.75, 0.25);
      const lRedBack = new THREE.Mesh(lensGeo, rMat);
      lRedBack.position.set(3.2, 5.75, -0.25);
      const lAmb = new THREE.Mesh(lensGeo, aMat);
      lAmb.position.set(3.2, 5.3, 0.25);
      const lAmbBack = new THREE.Mesh(lensGeo, aMat);
      lAmbBack.position.set(3.2, 5.3, -0.25);
      const lGrn = new THREE.Mesh(lensGeo, gMat);
      lGrn.position.set(3.2, 4.85, 0.25);
      const lGrnBack = new THREE.Mesh(lensGeo, gMat);
      lGrnBack.position.set(3.2, 4.85, -0.25);
      postGrp.add(mast, arm, box, lRed, lRedBack, lAmb, lAmbBack, lGrn, lGrnBack);
      tlGroup.add(postGrp);
    };

    // Corners placed at ±12.5m (cleanly outside 20m road surface)
    buildCornerPost(-12.5, -12.5, 0, ewRedMat, ewAmberMat, ewGreenMat);
    buildCornerPost(12.5, 12.5, Math.PI, ewRedMat, ewAmberMat, ewGreenMat);
    buildCornerPost(12.5, -12.5, -Math.PI / 2, nsRedMat, nsAmberMat, nsGreenMat);
    buildCornerPost(-12.5, 12.5, Math.PI / 2, nsRedMat, nsAmberMat, nsGreenMat);

    worldGroup.add(tlGroup);
    trafficLights.push({
      id: tl.id,
      label: tl.label,
      x: tl.x,
      z: tl.z,
      phaseOffset: (idx % 2) * 10,
      ewRedMat,
      ewAmberMat,
      ewGreenMat,
      nsRedMat,
      nsAmberMat,
      nsGreenMat,
    });
  }

  // Reflective Cat's-Eye Studs & Roadside Speed-Reference Posts
  const studMat = new THREE.MeshStandardMaterial({
    color: 0xfde047,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.6,
    roughness: 0.35,
  });
  neonMaterials.push(studMat);
  const dummy = new THREE.Object3D();
  const studPositions: Array<[number, number]> = [];
  for (let p = -1400; p <= 1400; p += 22) {
    studPositions.push(
      [p, 140], [p, -210], [p, 580], [p, 1060], [p, -960],
      [160, p], [420, p], [-240, p], [-480, p], [-760, p],
    );
    if (p < 610 || p > 810) studPositions.push([-60, p]);
  }
  const studInst = new THREE.InstancedMesh(new THREE.BoxGeometry(0.28, 0.08, 0.48), studMat, studPositions.length);
  for (let i = 0; i < studPositions.length; i++) {
    dummy.position.set(studPositions[i][0], 0.085, studPositions[i][1]);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    studInst.setMatrixAt(i, dummy.matrix);
  }
  studInst.computeBoundingSphere();
  worldGroup.add(studInst);

  const postMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.45 });
  const postPositions: Array<[number, number]> = [];
  for (let p = -1360; p <= 1360; p += 38) {
    postPositions.push(
      [p, 128], [p, 152],
      [p, 568], [p, 592],
      [p, 1048], [p, 1072],
      [148, p], [172, p],
      [-252, p], [-228, p],
      [-492, p], [-468, p],
    );
  }
  const postInst = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.08, 0.1, 1.05, 6), postMat, postPositions.length);
  for (let i = 0; i < postPositions.length; i++) {
    dummy.position.set(postPositions[i][0], 0.52, postPositions[i][1]);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    postInst.setMatrixAt(i, dummy.matrix);
  }
  postInst.computeBoundingSphere();
  worldGroup.add(postInst);

  // Overhead Little Jaipur Urban Avenue Gantries
  const gantrySteelMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.3 });
  const addGantry = (gx: number, gz: number, rotY: number, signTex: THREE.CanvasTexture) => {
    const g = new THREE.Group();
    g.position.set(gx, 0, gz);
    g.rotation.y = rotY;
    for (const sx of [-11.5, 11.5]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.4, 8.8, 8), gantrySteelMat);
      col.position.set(sx, 4.4, 0);
      col.castShadow = true;
      g.add(col);
    }
    const truss = new THREE.Mesh(new THREE.BoxGeometry(24, 0.65, 0.65), gantrySteelMat);
    truss.position.set(0, 8.6, 0);
    const board = new THREE.Mesh(
      new THREE.BoxGeometry(13.5, 3.6, 0.35),
      new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.35, metalness: 0.15 }),
    );
    board.position.set(0, 8.4, 0);
    g.add(truss, board);
    worldGroup.add(g);
  };
  addGantry(40, 140, Math.PI / 2, textures.highwaySignNorth);
  addGantry(-350, 140, Math.PI / 2, textures.highwaySignSouth);
  addGantry(160, -490, 0, textures.highwaySignNorth);
  addGantry(160, 260, 0, textures.highwaySignSouth);
  addGantry(160, 960, 0, textures.airportSignMap);
  addGantry(-60, 490, 0, textures.highwaySignSouth);
  addGantry(420, 470, 0, textures.highwaySignNorth);

  // ============================================================================
  // 4D. ELEVATED JAIPUR METRO CORRIDOR (8 STATIONS) + ANIMATED METRO TRAIN
  // ============================================================================
  const metroPinkMat = new THREE.MeshStandardMaterial({
    color: 0xdb2777,
    emissive: 0xec4899,
    emissiveIntensity: 1.0,
    roughness: 0.35,
  });
  neonMaterials.push(metroPinkMat);

  {
    const metroViaductY = 9.2;
    const addViaductSeg = (x1: number, z1: number, x2: number, z2: number) => {
      const dx = x2 - x1;
      const dz = z2 - z1;
      const len = Math.hypot(dx, dz);
      const yaw = Math.atan2(dx, dz);
      const beam = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.9, len), concreteMat);
      beam.position.set((x1 + x2) / 2, metroViaductY, (z1 + z2) / 2);
      beam.rotation.y = yaw;
      worldGroup.add(beam);

      const railStrip = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.14, len), darkSteelMat);
      railStrip.position.set((x1 + x2) / 2, metroViaductY + 0.5, (z1 + z2) / 2);
      railStrip.rotation.y = yaw;
      worldGroup.add(railStrip);

      const pillars = Math.max(2, Math.floor(len / 46));
      for (let k = 0; k <= pillars; k++) {
        const t = k / pillars;
        const px = x1 + dx * t;
        const pz = z1 + dz * t;
        // Skip pillar if very close to road centerlines so cars never collide on intersections
        let nearRoad = false;
        for (const rx of JAIPUR_NS_ROADS) if (Math.abs(px - rx) < 12) nearRoad = true;
        for (const rz of JAIPUR_EW_ROADS) if (Math.abs(pz - rz) < 12) nearRoad = true;
        if (nearRoad) continue;
        const pier = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 1.05, metroViaductY - 0.3, 10), concreteMat);
        pier.position.set(px, (metroViaductY - 0.3) / 2, pz);
        worldGroup.add(pier);
        buildings.push({ minX: px - 1.1, maxX: px + 1.1, minZ: pz - 1.1, maxZ: pz + 1.1, height: metroViaductY });
      }
    };

    // Pink & Orange Line elevated corridor (strictly parallel to road edges without blocking lanes)
    addViaductSeg(-1020, 112, 195, 112);
    addViaductSeg(195, 112, 195, -236);
    addViaductSeg(195, -236, -268, -236);
    addViaductSeg(-268, -236, -268, -640);

    for (const st of JAIPUR_METRO_STATIONS) {
      const stGrp = new THREE.Group();
      stGrp.position.set(st.x, 0, st.z);
      const canopy = new THREE.Mesh(new THREE.BoxGeometry(22, 1.1, 8.5), whiteMarbleMat);
      canopy.position.y = metroViaductY + 3.4;
      const trim = new THREE.Mesh(new THREE.BoxGeometry(22.4, 0.55, 8.8), metroPinkMat);
      trim.position.y = metroViaductY + 2.8;
      const sign = new THREE.Mesh(
        new THREE.BoxGeometry(10, 2.2, 0.35),
        new THREE.MeshStandardMaterial({
          map: textures.metroSignMap,
          emissiveMap: textures.metroSignMap,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.45,
        }),
      );
      sign.position.set(0, 4.4, 3.8);
      const kiosk = new THREE.Mesh(new THREE.BoxGeometry(7.2, 4.2, 5.4), pinkHaveliMat);
      kiosk.position.set(0, 2.1, 0);
      stGrp.add(canopy, trim, sign, kiosk);
      worldGroup.add(stGrp);

      // Compute clear street-side entrance offset
      const eZ = st.z + (st.z === 112 ? 9.5 : 8.5);
      buildings.push({ minX: st.x - 3.8, maxX: st.x + 3.8, minZ: st.z - 2.9, maxZ: st.z + 2.9, height: 12 });
      blueprintBuildings.push({ x: st.x, z: st.z, w: 20, d: 8, kind: 'metro' });

      const ring = new THREE.Mesh(new THREE.TorusGeometry(2.8, 0.22, 8, 24), metroPinkMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(st.x, 0.22, eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id: st.id,
        name: st.name,
        category: 'metro',
        localityName: st.line,
        x: st.x,
        z: st.z,
        entryX: st.x,
        entryZ: eZ,
        accent: '#ec4899',
        brand: 'Jaipur Metro Rail (JMRC)',
        lootCash: 11500,
        canRob: true,
      });
    }
  }
  const metroTrain = buildMetroTrain();
  metroTrain.position.set(-420, 9.5, 112);
  worldGroup.add(metroTrain);

  // ============================================================================
  // 4E. JAIPUR BROAD-GAUGE RAILWAY CORRIDOR (z = 248) + 4 STATIONS + EXPRESS TRAIN
  // ============================================================================
  const railBlueMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7,
    emissive: 0x38bdf8,
    emissiveIntensity: 1.25,
    roughness: 0.35,
  });
  neonMaterials.push(railBlueMat);

  {
    const railZ = 248;
    const ballast = new THREE.Mesh(new THREE.BoxGeometry(2960, 0.14, 7.6), concreteMat);
    ballast.position.set(0, 0.04, railZ);
    ballast.receiveShadow = true;
    worldGroup.add(ballast);

    for (const rzOff of [-1.25, 1.25]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(2960, 0.16, 0.18), darkSteelMat);
      rail.position.set(0, 0.11, railZ + rzOff);
      worldGroup.add(rail);
    }

    const sleeperGeo = new THREE.BoxGeometry(0.45, 0.1, 4.2);
    const sleeperCount = 560;
    const sleeperInst = new THREE.InstancedMesh(sleeperGeo, terracottaMat, sleeperCount);
    for (let i = 0; i < sleeperCount; i++) {
      dummy.position.set(-1400 + i * 5, 0.08, railZ);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      sleeperInst.setMatrixAt(i, dummy.matrix);
    }
    sleeperInst.computeBoundingSphere();
    worldGroup.add(sleeperInst);

    for (const rs of JAIPUR_RAIL_STATIONS) {
      const stX = rs.x;
      const platZ = railZ - 11;
      const plat = new THREE.Mesh(new THREE.BoxGeometry(64, 1.15, 11), concreteMat);
      plat.position.set(stX, 0.58, platZ);
      const shed = new THREE.Mesh(new THREE.BoxGeometry(58, 0.45, 9.5), railBlueMat);
      shed.position.set(stX, 5.4, platZ);
      const concourse = new THREE.Mesh(new THREE.BoxGeometry(36, 7.5, 9), sandstoneMat);
      concourse.position.set(stX, 3.75, platZ - 7);
      const sign = new THREE.Mesh(
        new THREE.BoxGeometry(16, 3.0, 0.4),
        new THREE.MeshStandardMaterial({
          map: textures.railSignMap,
          emissiveMap: textures.railSignMap,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.5,
        }),
      );
      sign.position.set(stX, 6.2, platZ - 11.7);
      worldGroup.add(plat, shed, concourse, sign);

      const eZ = platZ - 15.5;
      buildings.push({ minX: stX - 18.5, maxX: stX + 18.5, minZ: platZ - 11.8, maxZ: platZ + 5.5, height: 8.5 });
      blueprintBuildings.push({ x: stX, z: platZ, w: 64, d: 16, kind: 'railway' });

      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.24, 8, 24), railBlueMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(stX, 0.22, eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id: rs.id,
        name: rs.name,
        category: 'railway',
        localityName: 'North Western Railway (NWR)',
        x: stX,
        z: platZ,
        entryX: stX,
        entryZ: eZ,
        accent: '#38bdf8',
        brand: 'Indian Railways · Jaipur Division',
        lootCash: 19000,
        canRob: true,
      });
    }
  }
  const expressTrain = buildIndianExpressTrain();
  expressTrain.position.set(-480, 0.14, 248);
  worldGroup.add(expressTrain);

  // ============================================================================
  // COLLISION / FOOTPRINT CHECKER + ENTERABLE INDIAN BUILDING BUILDER
  // ============================================================================
  const isBuildingFootprintClear = (bx: number, bz: number, halfW: number, halfD: number): boolean => {
    for (const rx of JAIPUR_NS_ROADS) {
      if (Math.abs(bx - rx) < halfW + 13.5) return false;
    }
    for (const rz of JAIPUR_EW_ROADS) {
      if (Math.abs(bz - rz) < halfD + 13.5) return false;
    }
    // Protect Railway track corridor z = 248 (except stations placed explicitly)
    if (Math.abs(bz - 248) < halfD + 12) return false;
    // Protect all 14 Jaipur Circles
    for (const c of JAIPUR_CIRCLES) {
      if (Math.hypot(bx - c.x, bz - c.z) < c.radius + Math.max(halfW, halfD) + 6) return false;
    }
    // Protect Police HQ Courtyard + Connector
    if (bx + halfW >= -34 && bx - halfW <= 14 && bz + halfD >= 28 && bz - halfD <= 140) return false;
    // Protect Man Sagar Lake, Ram Niwas, Central Park, SMS Stadium, City Parks & Dravyavati River
    if (bx + halfW >= 182 && bx - halfW <= 390 && bz + halfD >= -845 && bz - halfD <= -655) return false;
    if (bx + halfW >= -235 && bx - halfW <= 115 && bz + halfD >= 650 && bz - halfD <= 770) return false;
    if (bx + halfW >= 35 && bx - halfW <= 155 && bz + halfD >= 8 && bz - halfD <= 122) return false;
    if (bx + halfW >= -25 && bx - halfW <= 148 && bz + halfD >= 365 && bz - halfD <= 545) return false;
    if (bx + halfW >= 220 && bx - halfW <= 370 && bz + halfD >= 365 && bz - halfD <= 495) return false; // SMS Stadium
    if (bx + halfW >= -675 && bx - halfW <= -495 && bz + halfD >= 630 && bz - halfD <= 790) return false; // Mansarovar City Park
    if (bx + halfW >= -965 && bx - halfW <= -805 && bz + halfD >= 165 && bz - halfD <= 290) return false; // Vaishali Chitrakoot
    if (bx + halfW >= -675 && bx - halfW <= -515 && bz + halfD >= -540 && bz - halfD <= -410) return false; // Vidyadhar Stadium
    if (Math.hypot(bx - 160, bz - 840) < 74) return false;
    // Protect Jaipur International Airport Terminal, Apron & Runway 09/27
    if (bx + halfW >= 60 && bx - halfW <= 425 && bz + halfD >= 1072 && bz - halfD <= 1235) return false;
    for (const f of WORLD_FACILITIES) {
      if (Math.hypot(bx - f.x, bz - f.z) < 28 || Math.hypot(bx - f.entryX, bz - f.entryZ) < 18) return false;
    }
    for (const eb of enterableBuildings) {
      if (Math.hypot(bx - eb.x, bz - eb.z) < Math.max(halfW, halfD) + 16) return false;
    }
    return true;
  };

  const HOUSE_LOCAL_NAMES = [
    'Pink Courtyard Haveli',
    'Johari Residence & Verandah',
    'C-Scheme Villa',
    'Bapu Nagar Bungalow',
    'Raja Park Terrace Home',
    'Civil Lines Quarters',
    'Vaishali Family Flat',
    'Mansarovar Sector House',
    'Sodala Heritage Mansion',
    'Adarsh Nagar Kothi',
  ];
  let houseCounter = 1;

  type BuildingStyle = 'pink' | 'ochre' | 'blue' | 'white' | 'dhaba' | 'temple' | 'glass';
  const addIndianBuilding = (
    bx: number,
    bz: number,
    w: number,
    d: number,
    h: number,
    style: BuildingStyle,
    rotY = 0,
    forcePlace = false,
    registerEnterable = true,
  ) => {
    const swapped = Math.abs(Math.sin(rotY)) > 0.5;
    const halfW = swapped ? d / 2 : w / 2;
    const halfD = swapped ? w / 2 : d / 2;
    if (!forcePlace && !isBuildingFootprintClear(bx, bz, halfW, halfD)) {
      return;
    }

    const grp = new THREE.Group();
    grp.position.set(bx, 0, bz);
    grp.rotation.y = rotY;

    const wallMat =
      style === 'pink'
        ? pinkHaveliMat
        : style === 'glass'
          ? techGlassMat
          : style === 'white'
            ? whiteMarbleMat
            : sandstoneMat;

    const plinth = new THREE.Mesh(new THREE.BoxGeometry(w + 1.2, 0.9, d + 1.2), concreteMat);
    plinth.position.y = 0.45;
    plinth.receiveShadow = true;
    grp.add(plinth);

    const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
    body.position.y = 0.9 + h / 2;
    body.castShadow = !isSoftwareGl;
    body.receiveShadow = true;
    grp.add(body);

    const roofY = 0.9 + h;

    if (style !== 'glass') {
      const chhajja = new THREE.Mesh(new THREE.BoxGeometry(w + 1.6, 0.42, d + 1.6), terracottaMat);
      chhajja.position.y = roofY + 0.15;
      grp.add(chhajja);

      const parapet = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.95, d + 0.4), wallMat);
      parapet.position.y = roofY + 0.8;
      grp.add(parapet);
    }

    if (style === 'temple') {
      for (let tier = 0; tier < 4; tier++) {
        const tw = w * (0.68 - tier * 0.14);
        const td = d * (0.68 - tier * 0.14);
        const step = new THREE.Mesh(new THREE.BoxGeometry(tw, 2.2, td), goldenStoneMat);
        step.position.y = roofY + 1.4 + tier * 2.1;
        step.castShadow = !isSoftwareGl;
        grp.add(step);
      }
      const kalash = new THREE.Mesh(new THREE.SphereGeometry(0.95, 10, 8), warmLanternMat);
      kalash.position.y = roofY + 10.2;
      grp.add(kalash);
    } else if (style === 'pink' || style === 'ochre' || style === 'white') {
      const jharokha = new THREE.Mesh(new THREE.BoxGeometry(w * 0.42, 2.8, 1.4), goldenStoneMat);
      jharokha.position.set(0, Math.min(roofY - 2.2, 5.8), d / 2 + 0.65);
      grp.add(jharokha);

      const domeMat = style === 'white' ? whiteMarbleMat : goldenStoneMat;
      for (const sx of [-w * 0.34, w * 0.34]) {
        const dome = new THREE.Mesh(new THREE.SphereGeometry(1.4, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.58), domeMat);
        dome.position.set(sx, roofY + 2.5, 0);
        grp.add(dome);
        for (const px of [-0.9, 0.9]) {
          const col = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 1.6, 6), domeMat);
          col.position.set(sx + px, roofY + 1.7, 0);
          grp.add(col);
        }
      }
    } else if (style === 'dhaba') {
      const awning = new THREE.Mesh(new THREE.BoxGeometry(w + 1.4, 0.25, 3.4), terracottaMat);
      awning.position.set(0, 3.7, d / 2 + 1.6);
      awning.rotation.x = 0.2;
      const sign = new THREE.Mesh(new THREE.BoxGeometry(w * 0.84, 1.9, 0.35), shopSignMat);
      sign.position.set(0, 5.2, d / 2 + 0.25);
      grp.add(awning, sign);
      const tank = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.15, 1.8, 10), syntaxTankMat);
      tank.position.set(w * 0.25, roofY + 2.1, 0);
      grp.add(tank);
    }

    // Welcoming Amber Doorway Indicator facing front
    const doorMesh = new THREE.Mesh(
      new THREE.BoxGeometry(2.6, 3.2, 0.35),
      new THREE.MeshStandardMaterial({ color: 0x78350f, emissive: 0xd97706, emissiveIntensity: 0.35 }),
    );
    doorMesh.position.set(0, 2.2, d / 2 + 0.2);
    grp.add(doorMesh);

    worldGroup.add(grp);
    buildings.push({
      minX: bx - halfW,
      maxX: bx + halfW,
      minZ: bz - halfD,
      maxZ: bz + halfD,
      height: roofY + 3,
    });
    blueprintBuildings.push({
      x: bx,
      z: bz,
      w: halfW * 2,
      d: halfD * 2,
      kind: 'city',
    });

    if (registerEnterable) {
      const fwdX = Math.sin(rotY);
      const fwdZ = Math.cos(rotY);
      const entryX = bx + fwdX * (Math.max(halfW, halfD) + 3.8);
      const entryZ = bz + fwdZ * (Math.max(halfW, halfD) + 3.8);
      const cat: BuildingCategory = style === 'dhaba' ? 'grocery' : style === 'glass' ? 'office' : 'house';
      const label =
        cat === 'office'
          ? `Jaipur Business Hub #${houseCounter}`
          : cat === 'grocery'
            ? `Pink City Kirana & Mart #${houseCounter}`
            : `${HOUSE_LOCAL_NAMES[houseCounter % HOUSE_LOCAL_NAMES.length]} #${houseCounter}`;
      houseCounter++;
      enterableBuildings.push({
        id: `house_${houseCounter}`,
        name: label,
        category: cat,
        localityName: style === 'pink' ? 'Pink City Heritage Block' : 'Jaipur Urban Block',
        x: bx,
        z: bz,
        entryX,
        entryZ,
        accent: cat === 'office' ? '#38bdf8' : cat === 'grocery' ? '#10b981' : '#f59e0b',
        lootCash: cat === 'office' ? 14000 : cat === 'grocery' ? 8500 : 7200 + (houseCounter % 5) * 1500,
        canRob: true,
      });
    }
  };

  // Drive-through Rajasthani Pink Gate Archway
  const addDistrictGateArch = (gx: number, gz: number, span = 22, rotY = 0, mat = pinkSolidMat) => {
    const g = new THREE.Group();
    g.position.set(gx, 0, gz);
    g.rotation.y = rotY;
    const halfSpan = span / 2;

    for (const sx of [-halfSpan, halfSpan]) {
      const pier = new THREE.Mesh(new THREE.BoxGeometry(3.4, 10.5, 3.8), mat);
      pier.position.set(sx, 5.25, 0);
      pier.castShadow = !isSoftwareGl;
      const chhatri = new THREE.Mesh(new THREE.SphereGeometry(1.3, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.6), mat);
      chhatri.position.set(sx, 11.4, 0);
      g.add(pier, chhatri);

      const cos = Math.cos(rotY);
      const sin = Math.sin(rotY);
      const wx = gx + sx * cos;
      const wz = gz - sx * sin;
      buildings.push({ minX: wx - 1.9, maxX: wx + 1.9, minZ: wz - 1.9, maxZ: wz + 1.9, height: 12 });
    }
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(span + 4.2, 3.2, 4.0), mat);
    lintel.position.set(0, 10.8, 0);
    lintel.castShadow = !isSoftwareGl;
    const crown = new THREE.Mesh(new THREE.SphereGeometry(1.6, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.6), warmLanternMat);
    crown.position.set(0, 12.8, 0);
    g.add(lintel, crown);
    worldGroup.add(g);
  };

  // ============================================================================
  // 5. WALLED PINK CITY: PARKOTA WALLS, 6 GATES, HAWA MAHAL, CITY PALACE & JANTAR MANTAR
  // ============================================================================
  {
    const hawa = new THREE.Group();
    hawa.position.set(120, 0, -245);
    const tier1 = new THREE.Mesh(new THREE.BoxGeometry(46, 12.5, 13), pinkHaveliMat);
    tier1.position.y = 6.25;
    tier1.castShadow = !isSoftwareGl;
    const tier2 = new THREE.Mesh(new THREE.BoxGeometry(35, 10.0, 10.5), pinkHaveliMat);
    tier2.position.y = 17.5;
    tier2.castShadow = !isSoftwareGl;
    const tier3 = new THREE.Mesh(new THREE.BoxGeometry(22, 8.0, 8.5), pinkSolidMat);
    tier3.position.y = 26.2;
    hawa.add(tier1, tier2, tier3);
    for (let j = -15; j <= 15; j += 7.5) {
      const bay = new THREE.Mesh(new THREE.BoxGeometry(4.4, 9.6, 1.9), pinkSolidMat);
      bay.position.set(j, 11.2, 6.5);
      hawa.add(bay);
    }
    for (let d = -9; d <= 9; d += 4.5) {
      const dome = new THREE.Mesh(new THREE.SphereGeometry(2.1, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.6), goldenStoneMat);
      dome.position.set(d, 30.8, 0);
      hawa.add(dome);
    }
    worldGroup.add(hawa);
    buildings.push({ minX: 96, maxX: 144, minZ: -253, maxZ: -237, height: 32 });
    blueprintBuildings.push({ x: 120, z: -245, w: 46, d: 14, kind: 'landmark' });

    const cityPalace = new THREE.Group();
    cityPalace.position.set(35, 0, -280);
    const cpBase = new THREE.Mesh(new THREE.BoxGeometry(44, 11, 34), pinkHaveliMat);
    cpBase.position.y = 5.5;
    cpBase.castShadow = !isSoftwareGl;
    const cpMid = new THREE.Mesh(new THREE.BoxGeometry(24, 11, 20), pinkSolidMat);
    cpMid.position.y = 16.5;
    const cpTop = new THREE.Mesh(new THREE.BoxGeometry(12, 8, 12), whiteMarbleMat);
    cpTop.position.y = 26;
    const cpCrown = new THREE.Mesh(new THREE.SphereGeometry(4.2, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.6), goldenStoneMat);
    cpCrown.position.y = 30.2;
    cityPalace.add(cpBase, cpMid, cpTop, cpCrown);
    worldGroup.add(cityPalace);
    buildings.push({ minX: 12, maxX: 58, minZ: -298, maxZ: -262, height: 32 });
    blueprintBuildings.push({ x: 35, z: -280, w: 44, d: 34, kind: 'landmark' });

    const jantar = new THREE.Group();
    jantar.position.set(80, 0, -284);
    const jmPlinth = new THREE.Mesh(new THREE.BoxGeometry(22, 1.2, 22), whiteMarbleMat);
    jmPlinth.position.y = 0.6;
    const gnomon = new THREE.Mesh(new THREE.BoxGeometry(3.2, 16, 18), goldenStoneMat);
    gnomon.position.set(0, 7.5, 0);
    gnomon.rotation.x = -0.45;
    gnomon.castShadow = !isSoftwareGl;
    const dialWing = new THREE.Mesh(new THREE.CylinderGeometry(8.5, 8.5, 1.4, 16, 1, false, 0, Math.PI), whiteMarbleMat);
    dialWing.rotation.z = Math.PI / 2;
    dialWing.position.set(0, 4.5, 4);
    jantar.add(jmPlinth, gnomon, dialWing);
    worldGroup.add(jantar);
    buildings.push({ minX: 69, maxX: 91, minZ: -295, maxZ: -273, height: 16 });
    blueprintBuildings.push({ x: 80, z: -284, w: 22, d: 22, kind: 'landmark' });

    // 6 Iconic Pink City Drive-Through Heritage Gates
    addDistrictGateArch(-240, -210, 22, Math.PI / 2, pinkSolidMat);
    addDistrictGateArch(12, -210, 22, Math.PI / 2, pinkSolidMat);
    addDistrictGateArch(420, -210, 22, Math.PI / 2, pinkSolidMat);
    addDistrictGateArch(-60, -40, 22, 0, pinkSolidMat);
    addDistrictGateArch(160, -40, 22, 0, pinkSolidMat);
    addDistrictGateArch(160, -380, 22, 0, pinkSolidMat);

    const addWallSeg = (x1: number, z1: number, x2: number, z2: number) => {
      const len = Math.hypot(x2 - x1, z2 - z1);
      if (len < 6) return;
      const cx = (x1 + x2) / 2;
      const cz = (z1 + z2) / 2;
      const isHoriz = Math.abs(x2 - x1) > Math.abs(z2 - z1);
      const w = isHoriz ? len : 4.2;
      const d = isHoriz ? 4.2 : len;
      const wall = new THREE.Mesh(new THREE.BoxGeometry(w, 6.2, d), pinkSolidMat);
      wall.position.set(cx, 3.1, cz);
      wall.castShadow = !isSoftwareGl;
      worldGroup.add(wall);
      buildings.push({ minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2, height: 6.5 });
    };
    addWallSeg(-225, -54, -76, -54);
    addWallSeg(-44, -54, 144, -54);
    addWallSeg(176, -54, 405, -54);
    addWallSeg(-225, -366, -76, -366);
    addWallSeg(-44, -366, 144, -366);
    addWallSeg(176, -366, 405, -366);

    const pinkBlocks: Array<[number, number, number, number, number, BuildingStyle]> = [
      [115, -135, 28, 22, 13, 'pink'],
      [205, -135, 28, 22, 14, 'pink'],
      [260, -135, 24, 22, 13, 'pink'],
      [260, -255, 24, 20, 14, 'ochre'],
      [330, -135, 24, 20, 12, 'pink'],
      [330, -255, 24, 20, 11, 'temple'],
      [-15, -135, 26, 20, 12, 'pink'],
      [-105, -135, 24, 20, 12, 'pink'],
      [-185, -135, 24, 20, 11, 'dhaba'],
      [-155, -260, 26, 22, 13, 'pink'],
      [-105, -320, 26, 20, 12, 'ochre'],
      [240, -320, 26, 20, 13, 'pink'],
    ];
    for (const [bx, bz, bw, bd, bh, st] of pinkBlocks) {
      addIndianBuilding(bx, bz, bw, bd, bh, st, 0, false);
    }
  }

  // ============================================================================
  // 6. CENTRAL LANDMARKS, SMS CRICKET STADIUM, PARKS & PLAYGROUNDS
  // ============================================================================
  {
    // Albert Hall Museum in Ram Niwas Bagh
    const albert = new THREE.Group();
    albert.position.set(102, 0, 56);
    const ahBase = new THREE.Mesh(new THREE.BoxGeometry(46, 9, 24), sandstoneMat);
    ahBase.position.y = 4.5;
    ahBase.castShadow = !isSoftwareGl;
    const ahCenter = new THREE.Mesh(new THREE.BoxGeometry(16, 14, 16), goldenStoneMat);
    ahCenter.position.y = 9.5;
    const ahMainDome = new THREE.Mesh(new THREE.SphereGeometry(5.5, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), whiteMarbleMat);
    ahMainDome.position.y = 16.5;
    albert.add(ahBase, ahCenter, ahMainDome);
    for (const sx of [-18, 18]) {
      const tower = new THREE.Mesh(new THREE.BoxGeometry(7, 13, 7), goldenStoneMat);
      tower.position.set(sx, 6.5, 0);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(2.6, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.6), whiteMarbleMat);
      dome.position.set(sx, 13.5, 0);
      albert.add(tower, dome);
    }
    worldGroup.add(albert);
    buildings.push({ minX: 78, maxX: 126, minZ: 43, maxZ: 69, height: 22 });
    blueprintBuildings.push({ x: 102, z: 56, w: 46, d: 24, kind: 'landmark' });

    // Raj Mandir Cinema Art-Deco Meringue Facade
    addIndianBuilding(-135, 92, 34, 24, 16, 'pink', 0, false);

    // Vidhan Sabha (Rajasthan Assembly Dome)
    const vs = new THREE.Group();
    vs.position.set(-135, 0, 455);
    const vsBody = new THREE.Mesh(new THREE.BoxGeometry(52, 15, 36), sandstoneMat);
    vsBody.position.y = 7.5;
    vsBody.castShadow = !isSoftwareGl;
    const vsDome = new THREE.Mesh(new THREE.SphereGeometry(10.5, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.58), pinkHaveliMat);
    vsDome.position.y = 15;
    vs.add(vsBody, vsDome);
    worldGroup.add(vs);
    buildings.push({ minX: -162, maxX: -108, minZ: 436, maxZ: 474, height: 26 });
    blueprintBuildings.push({ x: -135, z: 455, w: 52, d: 36, kind: 'landmark' });

    // SAWAI MANSINGH (SMS) CRICKET STADIUM (x = 295, z = 435)
    {
      const sx = 295;
      const sz = 435;
      const sms = new THREE.Group();
      sms.position.set(sx, 0, sz);

      const turf = new THREE.Mesh(new THREE.CylinderGeometry(52, 52, 0.2, 32), pitchTurfMat);
      turf.scale.set(1.22, 1, 0.92);
      turf.position.y = 0.12;
      const pitch = new THREE.Mesh(new THREE.BoxGeometry(16, 0.25, 4.2), goldenStoneMat);
      pitch.position.y = 0.18;
      const bowlOuter = new THREE.Mesh(
        new THREE.CylinderGeometry(62, 58, 14, 28, 1, true),
        sandstoneMat,
      );
      bowlOuter.scale.set(1.22, 1, 0.92);
      bowlOuter.position.y = 7;
      const bowlRim = new THREE.Mesh(new THREE.TorusGeometry(58, 2.8, 8, 28), whiteMarbleMat);
      bowlRim.rotation.x = Math.PI / 2;
      bowlRim.scale.set(1.22, 0.92, 1);
      bowlRim.position.y = 14.2;
      const signBoard = new THREE.Mesh(
        new THREE.BoxGeometry(26, 4.2, 0.5),
        new THREE.MeshStandardMaterial({
          map: textures.stadiumSignMap,
          emissiveMap: textures.stadiumSignMap,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.55,
        }),
      );
      signBoard.position.set(0, 11.5, -52);
      sms.add(turf, pitch, bowlOuter, bowlRim, signBoard);

      const floodMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: 0xfef9c3,
        emissiveIntensity: 2.6,
      });
      neonMaterials.push(floodMat);
      for (const [fx, fz] of [
        [-58, -36],
        [58, -36],
        [-58, 36],
        [58, 36],
      ]) {
        const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 1.0, 34, 8), darkSteelMat);
        mast.position.set(fx, 17, fz);
        const head = new THREE.Mesh(new THREE.BoxGeometry(8, 3.8, 1.4), floodMat);
        head.position.set(fx, 33.5, fz);
        head.lookAt(0, 2, 0);
        sms.add(mast, head);
      }

      worldGroup.add(sms);
      buildings.push({ minX: sx - 64, maxX: sx + 64, minZ: sz - 50, maxZ: sz + 50, height: 18 });
      blueprintBuildings.push({ x: sx, z: sz, w: 126, d: 96, kind: 'stadium' });

      const eX = sx - 72;
      const eZ = sz;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.4, 0.25, 8, 24), floodMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(eX, 0.22, eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id: 'sms_stadium',
        name: 'Sawai Mansingh (SMS) Cricket Stadium',
        category: 'stadium',
        localityName: 'JLN Marg Sports Complex',
        x: sx,
        z: sz,
        entryX: eX,
        entryZ: eZ,
        accent: '#22c55e',
        brand: 'Rajasthan Cricket Association',
        lootCash: 32000,
        canRob: true,
      });
    }

    // Birla Mandir & Moti Dungri Castle Hill cleanly south of SMS Stadium
    addIndianBuilding(230, 535, 28, 24, 15, 'temple', 0, true, false);
    const birlaMarble = new THREE.Mesh(new THREE.BoxGeometry(24, 9, 20), whiteMarbleMat);
    birlaMarble.position.set(230, 20, 535);
    worldGroup.add(birlaMarble);

    const motiHill = new THREE.Mesh(new THREE.ConeGeometry(24, 18, 7), hillMat);
    motiHill.position.set(345, 9, 535);
    const motiKeep = new THREE.Mesh(new THREE.BoxGeometry(14, 9, 14), goldenStoneMat);
    motiKeep.position.set(345, 20, 535);
    worldGroup.add(motiHill, motiKeep);
    buildings.push({ minX: 325, maxX: 365, minZ: 515, maxZ: 555, height: 26 });
    blueprintBuildings.push({ x: 345, z: 535, w: 28, d: 28, kind: 'landmark' });

    // Central Park Playground & Basketball Court (15, 505) + Vaishali & Mansarovar Playgrounds
    const addPlayground = (px: number, pz: number) => {
      const pg = new THREE.Group();
      pg.position.set(px, 0, pz);
      const court = new THREE.Mesh(new THREE.PlaneGeometry(24, 15), new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.85 }));
      court.rotation.x = -Math.PI / 2;
      court.position.y = 0.04;
      pg.add(court);
      for (const hx of [-11, 11]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 3.6, 8), darkSteelMat);
        post.position.set(hx, 1.8, 0);
        const board = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.1, 1.6), whiteMarbleMat);
        board.position.set(hx * 0.95, 3.2, 0);
        pg.add(post, board);
      }
      // Swing set & slide beside court
      for (const sx of [-3, 3]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 3.2, 6), terracottaMat);
        leg.position.set(sx, 1.6, 12);
        pg.add(leg);
      }
      const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 6.6, 6), terracottaMat);
      bar.rotation.z = Math.PI / 2;
      bar.position.set(0, 3.2, 12);
      const slide = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.25, 4.5), new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.4 }));
      slide.position.set(7.5, 1.4, 12);
      slide.rotation.x = 0.45;
      pg.add(bar, slide);
      worldGroup.add(pg);
    };
    addPlayground(35, 505);
    addPlayground(-885, 225);
    addPlayground(-585, 710);
    addPlayground(-595, -475);
  }

  // ============================================================================
  // 7. NORTH JAIPUR: AMER FORT & NAHARGARH FORT CITADELS
  // ============================================================================
  {
    const amer = new THREE.Group();
    amer.position.set(225, 0, -1035);
    const cliff = new THREE.Mesh(new THREE.BoxGeometry(74, 18, 44), hillMat);
    cliff.position.y = 9;
    const citadel = new THREE.Mesh(new THREE.BoxGeometry(58, 16, 32), goldenStoneMat);
    citadel.position.y = 26;
    citadel.castShadow = !isSoftwareGl;
    const sheeshMahal = new THREE.Mesh(new THREE.BoxGeometry(22, 9, 16), whiteMarbleMat);
    sheeshMahal.position.y = 38;
    amer.add(cliff, citadel, sheeshMahal);
    for (const bx of [-26, 0, 26]) {
      const bastion = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 5.2, 34, 10), goldenStoneMat);
      bastion.position.set(bx, 17, 16);
      amer.add(bastion);
    }
    worldGroup.add(amer);
    buildings.push({ minX: 186, maxX: 264, minZ: -1058, maxZ: -1012, height: 42 });
    blueprintBuildings.push({ x: 225, z: -1035, w: 74, d: 44, kind: 'landmark' });

    const nahar = new THREE.Group();
    nahar.position.set(-165, 0, -1035);
    const nCliff = new THREE.Mesh(new THREE.BoxGeometry(62, 22, 40), ridgeMat);
    nCliff.position.y = 11;
    const nFort = new THREE.Mesh(new THREE.BoxGeometry(46, 13, 28), sandstoneMat);
    nFort.position.y = 28;
    nFort.castShadow = !isSoftwareGl;
    nahar.add(nCliff, nFort);
    worldGroup.add(nahar);
    buildings.push({ minX: -198, maxX: -132, minZ: -1056, maxZ: -1014, height: 38 });
    blueprintBuildings.push({ x: -165, z: -1035, w: 62, d: 40, kind: 'landmark' });
  }

  // ============================================================================
  // 8. SOUTH JAIPUR: DRAVYAVATI CABLE FLYOVER, WORLD TRADE PARK & PATRIKA GATE
  // ============================================================================
  {
    const deck = new THREE.Mesh(new THREE.BoxGeometry(18, 0.9, 112), concreteMat);
    deck.position.set(-60, 7.05, 710);
    deck.receiveShadow = true;
    deck.castShadow = !isSoftwareGl;
    worldGroup.add(deck);

    const makeBridgeSlope = (zCenter: number, tiltX: number) => {
      const slope = new THREE.Mesh(new THREE.BoxGeometry(18, 0.8, 52), concreteMat);
      slope.position.set(-60, 3.7, zCenter);
      slope.rotation.x = tiltX;
      slope.receiveShadow = true;
      worldGroup.add(slope);
    };
    makeBridgeSlope(785, 0.145);
    makeBridgeSlope(635, -0.145);

    for (const pylonZ of [672, 748]) {
      const pylonGroup = new THREE.Group();
      pylonGroup.position.set(-60, 0, pylonZ);
      for (const sx of [-9.5, 9.5]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.4, 42, 10), concreteMat);
        leg.position.set(sx, 21, 0);
        pylonGroup.add(leg);
      }
      const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(20, 2.2, 2.2), concreteMat);
      crossBeam.position.set(0, 34, 0);
      pylonGroup.add(crossBeam);

      for (let c = 1; c <= 4; c++) {
        for (const dirZ of [-1, 1]) {
          for (const sx of [-9.2, 9.2]) {
            const anchorZ = dirZ * c * 7.5;
            const topY = 40 - c * 1.6;
            const dy = topY - 7.5;
            const len = Math.sqrt(dy * dy + anchorZ * anchorZ);
            const cable = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, len, 6), cableMat);
            cable.position.set(sx, (topY + 7.5) / 2, anchorZ / 2);
            cable.quaternion.setFromUnitVectors(
              new THREE.Vector3(0, 1, 0),
              new THREE.Vector3(0, dy, -anchorZ).normalize(),
            );
            pylonGroup.add(cable);
          }
        }
      }
      worldGroup.add(pylonGroup);
    }

    const wtp = new THREE.Group();
    wtp.position.set(482, 0, 515);
    const wtpBase = new THREE.Mesh(new THREE.BoxGeometry(58, 12, 34), techGlassMat);
    wtpBase.position.y = 6;
    wtpBase.castShadow = !isSoftwareGl;
    const pyrLeft = new THREE.Mesh(new THREE.ConeGeometry(16, 26, 4), techGlassMat);
    pyrLeft.position.set(-14, 24, 0);
    pyrLeft.rotation.y = Math.PI / 4;
    const pyrRight = new THREE.Mesh(new THREE.ConeGeometry(16, 26, 4), techGlassMat);
    pyrRight.position.set(14, 24, 0);
    pyrRight.rotation.y = Math.PI / 4;
    const skyBridge = new THREE.Mesh(new THREE.BoxGeometry(24, 4, 8), techGlassMat);
    skyBridge.position.set(0, 19, 0);
    wtp.add(wtpBase, pyrLeft, pyrRight, skyBridge);
    worldGroup.add(wtp);
    buildings.push({ minX: 452, maxX: 512, minZ: 497, maxZ: 533, height: 38 });
    blueprintBuildings.push({ x: 482, z: 515, w: 58, d: 34, kind: 'landmark' });

    addDistrictGateArch(160, 792, 24, 0, pinkHaveliMat);
  }

  // ============================================================================
  // 9. JAIPUR POLICE COMMISSIONERATE HQ & HELIPAD (x = -10, z = 48, Gate z = 82)
  // ============================================================================
  {
    const px = POLICE_STATION.x;
    const pz = POLICE_STATION.z;
    const gateZ = POLICE_STATION.gateZ;
    const stationGroup = new THREE.Group();

    const apronMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.78, metalness: 0.08 });
    const courtyard = new THREE.Mesh(new THREE.PlaneGeometry(34, 42), apronMat);
    courtyard.rotation.x = -Math.PI / 2;
    courtyard.position.set(px, 0.03, pz + 16);
    courtyard.receiveShadow = true;
    stationGroup.add(courtyard);

    const stationWallMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.65, metalness: 0.08 });
    const policeNavyMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.45, metalness: 0.2 });
    const policeRedMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0xef4444, emissiveIntensity: 1.8 });
    const policeBlueGlowMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, emissive: 0x3b82f6, emissiveIntensity: 1.8 });
    neonMaterials.push(policeRedMat, policeBlueGlowMat);

    const mainHall = new THREE.Mesh(new THREE.BoxGeometry(24, 10.5, 13), stationWallMat);
    mainHall.position.set(px, 5.25, pz);
    mainHall.castShadow = !isSoftwareGl;
    mainHall.receiveShadow = true;
    stationGroup.add(mainHall);

    const navyBand = new THREE.Mesh(new THREE.BoxGeometry(24.4, 1.4, 13.4), policeNavyMat);
    navyBand.position.set(px, 9.6, pz);
    const redStripe = new THREE.Mesh(new THREE.BoxGeometry(24.5, 0.45, 13.5), policeRedMat);
    redStripe.position.set(px, 8.7, pz);
    stationGroup.add(navyBand, redStripe);

    const helipadRing = new THREE.Mesh(
      new THREE.RingGeometry(4.2, 4.9, 24),
      new THREE.MeshBasicMaterial({ color: 0xfacc15, side: THREE.DoubleSide }),
    );
    helipadRing.rotation.x = -Math.PI / 2;
    helipadRing.position.set(px, 10.6, pz);
    const hLeft = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 4.2), whiteMarbleMat);
    hLeft.position.set(px - 1.3, 10.6, pz);
    const hRight = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 4.2), whiteMarbleMat);
    hRight.position.set(px + 1.3, 10.6, pz);
    const hBar = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.08, 0.7), whiteMarbleMat);
    hBar.position.set(px, 10.6, pz);
    stationGroup.add(helipadRing, hLeft, hRight, hBar);

    const canopy = new THREE.Mesh(new THREE.BoxGeometry(10, 0.6, 4.4), policeNavyMat);
    canopy.position.set(px, 4.2, pz + 8.4);
    stationGroup.add(canopy);
    for (const sx of [-4.2, 4.2]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 4.0, 8), stationWallMat);
      col.position.set(px + sx, 2.0, pz + 10.0);
      stationGroup.add(col);
    }

    const signBoard = new THREE.Mesh(
      new THREE.BoxGeometry(12.2, 3.4, 0.4),
      new THREE.MeshStandardMaterial({
        map: textures.policeStationSign,
        emissiveMap: textures.policeStationSign,
        emissive: new THREE.Color(0xffffff),
        emissiveIntensity: 0.65,
        roughness: 0.3,
      }),
    );
    signBoard.position.set(px, 6.5, pz + 6.7);
    stationGroup.add(signBoard);

    const beaconRed = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.75, 0.9, 10), policeRedMat);
    beaconRed.position.set(px - 6.5, 10.95, pz + 4.5);
    const beaconBlue = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.75, 0.9, 10), policeBlueGlowMat);
    beaconBlue.position.set(px + 6.5, 10.95, pz + 4.5);
    stationGroup.add(beaconRed, beaconBlue);

    for (const gx of [-6.0, 6.0]) {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(1.7, 5.8, 1.7), stationWallMat);
      pillar.position.set(px + gx, 2.9, gateZ);
      const cap = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.4, 2.0), policeNavyMat);
      cap.position.set(px + gx, 5.9, gateZ);
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.42, 8, 8), gx < 0 ? policeRedMat : policeBlueGlowMat);
      lamp.position.set(px + gx, 6.45, gateZ);
      stationGroup.add(pillar, cap, lamp);
      buildings.push({ minX: px + gx - 0.9, maxX: px + gx + 0.9, minZ: gateZ - 0.9, maxZ: gateZ + 0.9, height: 6.5 });
    }

    for (const side of [-1, 1]) {
      const wingWall = new THREE.Mesh(new THREE.BoxGeometry(9.0, 2.8, 0.8), stationWallMat);
      wingWall.position.set(px + side * 11.4, 1.4, gateZ);
      const sideWall = new THREE.Mesh(new THREE.BoxGeometry(0.8, 2.8, 34), stationWallMat);
      sideWall.position.set(px + side * 15.6, 1.4, gateZ - 17);
      stationGroup.add(wingWall, sideWall);
      buildings.push({
        minX: px + side * 11.4 - 4.5,
        maxX: px + side * 11.4 + 4.5,
        minZ: gateZ - 0.45,
        maxZ: gateZ + 0.45,
        height: 2.8,
      });
    }

    worldGroup.add(stationGroup);
    buildings.push({ minX: px - 12.2, maxX: px + 12.2, minZ: pz - 6.7, maxZ: pz + 6.7, height: 11.5 });
    blueprintBuildings.push({ x: px, z: pz, w: 24, d: 13, kind: 'police' });
  }

  // ============================================================================
  // 10. WORKING BANKS, HOSPITALS & C-SCHEME PLAYER HOME
  // ============================================================================
  {
    const bankGreenMat = new THREE.MeshStandardMaterial({ color: 0x059669, emissive: 0x10b981, emissiveIntensity: 1.4, roughness: 0.35 });
    const hospRedMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0xef4444, emissiveIntensity: 1.6, roughness: 0.3 });
    const homeGoldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xd97706, emissiveIntensity: 1.4, roughness: 0.32 });
    const tealGlassMat = new THREE.MeshStandardMaterial({ color: 0x0f766e, roughness: 0.18, metalness: 0.7 });
    neonMaterials.push(bankGreenMat, hospRedMat, homeGoldMat);

    for (const fac of WORLD_FACILITIES) {
      if (fac.type === 'airport') continue;
      const grp = new THREE.Group();
      const faceDir = fac.entryX >= fac.x ? 1 : -1;

      const apron = new THREE.Mesh(
        new THREE.PlaneGeometry(34, 28),
        new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.9, metalness: 0.0 }),
      );
      apron.rotation.x = -Math.PI / 2;
      apron.position.set((fac.x + fac.entryX) / 2, 0.025, fac.z);
      apron.receiveShadow = true;
      grp.add(apron);

      const buildingGrp = new THREE.Group();
      buildingGrp.position.set(fac.x, 0, fac.z);

      if (fac.type === 'bank') {
        const plinth = new THREE.Mesh(new THREE.BoxGeometry(20, 0.9, 20), concreteMat);
        plinth.position.y = 0.45;
        const body = new THREE.Mesh(new THREE.BoxGeometry(18, 10.5, 18), whiteMarbleMat);
        body.position.y = 6.15;
        body.castShadow = !isSoftwareGl;
        const vaultTrim = new THREE.Mesh(new THREE.BoxGeometry(18.5, 1.1, 18.5), bankGreenMat);
        vaultTrim.position.y = 11.2;
        const glassBand = new THREE.Mesh(new THREE.BoxGeometry(18.2, 3.2, 14), tealGlassMat);
        glassBand.position.y = 4.2;
        const vaultDome = new THREE.Mesh(new THREE.SphereGeometry(3.4, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.58), goldenStoneMat);
        vaultDome.position.y = 11.8;
        const sign = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, 2.8, 11),
          new THREE.MeshStandardMaterial({
            map: textures.bankSignMap,
            emissiveMap: textures.bankSignMap,
            emissive: new THREE.Color(0xffffff),
            emissiveIntensity: 0.45,
            roughness: 0.35,
          }),
        );
        sign.position.set(faceDir * 9.25, 8.2, 0);
        const atm = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.5, 1.8), bankGreenMat);
        atm.position.set(faceDir * 10.2, 1.25, 5.5);
        buildingGrp.add(plinth, body, vaultTrim, glassBand, vaultDome, sign, atm);
        buildings.push({ minX: fac.x - 9.6, maxX: fac.x + 9.6, minZ: fac.z - 9.6, maxZ: fac.z + 9.6, height: 14 });
        blueprintBuildings.push({ x: fac.x, z: fac.z, w: 18, d: 18, kind: 'bank' });
      } else if (fac.type === 'hospital') {
        const plinth = new THREE.Mesh(new THREE.BoxGeometry(22, 0.9, 22), concreteMat);
        plinth.position.y = 0.45;
        const body = new THREE.Mesh(new THREE.BoxGeometry(20, 12.5, 20), whiteMarbleMat);
        body.position.y = 7.15;
        body.castShadow = !isSoftwareGl;
        const redBand = new THREE.Mesh(new THREE.BoxGeometry(20.5, 0.85, 20.5), hospRedMat);
        redBand.position.y = 12.8;
        const canopy = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.65, 9), whiteMarbleMat);
        canopy.position.set(faceDir * 12.2, 4.2, 0);
        const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.5, 3.2, 1.0), hospRedMat);
        crossV.position.set(faceDir * 10.25, 10.2, 0);
        const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.0, 3.2), hospRedMat);
        crossH.position.set(faceDir * 10.25, 10.2, 0);
        const roofCrossV = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.2, 5.2), hospRedMat);
        roofCrossV.position.set(0, 13.6, 0);
        const roofCrossH = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.2, 1.4), hospRedMat);
        roofCrossH.position.set(0, 13.6, 0);
        const sign = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, 2.8, 12),
          new THREE.MeshStandardMaterial({
            map: textures.hospitalSignMap,
            emissiveMap: textures.hospitalSignMap,
            emissive: new THREE.Color(0xffffff),
            emissiveIntensity: 0.45,
            roughness: 0.35,
          }),
        );
        sign.position.set(faceDir * 10.25, 6.4, 0);
        buildingGrp.add(plinth, body, redBand, canopy, crossV, crossH, roofCrossV, roofCrossH, sign);
        buildings.push({ minX: fac.x - 10.6, maxX: fac.x + 10.6, minZ: fac.z - 10.6, maxZ: fac.z + 10.6, height: 15 });
        blueprintBuildings.push({ x: fac.x, z: fac.z, w: 20, d: 20, kind: 'hospital' });
      } else {
        const plinth = new THREE.Mesh(new THREE.BoxGeometry(20, 0.85, 22), concreteMat);
        plinth.position.y = 0.42;
        const villaBody = new THREE.Mesh(new THREE.BoxGeometry(17, 9.5, 19), pinkHaveliMat);
        villaBody.position.y = 5.6;
        villaBody.castShadow = !isSoftwareGl;
        const cornice = new THREE.Mesh(new THREE.BoxGeometry(18.4, 0.45, 20.4), terracottaMat);
        cornice.position.y = 10.5;
        const dome = new THREE.Mesh(new THREE.SphereGeometry(2.6, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.58), goldenStoneMat);
        dome.position.y = 11.4;
        const carportRoof = new THREE.Mesh(new THREE.BoxGeometry(6.5, 0.35, 9.5), goldenStoneMat);
        carportRoof.position.set(faceDir * 11.2, 4.1, 4.2);
        for (const pzOff of [0.2, 8.2]) {
          const post = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.25, 4.0, 8), whiteMarbleMat);
          post.position.set(faceDir * 13.8, 2.0, pzOff);
          buildingGrp.add(post);
        }
        const sign = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, 2.5, 11),
          new THREE.MeshStandardMaterial({
            map: textures.homeSignMap,
            emissiveMap: textures.homeSignMap,
            emissive: new THREE.Color(0xffffff),
            emissiveIntensity: 0.45,
            roughness: 0.35,
          }),
        );
        sign.position.set(faceDir * 8.75, 7.2, -2);
        buildingGrp.add(plinth, villaBody, cornice, dome, carportRoof, sign);
        buildings.push({ minX: fac.x - 9.0, maxX: fac.x + 9.0, minZ: fac.z - 10.0, maxZ: fac.z + 10.0, height: 14 });
        blueprintBuildings.push({ x: fac.x, z: fac.z, w: 17, d: 19, kind: 'home' });
      }

      const ringMat = fac.type === 'bank' ? bankGreenMat : fac.type === 'hospital' ? hospRedMat : homeGoldMat;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.2, 0.24, 8, 28), ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(fac.entryX, 0.22, fac.entryZ);
      facilityRings.push(ring);

      grp.add(buildingGrp, ring);
      worldGroup.add(grp);
    }
  }

  // ============================================================================
  // 10B. FIRE BRIGADE STATIONS, 6 PETROL PUMPS, 5 BRAND VEHICLE SHOWROOMS,
  //      AMMUNATION, CLOTH, BARBER, DMART, DECATHLON, PAAN, GROCERY, HOTELS, SCHOOLS, OFFICES & ALL STORES
  // ============================================================================
  const fireHqPos = { x: 485, z: -15 };
  {
    const fireRedMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0xef4444, emissiveIntensity: 1.5 });
    const petrolOrangeMat = new THREE.MeshStandardMaterial({ color: 0xea580c, emissive: 0xf97316, emissiveIntensity: 1.2 });
    const ammoMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, emissive: 0xeab308, emissiveIntensity: 0.9 });
    neonMaterials.push(fireRedMat, petrolOrangeMat);

    const spawnFireStation = (id: string, name: string, loc: string, fx: number, fz: number, eX: number, eZ: number) => {
      const grp = new THREE.Group();
      grp.position.set(fx, 0, fz);
      const bay = new THREE.Mesh(new THREE.BoxGeometry(24, 9.5, 16), whiteMarbleMat);
      bay.position.y = 4.75;
      bay.castShadow = !isSoftwareGl;
      const redTrim = new THREE.Mesh(new THREE.BoxGeometry(24.5, 1.4, 16.5), fireRedMat);
      redTrim.position.y = 9.2;
      const drillTower = new THREE.Mesh(new THREE.BoxGeometry(6, 18, 6), pinkSolidMat);
      drillTower.position.set(-9, 9, -4);
      const sign = new THREE.Mesh(
        new THREE.BoxGeometry(16, 3.4, 0.4),
        new THREE.MeshStandardMaterial({
          map: textures.fireStationSignMap,
          emissiveMap: textures.fireStationSignMap,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.55,
        }),
      );
      sign.position.set(0, 7.2, -8.25);
      // 2 Red Fire Garage Bay Doors
      for (const gx of [-5, 5]) {
        const door = new THREE.Mesh(new THREE.BoxGeometry(6.5, 5.8, 0.35), fireRedMat);
        door.position.set(gx, 2.9, -8.1);
        grp.add(door);
      }
      grp.add(bay, redTrim, drillTower, sign);
      worldGroup.add(grp);

      buildings.push({ minX: fx - 12.5, maxX: fx + 12.5, minZ: fz - 8.5, maxZ: fz + 8.5, height: 18 });
      blueprintBuildings.push({ x: fx, z: fz, w: 24, d: 16, kind: 'fire' });

      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.2, 0.25, 8, 24), fireRedMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(eX, 0.22, eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id,
        name,
        category: 'fire_station',
        localityName: loc,
        x: fx,
        z: fz,
        entryX: eX,
        entryZ: eZ,
        accent: '#ef4444',
        brand: 'Nagar Nigam Jaipur Fire Brigade',
        lootCash: 0,
        canRob: false,
      });
    };
    spawnFireStation('fire_ghat_gate', 'Jaipur Fire Brigade HQ (Ghat Gate)', 'Ghat Gate · Agra Rd', 485, -15, 485, -27);
    spawnFireStation('fire_bais_godam', 'Bais Godam Fire Sub-Station', 'Sodala · Civil Lines', -315, 395, -315, 378);

    // 6 Working IndianOil / HP Petrol Pumps across Jaipur
    const petrolSites: Array<{ id: string; name: string; loc: string; x: number; z: number; eX: number; eZ: number }> = [
      { id: 'petrol_mi', name: 'IndianOil · MI Road Pump', loc: 'MI Road · Panch Batti', x: -102, z: 96, eX: -102, eZ: 118 },
      { id: 'petrol_jln', name: 'HP Fuel & Nitro · JLN Marg', loc: 'JLN Marg · Trimurti', x: 215, z: 625, eX: 194, eZ: 625 },
      { id: 'petrol_amer', name: 'IndianOil · Amer Road Station', loc: 'Amer Road · Zorawar Gate', x: 215, z: -425, eX: 194, eZ: -425 },
      { id: 'petrol_vaishali', name: 'Bharat Petroleum · Vaishali', loc: 'Vaishali Nagar', x: -715, z: 96, eX: -715, eZ: 118 },
      { id: 'petrol_mansarovar', name: 'HP Petrol Pump · Mansarovar', loc: 'Mansarovar · New Sanganer', x: -430, z: 635, eX: -430, eZ: 615 },
      { id: 'petrol_airport', name: 'IndianOil · Airport Tonk Rd', loc: 'Sanganer · Patrika', x: 108, z: 995, eX: 132, eZ: 995 },
    ];
    for (const p of petrolSites) {
      const grp = new THREE.Group();
      grp.position.set(p.x, 0, p.z);
      const pad = new THREE.Mesh(new THREE.BoxGeometry(22, 0.25, 16), concreteMat);
      pad.position.y = 0.12;
      const canopy = new THREE.Mesh(new THREE.BoxGeometry(19, 1.0, 12), petrolOrangeMat);
      canopy.position.y = 5.4;
      const booth = new THREE.Mesh(new THREE.BoxGeometry(6, 4.0, 5), whiteMarbleMat);
      booth.position.set(-6, 2.0, 0);
      const sign = new THREE.Mesh(
        new THREE.BoxGeometry(13, 2.4, 0.4),
        new THREE.MeshStandardMaterial({
          map: textures.petrolSignMap,
          emissiveMap: textures.petrolSignMap,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.5,
        }),
      );
      sign.position.set(0, 6.4, 6.1);
      for (const px of [-2, 3, 7]) {
        const disp = new THREE.Mesh(new THREE.BoxGeometry(1.1, 2.1, 0.8), darkSteelMat);
        disp.position.set(px, 1.15, 0);
        const nozzleStrip = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.4, 0.85), petrolOrangeMat);
        nozzleStrip.position.set(px, 1.85, 0);
        const col = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 5.2, 8), whiteMarbleMat);
        col.position.set(px, 2.7, 3.6);
        grp.add(disp, nozzleStrip, col);
      }
      grp.add(pad, canopy, booth, sign);
      worldGroup.add(grp);

      buildings.push({ minX: p.x - 9.2, maxX: p.x - 2.8, minZ: p.z - 2.8, maxZ: p.z + 2.8, height: 6 });
      blueprintBuildings.push({ x: p.x, z: p.z, w: 20, d: 14, kind: 'petrol' });

      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.0, 0.22, 8, 22), petrolOrangeMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(p.eX, 0.22, p.eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id: p.id,
        name: p.name,
        category: 'petrol',
        localityName: p.loc,
        x: p.x,
        z: p.z,
        entryX: p.eX,
        entryZ: p.eZ,
        accent: '#f97316',
        brand: 'IndianOil · HP Fuel Station',
        lootCash: 16500,
        canRob: true,
      });
    }

    // 5 Brand Vehicle Showrooms with Glass Frontage + Rotating Real Display Vehicle!
    const showrooms: Array<{
      id: string;
      name: string;
      brand: string;
      loc: string;
      x: number;
      z: number;
      eX: number;
      eZ: number;
      rotY: number;
      signTex: THREE.CanvasTexture;
      displayCar: VehicleId;
      carColor: string;
      accent: string;
    }> = [
      {
        id: 'showroom_ferrari',
        name: 'Ferrari & Lamborghini Jaipur',
        brand: 'Ferrari & Lamborghini',
        loc: 'MI Road · Luxury Row',
        x: -182,
        z: 96,
        eX: -182,
        eZ: 118,
        rotY: 0,
        signTex: textures.showroomFerrariSign,
        displayCar: 'ferrari_sf90',
        carColor: '#d91616',
        accent: '#ef4444',
      },
      {
        id: 'showroom_bugatti',
        name: 'Bugatti & Koenigsegg Hyper Lounge',
        brand: 'Bugatti & Koenigsegg',
        loc: 'Malviya Nagar · WTP',
        x: 486,
        z: 635,
        eX: 486,
        eZ: 606,
        rotY: Math.PI,
        signTex: textures.showroomBugattiSign,
        displayCar: 'bugatti_chiron',
        carColor: '#1d4ed8',
        accent: '#3b82f6',
      },
      {
        id: 'showroom_suv',
        name: 'Mahindra & Toyota 4x4 Arena',
        brand: 'Mahindra & Toyota',
        loc: 'Vaishali Nagar · Amrapali',
        x: -645,
        z: 96,
        eX: -645,
        eZ: 118,
        rotY: 0,
        signTex: textures.showroomSuvSign,
        displayCar: 'fortuner_suv',
        carColor: '#f8fafc',
        accent: '#eab308',
      },
      {
        id: 'showroom_maruti',
        name: 'Maruti Arena & Honda Motors',
        brand: 'Maruti Suzuki & Honda',
        loc: 'Tonk Road · Lal Kothi',
        x: -125,
        z: 635,
        eX: -102,
        eZ: 635,
        rotY: Math.PI / 2,
        signTex: textures.showroomMarutiSign,
        displayCar: 'city_sedan',
        carColor: '#e2e8f0',
        accent: '#0ea5e9',
      },
      {
        id: 'showroom_bikes',
        name: 'Royal Enfield & KTM Superbikes',
        brand: 'Royal Enfield & KTM',
        loc: 'Raja Park · Panchwati',
        x: 486,
        z: 195,
        eX: 460,
        eZ: 195,
        rotY: -Math.PI / 2,
        signTex: textures.showroomBikeSign,
        displayCar: 'duke_390',
        carColor: '#ea580c',
        accent: '#f97316',
      },
    ];
    for (const sr of showrooms) {
      const grp = new THREE.Group();
      grp.position.set(sr.x, 0, sr.z);
      grp.rotation.y = sr.rotY;

      const plinth = new THREE.Mesh(new THREE.BoxGeometry(26, 0.5, 18), darkSteelMat);
      plinth.position.y = 0.25;
      const roof = new THREE.Mesh(new THREE.BoxGeometry(27, 0.85, 19), darkSteelMat);
      roof.position.y = 8.4;
      const backWall = new THREE.Mesh(new THREE.BoxGeometry(25.6, 8, 1.2), whiteMarbleMat);
      backWall.position.set(0, 4.2, -8.2);
      const glassWall = new THREE.Mesh(new THREE.BoxGeometry(25.4, 7.6, 16.4), showroomGlassMat);
      glassWall.position.set(0, 4.2, 0);
      const sign = new THREE.Mesh(
        new THREE.BoxGeometry(20, 3.2, 0.45),
        new THREE.MeshStandardMaterial({
          map: sr.signTex,
          emissiveMap: sr.signTex,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.6,
        }),
      );
      sign.position.set(0, 7.2, 8.8);
      grp.add(plinth, roof, backWall, glassWall, sign);

      const turntable = new THREE.Group();
      turntable.position.set(0, 0.65, 0);
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(4.4, 4.6, 0.35, 24), whiteMarbleMat);
      turntable.add(disc);
      const heroRig = buildVehicleModel(sr.displayCar, sr.carColor, textures, isSoftwareGl, false);
      heroRig.root.position.set(0, 0.22, 0);
      heroRig.root.rotation.y = 0.4;
      turntable.add(heroRig.root);
      showroomTurntables.push(turntable);
      grp.add(turntable);

      worldGroup.add(grp);
      const sw = Math.abs(Math.sin(sr.rotY)) > 0.5;
      const hw = sw ? 9.5 : 13.5;
      const hd = sw ? 13.5 : 9.5;
      buildings.push({ minX: sr.x - hw, maxX: sr.x + hw, minZ: sr.z - hd, maxZ: sr.z + hd, height: 9 });
      blueprintBuildings.push({ x: sr.x, z: sr.z, w: hw * 2, d: hd * 2, kind: 'showroom' });

      const srGlow = new THREE.MeshStandardMaterial({ color: sr.accent, emissive: sr.accent, emissiveIntensity: 1.4 });
      neonMaterials.push(srGlow);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.2, 0.22, 8, 22), srGlow);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(sr.eX, 0.22, sr.eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id: sr.id,
        name: sr.name,
        category: 'showroom',
        localityName: sr.loc,
        x: sr.x,
        z: sr.z,
        entryX: sr.eX,
        entryZ: sr.eZ,
        accent: sr.accent,
        brand: sr.brand,
        lootCash: 45000,
        canRob: true,
      });
    }

    // Specialized Jaipur Stores, Schools, Offices, Hotels, Ammu-Nation, Cloth & Barber!
    interface VenueSpec {
      id: string;
      name: string;
      category: BuildingCategory;
      loc: string;
      x: number;
      z: number;
      eX: number;
      eZ: number;
      w: number;
      d: number;
      h: number;
      wallMat: THREE.Material;
      signTex: THREE.CanvasTexture;
      accent: string;
      loot: number;
    }

    const venues: VenueSpec[] = [
      // Ammu-Nation x2
      {
        id: 'ammo_mi',
        name: 'Ammu-Nation · MI Road Armory',
        category: 'ammunation',
        loc: 'MI Road · Ajmeri Gate',
        x: -16,
        z: 96,
        eX: -16,
        eZ: 118,
        w: 18,
        d: 14,
        h: 8,
        wallMat: ammoMat,
        signTex: textures.ammunationSignMap,
        accent: '#f59e0b',
        loot: 24000,
      },
      {
        id: 'ammo_vaishali',
        name: 'Ammu-Nation · Vaishali Defense',
        category: 'ammunation',
        loc: 'Vaishali Nagar',
        x: -835,
        z: 96,
        eX: -835,
        eZ: 118,
        w: 18,
        d: 14,
        h: 8,
        wallMat: ammoMat,
        signTex: textures.ammunationSignMap,
        accent: '#f59e0b',
        loot: 24000,
      },
      // Cloth Stores x3
      {
        id: 'cloth_johari',
        name: 'Johari Cloth House & Silks',
        category: 'cloth',
        loc: 'Johari Bazaar',
        x: 112,
        z: -88,
        eX: 136,
        eZ: -88,
        w: 18,
        d: 14,
        h: 9,
        wallMat: pinkHaveliMat,
        signTex: textures.clothSignMap,
        accent: '#ec4899',
        loot: 14500,
      },
      {
        id: 'cloth_rajapark',
        name: 'Raja Park Fashion Street',
        category: 'cloth',
        loc: 'Raja Park',
        x: 365,
        z: 195,
        eX: 392,
        eZ: 195,
        w: 18,
        d: 15,
        h: 9,
        wallMat: whiteMarbleMat,
        signTex: textures.clothSignMap,
        accent: '#ec4899',
        loot: 14000,
      },
      {
        id: 'cloth_cscheme',
        name: 'C-Scheme Designer Couture',
        category: 'cloth',
        loc: 'C-Scheme · Statue Circle',
        x: -302,
        z: 96,
        eX: -302,
        eZ: 118,
        w: 16,
        d: 14,
        h: 9,
        wallMat: pinkHaveliMat,
        signTex: textures.clothSignMap,
        accent: '#ec4899',
        loot: 15500,
      },
      // Barber Shops x3
      {
        id: 'barber_statue',
        name: 'Royal Rajputana Barber Salon',
        category: 'barber',
        loc: 'Statue Circle · C-Scheme',
        x: -188,
        z: 195,
        eX: -188,
        eZ: 170,
        w: 14,
        d: 12,
        h: 7,
        wallMat: whiteMarbleMat,
        signTex: textures.barberSignMap,
        accent: '#38bdf8',
        loot: 6800,
      },
      {
        id: 'barber_mansarovar',
        name: 'Mansarovar Gents & Hair Studio',
        category: 'barber',
        loc: 'Mansarovar',
        x: -425,
        z: 525,
        eX: -452,
        eZ: 525,
        w: 14,
        d: 12,
        h: 7,
        wallMat: sandstoneMat,
        signTex: textures.barberSignMap,
        accent: '#38bdf8',
        loot: 6200,
      },
      {
        id: 'barber_bapu',
        name: 'Bapu Bazaar Vintage Barber',
        category: 'barber',
        loc: 'Bapu Bazaar',
        x: 212,
        z: -88,
        eX: 188,
        eZ: -88,
        w: 14,
        d: 12,
        h: 7,
        wallMat: pinkHaveliMat,
        signTex: textures.barberSignMap,
        accent: '#38bdf8',
        loot: 6500,
      },
      // DMart Supermarts x2
      {
        id: 'dmart_vidyadhar',
        name: 'DMart Hypermarket · Vidyadhar',
        category: 'dmart',
        loc: 'Vidyadhar Nagar',
        x: -545,
        z: -505,
        eX: -512,
        eZ: -505,
        w: 32,
        d: 24,
        h: 11,
        wallMat: whiteMarbleMat,
        signTex: textures.dmartSignMap,
        accent: '#22c55e',
        loot: 32000,
      },
      {
        id: 'dmart_mansarovar',
        name: 'DMart Value Megastore · Mansarovar',
        category: 'dmart',
        loc: 'Mansarovar · New Sanganer',
        x: -545,
        z: 525,
        eX: -512,
        eZ: 525,
        w: 32,
        d: 24,
        h: 11,
        wallMat: whiteMarbleMat,
        signTex: textures.dmartSignMap,
        accent: '#22c55e',
        loot: 34000,
      },
      // Decathlon Sports
      {
        id: 'decathlon_vaishali',
        name: 'Decathlon Sports Arena · Jaipur',
        category: 'decathlon',
        loc: 'Vaishali · 200 Ft Bypass',
        x: -955,
        z: 96,
        eX: -955,
        eZ: 118,
        w: 34,
        d: 22,
        h: 10,
        wallMat: techGlassMat,
        signTex: textures.decathlonSignMap,
        accent: '#0284c7',
        loot: 26000,
      },
      // Hotels x3
      {
        id: 'hotel_rambagh',
        name: 'Rambagh Palace Heritage Hotel',
        category: 'hotel',
        loc: 'Rambagh Circle · Bhawani Singh Rd',
        x: 98,
        z: 300,
        eX: 132,
        eZ: 300,
        w: 30,
        d: 24,
        h: 14,
        wallMat: goldenStoneMat,
        signTex: textures.hotelSignMap,
        accent: '#f59e0b',
        loot: 42000,
      },
      {
        id: 'hotel_rajputana',
        name: 'ITC Rajputana Palace Hotel',
        category: 'hotel',
        loc: 'Jaipur Junction · Gopalbari',
        x: -418,
        z: 195,
        eX: -450,
        eZ: 195,
        w: 28,
        d: 22,
        h: 14,
        wallMat: pinkSolidMat,
        signTex: textures.hotelSignMap,
        accent: '#f59e0b',
        loot: 38000,
      },
      {
        id: 'hotel_clarks',
        name: 'Clarks Amer Luxury Hotel',
        category: 'hotel',
        loc: 'JLN Marg · Jawahar Circle',
        x: 98,
        z: 785,
        eX: 130,
        eZ: 785,
        w: 26,
        d: 22,
        h: 16,
        wallMat: whiteMarbleMat,
        signTex: textures.hotelSignMap,
        accent: '#f59e0b',
        loot: 36000,
      },
      // Paan Shops x4
      {
        id: 'paan_chaupar',
        name: 'Badi Chaupar Royal Paan Corner',
        category: 'paan',
        loc: 'Badi Chaupar',
        x: 212,
        z: -168,
        eX: 188,
        eZ: -168,
        w: 10,
        d: 10,
        h: 5.5,
        wallMat: pinkHaveliMat,
        signTex: textures.paanSignMap,
        accent: '#10b981',
        loot: 4800,
      },
      {
        id: 'paan_mi',
        name: 'Panch Batti Banarasi Paan',
        category: 'paan',
        loc: 'MI Road',
        x: -102,
        z: 195,
        eX: -102,
        eZ: 170,
        w: 10,
        d: 10,
        h: 5.5,
        wallMat: sandstoneMat,
        signTex: textures.paanSignMap,
        accent: '#10b981',
        loot: 4500,
      },
      {
        id: 'paan_malviya',
        name: 'Gaurav Tower Paan & Soda',
        category: 'paan',
        loc: 'Malviya Nagar',
        x: 372,
        z: 525,
        eX: 396,
        eZ: 525,
        w: 10,
        d: 10,
        h: 5.5,
        wallMat: whiteMarbleMat,
        signTex: textures.paanSignMap,
        accent: '#10b981',
        loot: 4900,
      },
      {
        id: 'paan_rajapark',
        name: 'Raja Park Mint Paan Palace',
        category: 'paan',
        loc: 'Raja Park',
        x: 472,
        z: 96,
        eX: 446,
        eZ: 96,
        w: 10,
        d: 10,
        h: 5.5,
        wallMat: pinkHaveliMat,
        signTex: textures.paanSignMap,
        accent: '#10b981',
        loot: 4600,
      },
      // Grocery / Kirana Stores x4
      {
        id: 'grocery_johari',
        name: 'Johari Bazaar Kirana & Spices',
        category: 'grocery',
        loc: 'Johari Bazaar',
        x: 112,
        z: -168,
        eX: 136,
        eZ: -168,
        w: 14,
        d: 12,
        h: 7,
        wallMat: sandstoneMat,
        signTex: textures.grocerySignMap,
        accent: '#22c55e',
        loot: 7500,
      },
      {
        id: 'grocery_banipark',
        name: 'Bani Park Super Kirana',
        category: 'grocery',
        loc: 'Bani Park',
        x: -425,
        z: -165,
        eX: -452,
        eZ: -165,
        w: 15,
        d: 12,
        h: 7,
        wallMat: sandstoneMat,
        signTex: textures.grocerySignMap,
        accent: '#22c55e',
        loot: 7800,
      },
      {
        id: 'grocery_jagatpura',
        name: 'Jagatpura Daily Fresh Grocery',
        category: 'grocery',
        loc: 'Jagatpura',
        x: 705,
        z: 525,
        eX: 734,
        eZ: 525,
        w: 16,
        d: 13,
        h: 7.5,
        wallMat: whiteMarbleMat,
        signTex: textures.grocerySignMap,
        accent: '#22c55e',
        loot: 8200,
      },
      {
        id: 'grocery_civil',
        name: 'Civil Lines Reliance Fresh Mart',
        category: 'grocery',
        loc: 'Civil Lines',
        x: -298,
        z: 298,
        eX: -272,
        eZ: 298,
        w: 16,
        d: 13,
        h: 7.5,
        wallMat: whiteMarbleMat,
        signTex: textures.grocerySignMap,
        accent: '#22c55e',
        loot: 8900,
      },
      // Schools x2
      {
        id: 'school_sms',
        name: 'Sawai Mansingh Public School',
        category: 'school',
        loc: 'JLN Marg · Rambagh',
        x: 215,
        z: 300,
        eX: 186,
        eZ: 300,
        w: 28,
        d: 20,
        h: 11,
        wallMat: pinkHaveliMat,
        signTex: textures.schoolSignMap,
        accent: '#3b82f6',
        loot: 5500,
      },
      {
        id: 'school_vidyadhar',
        name: 'Vidyadhar Nagar International School',
        category: 'school',
        loc: 'Vidyadhar Nagar',
        x: -415,
        z: -505,
        eX: -450,
        eZ: -505,
        w: 28,
        d: 20,
        h: 11,
        wallMat: sandstoneMat,
        signTex: textures.schoolSignMap,
        accent: '#3b82f6',
        loot: 5500,
      },
      // Offices x3
      {
        id: 'office_secretariat',
        name: 'Rajasthan Secretariat & Metro Office',
        category: 'office',
        loc: 'Statue Circle · Vidhan Sabha',
        x: -125,
        z: 385,
        eX: -94,
        eZ: 385,
        w: 28,
        d: 20,
        h: 18,
        wallMat: techGlassMat,
        signTex: textures.officeSignMap,
        accent: '#8b5cf6',
        loot: 21000,
      },
      {
        id: 'office_wtp_corp',
        name: 'WTP Corporate & IT Chambers',
        category: 'office',
        loc: 'Malviya Nagar',
        x: 355,
        z: 635,
        eX: 388,
        eZ: 635,
        w: 24,
        d: 18,
        h: 22,
        wallMat: techGlassMat,
        signTex: textures.officeSignMap,
        accent: '#8b5cf6',
        loot: 25000,
      },
      {
        id: 'office_sitapura',
        name: 'Sitapura JECC & Tech Park Offices',
        category: 'office',
        loc: 'Sitapura Industrial',
        x: 695,
        z: 995,
        eX: 730,
        eZ: 995,
        w: 28,
        d: 20,
        h: 20,
        wallMat: techGlassMat,
        signTex: textures.officeSignMap,
        accent: '#8b5cf6',
        loot: 28000,
      },
      // All Other Requested Jaipur Stores: Jewelry, LMB Sweet Shop, Electronics, Pharmacy, Chai Tapri
      {
        id: 'jewelry_gem',
        name: 'Gem Palace Royal Jewelers',
        category: 'jewelry',
        loc: 'MI Road · Panch Batti',
        x: 24,
        z: 96,
        eX: 24,
        eZ: 118,
        w: 16,
        d: 14,
        h: 9,
        wallMat: goldenStoneMat,
        signTex: textures.jewelrySignMap,
        accent: '#eab308',
        loot: 55000,
      },
      {
        id: 'sweet_lmb',
        name: 'LMB Johari Heritage Sweets',
        category: 'sweet_shop',
        loc: 'Johari Bazaar',
        x: 212,
        z: -245,
        eX: 186,
        eZ: -245,
        w: 16,
        d: 13,
        h: 8,
        wallMat: pinkHaveliMat,
        signTex: textures.sweetSignMap,
        accent: '#f59e0b',
        loot: 11000,
      },
      {
        id: 'elec_mi',
        name: 'Pink City Electronics & Gadgets',
        category: 'electronics',
        loc: 'MI Road',
        x: -140,
        z: 96,
        eX: -140,
        eZ: 118,
        w: 16,
        d: 13,
        h: 10,
        wallMat: techGlassMat,
        signTex: textures.electronicsSignMap,
        accent: '#0ea5e9',
        loot: 29000,
      },
      {
        id: 'pharm_jln',
        name: 'Apollo 24x7 Pharmacy & Meds',
        category: 'pharmacy',
        loc: 'JLN Marg · SMS',
        x: 212,
        z: 100,
        eX: 186,
        eZ: 100,
        w: 14,
        d: 12,
        h: 8,
        wallMat: whiteMarbleMat,
        signTex: textures.pharmacySignMap,
        accent: '#ef4444',
        loot: 12500,
      },
      {
        id: 'chai_gulabji',
        name: 'Gulab Ji Heritage Chai Tapri',
        category: 'chai_tapri',
        loc: 'MI Road · Ganpati Plaza',
        x: -140,
        z: 195,
        eX: -140,
        eZ: 170,
        w: 12,
        d: 10,
        h: 6,
        wallMat: terracottaMat,
        signTex: textures.chaiSignMap,
        accent: '#f97316',
        loot: 5200,
      },
    ];

    for (const v of venues) {
      const grp = new THREE.Group();
      grp.position.set(v.x, 0, v.z);
      const plinth = new THREE.Mesh(new THREE.BoxGeometry(v.w + 1, 0.7, v.d + 1), concreteMat);
      plinth.position.y = 0.35;
      const body = new THREE.Mesh(new THREE.BoxGeometry(v.w, v.h, v.d), v.wallMat);
      body.position.y = 0.7 + v.h / 2;
      body.castShadow = !isSoftwareGl;
      body.receiveShadow = true;

      // Face signboard toward entry side
      const dx = v.eX - v.x;
      const dz = v.eZ - v.z;
      const faceYaw = Math.atan2(dx, dz);
      const signDist = Math.abs(dx) > Math.abs(dz) ? v.w / 2 + 0.3 : v.d / 2 + 0.3;
      const sign = new THREE.Mesh(
        new THREE.BoxGeometry(Math.min(v.w, v.d) * 0.92, 2.7, 0.35),
        new THREE.MeshStandardMaterial({
          map: v.signTex,
          emissiveMap: v.signTex,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.55,
        }),
      );
      sign.rotation.y = faceYaw;
      sign.position.set(Math.sin(faceYaw) * signDist, Math.min(v.h - 0.6, 6.4), Math.cos(faceYaw) * signDist);

      const door = new THREE.Mesh(
        new THREE.BoxGeometry(3.0, 3.2, 0.35),
        new THREE.MeshStandardMaterial({ color: v.accent, emissive: v.accent, emissiveIntensity: 0.45 }),
      );
      door.rotation.y = faceYaw;
      door.position.set(Math.sin(faceYaw) * signDist, 2.1, Math.cos(faceYaw) * signDist);

      grp.add(plinth, body, sign, door);
      worldGroup.add(grp);

      buildings.push({
        minX: v.x - v.w / 2 - 0.5,
        maxX: v.x + v.w / 2 + 0.5,
        minZ: v.z - v.d / 2 - 0.5,
        maxZ: v.z + v.d / 2 + 0.5,
        height: v.h + 1.5,
      });
      blueprintBuildings.push({ x: v.x, z: v.z, w: v.w, d: v.d, kind: 'store' });

      const ringMat = new THREE.MeshStandardMaterial({ color: v.accent, emissive: v.accent, emissiveIntensity: 1.4 });
      neonMaterials.push(ringMat);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(2.8, 0.2, 8, 22), ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(v.eX, 0.22, v.eZ);
      facilityRings.push(ring);
      worldGroup.add(ring);

      enterableBuildings.push({
        id: v.id,
        name: v.name,
        category: v.category,
        localityName: v.loc,
        x: v.x,
        z: v.z,
        entryX: v.eX,
        entryZ: v.eZ,
        accent: v.accent,
        lootCash: v.loot,
        canRob: true,
      });
    }
  }

  // ============================================================================
  // 11. JAIPUR INTERNATIONAL AIRPORT (JAI · SANGANER, z = 1125, RUNWAY z = 1220)
  // ============================================================================
  {
    const airportBlueMat = new THREE.MeshStandardMaterial({ color: 0x0ea5e9, emissive: 0x38bdf8, emissiveIntensity: 1.8, roughness: 0.28 });
    const airportAmberLightMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, emissive: 0xfbbf24, emissiveIntensity: 2.2 });
    const runwayMat = new THREE.MeshStandardMaterial({
      map: textures.runwayMap,
      roughness: 0.88,
      metalness: 0.02,
      polygonOffset: true,
      polygonOffsetFactor: -3,
      polygonOffsetUnits: -3,
    });
    const apronConcreteMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.88, metalness: 0.05 });
    const hangarMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.52, metalness: 0.55 });
    neonMaterials.push(airportBlueMat, airportAmberLightMat);

    for (const fac of WORLD_FACILITIES) {
      if (fac.type !== 'airport') continue;
      const cx = fac.x;
      const cz = fac.z;
      const runwayZ = cz + 95;

      const airportGrp = new THREE.Group();
      const runway = new THREE.Mesh(new THREE.PlaneGeometry(330, 34), runwayMat);
      runway.rotation.x = -Math.PI / 2;
      runway.position.set(cx, 0.06, runwayZ);
      runway.receiveShadow = true;
      airportGrp.add(runway);
      blueprintBuildings.push({ x: cx, z: runwayZ, w: 330, d: 34, kind: 'airport' });

      const apron = new THREE.Mesh(new THREE.PlaneGeometry(170, 72), apronConcreteMat);
      apron.rotation.x = -Math.PI / 2;
      apron.position.set(cx, 0.035, cz + 46);
      apron.receiveShadow = true;
      airportGrp.add(apron);

      for (let lx = -150; lx <= 150; lx += 30) {
        for (const lz of [-18, 18]) {
          const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.32, 6, 6), airportAmberLightMat);
          beacon.position.set(cx + lx, 0.32, runwayZ + lz);
          airportGrp.add(beacon);
        }
      }

      const termBody = new THREE.Mesh(new THREE.BoxGeometry(58, 11.5, 22), pinkHaveliMat);
      termBody.position.set(cx, 5.75, cz);
      termBody.castShadow = !isSoftwareGl;
      const termGlass = new THREE.Mesh(new THREE.BoxGeometry(52, 7.2, 22.4), techGlassMat);
      termGlass.position.set(cx, 5.4, cz);
      const termRoof = new THREE.Mesh(new THREE.BoxGeometry(64, 1.2, 28), sandstoneMat);
      termRoof.position.set(cx, 12.1, cz);
      const termSign = new THREE.Mesh(
        new THREE.BoxGeometry(28, 3.8, 0.45),
        new THREE.MeshStandardMaterial({
          map: textures.airportSignMap,
          emissiveMap: textures.airportSignMap,
          emissive: new THREE.Color(0xffffff),
          emissiveIntensity: 0.65,
          roughness: 0.3,
        }),
      );
      termSign.position.set(cx, 9.6, cz - 11.5);
      airportGrp.add(termBody, termGlass, termRoof, termSign);
      buildings.push({ minX: cx - 29.5, maxX: cx + 29.5, minZ: cz - 11.5, maxZ: cz + 11.5, height: 13 });
      blueprintBuildings.push({ x: cx, z: cz, w: 58, d: 22, kind: 'airport' });

      const towerX = cx + 48;
      const towerZ = cz + 10;
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 3.2, 28, 10), whiteMarbleMat);
      shaft.position.set(towerX, 14, towerZ);
      shaft.castShadow = !isSoftwareGl;
      const cab = new THREE.Mesh(new THREE.CylinderGeometry(5.6, 4.2, 4.4, 10), techGlassMat);
      cab.position.set(towerX, 29.5, towerZ);
      const cabRoof = new THREE.Mesh(new THREE.CylinderGeometry(6.1, 6.1, 0.7, 10), airportBlueMat);
      cabRoof.position.set(towerX, 32.0, towerZ);
      const radarGroup = new THREE.Group();
      radarGroup.position.set(towerX, 34.4, towerZ);
      const radarMast = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.35, 2.2, 8), concreteMat);
      radarMast.position.y = -0.8;
      const radarBar = new THREE.Mesh(new THREE.BoxGeometry(5.8, 1.2, 0.55), airportAmberLightMat);
      radarGroup.add(radarMast, radarBar);
      airportRadars.push(radarGroup);
      airportGrp.add(shaft, cab, cabRoof, radarGroup);
      buildings.push({ minX: towerX - 3.6, maxX: towerX + 3.6, minZ: towerZ - 3.6, maxZ: towerZ + 3.6, height: 35 });

      const hangarX = cx - 58;
      const hangarZ = cz + 18;
      const hangarBox = new THREE.Mesh(new THREE.BoxGeometry(28, 11, 24), hangarMat);
      hangarBox.position.set(hangarX, 5.5, hangarZ);
      hangarBox.castShadow = !isSoftwareGl;
      const hangarRoof = new THREE.Mesh(new THREE.CylinderGeometry(14, 14, 24, 14, 1, false, 0, Math.PI), hangarMat);
      hangarRoof.rotation.z = Math.PI / 2;
      hangarRoof.rotation.y = Math.PI / 2;
      hangarRoof.position.set(hangarX, 11, hangarZ);
      airportGrp.add(hangarBox, hangarRoof);
      buildings.push({ minX: hangarX - 14.5, maxX: hangarX + 14.5, minZ: hangarZ - 12.5, maxZ: hangarZ + 12.5, height: 18 });
      blueprintBuildings.push({ x: hangarX, z: hangarZ, w: 28, d: 24, kind: 'airport' });

      const parkedJet = buildJetAircraft('#f59e0b', isSoftwareGl);
      parkedJet.root.position.set(cx - 24, 0.05, cz + 42);
      parkedJet.root.rotation.y = -Math.PI / 3;
      airportGrp.add(parkedJet.root);

      const ring = new THREE.Mesh(new THREE.TorusGeometry(3.8, 0.28, 8, 28), airportBlueMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.set(fac.entryX, 0.24, fac.entryZ);
      facilityRings.push(ring);
      airportGrp.add(ring);

      worldGroup.add(airportGrp);
    }
  }

  // ============================================================================
  // 12. URBAN JAIPUR NEIGHBORHOOD BLOCKS & ENTERABLE HOUSES ACROSS ALL LOCALITIES
  // ============================================================================
  const localityStyles: BuildingStyle[] = ['pink', 'ochre', 'dhaba', 'glass', 'white'];
  JAIPUR_LOCALITIES.forEach((loc, idx) => {
    const isModernSouthOrWest =
      loc.zone === 'South · JLN & Airport' || loc.zone === 'West · Vaishali' || loc.zone === 'Central · MI Road';
    const baseStyle =
      loc.zone === 'Walled Pink City' ? 'pink' : isModernSouthOrWest ? localityStyles[(idx + 2) % localityStyles.length] : 'ochre';

    const offsets: Array<[number, number, BuildingStyle]> = [
      [38, 38, baseStyle],
      [-38, 38, 'dhaba'],
      [38, -38, idx % 3 === 0 ? 'temple' : baseStyle],
      [-38, -38, isModernSouthOrWest ? 'glass' : 'pink'],
    ];
    offsets.forEach(([ox, oz, st], k) => {
      const w = 18 + ((idx + k) % 3) * 4;
      const d = 16 + ((idx + k) % 2) * 4;
      const h = st === 'glass' ? 18 + (idx % 4) * 5 : 10 + ((idx + k) % 4) * 2.5;
      addIndianBuilding(loc.x + ox, loc.z + oz, w, d, h, st, ((idx + k) % 4) * (Math.PI / 2));
    });
  });

  // ============================================================================
  // 13. INSTANCED KHEJRI, ASHOKA & NEEM TREES (540 TREES ACROSS JAIPUR)
  // ============================================================================
  const treeCount = 540;
  const trunkGeo = new THREE.CylinderGeometry(0.24, 0.42, 6.2, 6);
  trunkGeo.translate(0, 3.1, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6b4f35, roughness: 0.9 });
  const canopyGeo = new THREE.ConeGeometry(2.8, 3.5, 6);
  canopyGeo.translate(0, 7.0, 0);
  const canopyMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8 });

  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
  const canopyInst = new THREE.InstancedMesh(canopyGeo, canopyMat, treeCount);
  trunkInst.castShadow = !isSoftwareGl;
  canopyInst.castShadow = !isSoftwareGl;

  const isTreePosBlocked = (x: number, z: number): boolean => {
    for (const rx of JAIPUR_NS_ROADS) if (Math.abs(x - rx) < 16) return true;
    for (const rz of JAIPUR_EW_ROADS) if (Math.abs(z - rz) < 16) return true;
    if (Math.abs(z - 248) < 14) return true;
    for (const c of JAIPUR_CIRCLES) if (Math.hypot(x - c.x, z - c.z) < c.radius + 14) return true;
    if (x >= -34 && x <= 14 && z >= 28 && z <= 140) return true;
    if (x >= 180 && x <= 395 && z >= -850 && z <= -650) return true;
    if (x >= -240 && x <= 120 && z >= 645 && z <= 775) return true;
    if (x >= 220 && x <= 375 && z >= 365 && z <= 495) return true; // SMS Stadium turf
    if (x >= 55 && x <= 430 && z >= 1070 && z <= 1245) return true;
    for (const b of buildings) {
      if (x >= b.minX - 4 && x <= b.maxX + 4 && z >= b.minZ - 4 && z <= b.maxZ + 4) return true;
    }
    return false;
  };

  const treeColor = new THREE.Color();
  for (let i = 0; i < treeCount; i++) {
    const angle = i * 2.39996;
    const rad = 55 + ((i * 37) % 1380);
    let tx = Math.cos(angle) * rad;
    let tz = Math.sin(angle) * rad;
    let tries = 0;
    while (isTreePosBlocked(tx, tz) && tries < 6) {
      tx += 28;
      tz += 24;
      tries++;
    }
    const sc = isTreePosBlocked(tx, tz) ? 0.001 : 0.85 + ((i * 13) % 35) / 100;
    dummy.position.set(tx, 0, tz);
    dummy.rotation.y = i * 0.9;
    dummy.scale.set(sc, sc * (0.9 + (i % 5) * 0.08), sc);
    dummy.updateMatrix();
    trunkInst.setMatrixAt(i, dummy.matrix);
    canopyInst.setMatrixAt(i, dummy.matrix);
    treeColor.setHSL(0.28 + ((i % 7) - 3) * 0.015, 0.48, 0.27 + (i % 4) * 0.04);
    canopyInst.setColorAt(i, treeColor);
  }
  trunkInst.instanceMatrix.needsUpdate = true;
  canopyInst.instanceMatrix.needsUpdate = true;
  if (canopyInst.instanceColor) canopyInst.instanceColor.needsUpdate = true;
  trunkInst.computeBoundingSphere();
  canopyInst.computeBoundingSphere();
  worldGroup.add(trunkInst, canopyInst);

  // ============================================================================
  // 14. DESTRUCTIBLE STREETLAMPS, BAZAAR STALLS & BOLLARDS (ZERO ROAD BARRICADES)
  // ============================================================================
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7, roughness: 0.35 });
  const bulbMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, emissive: 0xf59e0b, emissiveIntensity: 2.0 });
  neonMaterials.push(bulbMat);
  const stallClothMat = new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.85 });
  const crateMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.88 });
  const coneMat = new THREE.MeshStandardMaterial({ color: 0xea580c, roughness: 0.6 });

  const isPropBlocked = (x: number, z: number): boolean => {
    // Strictly keep every driving lane (20m wide => half-width 10m + 2.2m curb clearance) and railway completely free
    for (const rx of JAIPUR_NS_ROADS) if (Math.abs(x - rx) < 12.2) return true;
    for (const rz of JAIPUR_EW_ROADS) if (Math.abs(z - rz) < 12.2) return true;
    if (Math.abs(z - 248) < 10) return true;
    for (const c of JAIPUR_CIRCLES) if (Math.hypot(x - c.x, z - c.z) < c.radius + 12) return true;
    for (const f of WORLD_FACILITIES) {
      if (Math.hypot(x - f.entryX, z - f.entryZ) < 14 || Math.hypot(x - f.x, z - f.z) < 16) return true;
    }
    for (const eb of enterableBuildings) {
      if (Math.hypot(x - eb.entryX, z - eb.entryZ) < 8.5) return true;
    }
    if (Math.hypot(x - POLICE_STATION.gateX, z - POLICE_STATION.gateZ) < 16) return true;
    for (const b of buildings) {
      if (x >= b.minX - 1.5 && x <= b.maxX + 1.5 && z >= b.minZ - 1.5 && z <= b.maxZ + 1.5) return true;
    }
    return false;
  };

  let propIdCounter = 1;
  const spawnDestructible = (kind: PropKind, x: number, z: number) => {
    if (isPropBlocked(x, z)) return;
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    let radius = 1.0;
    let colorHex = 0xf59e0b;

    if (kind === 'lamp') {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 5.2, 8), poleMat);
      pole.position.y = 2.6;
      const arm = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.14, 0.14), poleMat);
      arm.position.set(0.6, 5.1, 0);
      const lampHead = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.18, 0.34), bulbMat);
      lampHead.position.set(1.1, 4.95, 0);
      g.add(pole, arm, lampHead);
      radius = 0.85;
      colorHex = 0xfbbf24;
    } else if (kind === 'stall') {
      const table = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.9, 1.4), crateMat);
      table.position.y = 0.45;
      const awning = new THREE.Mesh(new THREE.BoxGeometry(2.9, 0.14, 1.8), stallClothMat);
      awning.position.set(0, 2.25, 0);
      awning.rotation.x = 0.15;
      for (const sx of [-1.2, 1.2]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6), crateMat);
        post.position.set(sx, 1.1, -0.6);
        g.add(post);
      }
      g.add(table, awning);
      radius = 1.65;
      colorHex = 0xe11d48;
    } else if (kind === 'bollard') {
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.32, 1.1, 8), sandstoneMat);
      base.position.y = 0.55;
      const cap = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 6), sandstoneMat);
      cap.position.y = 1.12;
      g.add(base, cap);
      radius = 0.7;
      colorHex = 0xd97706;
    } else {
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.85, 8), coneMat);
      cone.position.y = 0.425;
      const base = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.08, 0.66), poleMat);
      base.position.y = 0.04;
      g.add(base, cone);
      radius = 0.65;
      colorHex = 0xf97316;
    }

    worldGroup.add(g);
    destructibles.push({
      id: propIdCounter++,
      kind,
      mesh: g,
      originX: x,
      originZ: z,
      x,
      z,
      radius,
      colorHex,
      smashed: false,
      respawnTimer: 0,
    });
  };

  // Streetlamps strictly on sidewalks (±13.5m from road centerlines)
  for (let p = -640; p <= 640; p += 56) {
    spawnDestructible('lamp', p, 126.5);
    spawnDestructible('lamp', p, -223.5);
    spawnDestructible('lamp', 146.5, p);
    spawnDestructible('lamp', -253.5, p);
  }
  // Johari & Bapu Bazaar Sidewalk Stalls & Heritage Bollards (never blocking streets)
  for (let i = 0; i < 22; i++) {
    const col = i % 5;
    const row = Math.floor(i / 5);
    const px = 142 + (col - 2) * 16;
    const pz = -82 - row * 24;
    spawnDestructible(i % 2 === 0 ? 'stall' : 'bollard', px, pz);
  }

  function isOnBridgeAt(x: number, z: number): boolean {
    return x >= -70 && x <= -50 && z >= 610 && z <= 810;
  }

  function groundHeightAt(x: number, z: number): number {
    let h = 0;
    if (x >= -70 && x <= -50) {
      if (z >= 660 && z <= 760) {
        h = Math.max(h, 7.5);
      } else if (z > 760 && z <= 810) {
        const t = 1 - (z - 760) / 50;
        h = Math.max(h, t * 7.5);
      } else if (z >= 610 && z < 660) {
        const t = (z - 610) / 50;
        h = Math.max(h, t * 7.5);
      }
    }
    return h;
  }

  function resetProp(prop: DestructibleProp): void {
    prop.smashed = false;
    prop.x = prop.originX;
    prop.z = prop.originZ;
    prop.mesh.visible = true;
    prop.mesh.position.set(prop.originX, 0, prop.originZ);
    prop.mesh.rotation.set(0, 0, 0);
  }

  return {
    worldGroup,
    asphaltMaterial,
    roadNetworkMeshes,
    techGlassMat,
    waterUniforms,
    neonMaterials,
    buildings,
    blueprintBuildings,
    facilityRings,
    airportRadars,
    trafficLights,
    enterableBuildings,
    showroomTurntables,
    metroTrain,
    expressTrain,
    fireHqPos,
    ramps,
    destructibles,
    groundHeightAt,
    isOnBridgeAt,
    resetProp,
  };
}
