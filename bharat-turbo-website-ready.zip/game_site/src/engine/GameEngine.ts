import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import {
  JAIPUR_CIRCLES,
  JAIPUR_EW_ROADS,
  JAIPUR_LOCALITIES,
  JAIPUR_NS_ROADS,
  JOBS_CATALOG,
  POLICE_STATION,
  VEHICLE_CATALOG,
  WEAPONS_CATALOG,
  WORLD_FACILITIES,
  computeJaipurGpsRoute,
  getNearestJaipurLocality,
  resolveRajasthanDistrict,
  type ActiveJobTelemetry,
  type CameraMode,
  type CharacterConfig,
  type DistrictId,
  type EnterableBuildingInfo,
  type GpsPoint,
  type GraphicsPreset,
  type JobDef,
  type JobType,
  type LiveTelemetry,
  type MissionDef,
  type RemotePeerState,
  type VehicleId,
  type WeaponId,
  type WeatherMode,
} from '../types/game';
import { createProceduralTextures, type ProceduralTexturePack } from './proceduralTextures';
import {
  buildJetAircraft,
  buildPoliceHelicopter,
  buildVehicleModel,
  type AircraftRig,
  type PoliceHelicopterRig,
  type VehicleRig,
} from './vehicleBuilder';
import { buildCharacterModel, type CharacterRig } from './characterBuilder';
import { buildIndiaWorld, type BlueprintBuilding, type IndiaWorldHandles } from './indiaWorldBuilder';
import type { SoundEngine } from '../services/audioEngine';

// Pre-allocated module-scope scratch objects for zero-GC 60fps loop
const _camPos = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _dummy = new THREE.Object3D();

const SpeedWarpShader = {
  uniforms: {
    tDiffuse: { value: null },
    uSpeedBlur: { value: 0.0 },
    uChromatic: { value: 0.0 },
    uVignette: { value: 0.25 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float uSpeedBlur;
    uniform float uChromatic;
    uniform float uVignette;
    varying vec2 vUv;

    void main() {
      vec2 dir = vUv - vec2(0.5);
      float dist = length(dir);
      float edgeMask = smoothstep(0.18, 0.72, dist);

      vec4 base = texture2D(tDiffuse, vUv);
      if (uSpeedBlur > 0.001 && edgeMask > 0.001) {
        vec2 stepVec = dir * (uSpeedBlur * edgeMask * 0.022);
        vec4 acc = base * 0.32;
        acc += texture2D(tDiffuse, vUv - stepVec * 0.5) * 0.24;
        acc += texture2D(tDiffuse, vUv - stepVec * 1.0) * 0.18;
        acc += texture2D(tDiffuse, vUv - stepVec * 1.5) * 0.14;
        acc += texture2D(tDiffuse, vUv - stepVec * 2.0) * 0.12;
        base = acc;
      }

      if (uChromatic > 0.0005) {
        vec2 cOff = dir * uChromatic * edgeMask;
        float r = texture2D(tDiffuse, vUv + cOff).r;
        float b = texture2D(tDiffuse, vUv - cOff).b;
        base.r = mix(base.r, r, 0.7);
        base.b = mix(base.b, b, 0.7);
      }

      float vig = 1.0 - smoothstep(0.38, 0.88, dist) * uVignette;
      gl_FragColor = vec4(base.rgb * vig, base.a);
    }
  `,
};

const SkyDomeShader = {
  uniforms: {
    uTopColor: { value: new THREE.Color(0x1e1b4b) },
    uHorizonColor: { value: new THREE.Color(0xf97316) },
    uSunDir: { value: new THREE.Vector3(0.55, 0.24, 0.45).normalize() },
    uSunColor: { value: new THREE.Color(0xfde68a) },
    uStarIntensity: { value: 0.15 },
    uCloudIntensity: { value: 0.35 },
    uTime: { value: 0.0 },
  },
  vertexShader: `
    varying vec3 vWorldDir;
    void main() {
      vWorldDir = normalize(position);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 uTopColor;
    uniform vec3 uHorizonColor;
    uniform vec3 uSunDir;
    uniform vec3 uSunColor;
    uniform float uStarIntensity;
    uniform float uCloudIntensity;
    uniform float uTime;
    varying vec3 vWorldDir;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
    }
    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
                 mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
    }

    void main() {
      vec3 dir = normalize(vWorldDir);
      float h = clamp(dir.y, 0.0, 1.0);
      vec3 sky = mix(uHorizonColor, uTopColor, pow(h, 0.58));

      // Solar / lunar glow disc
      float sunAmt = max(dot(dir, normalize(uSunDir)), 0.0);
      sky += uSunColor * pow(sunAmt, 14.0) * 0.55;
      sky += uSunColor * smoothstep(0.996, 0.9992, sunAmt) * 1.4;

      // Procedural drifting atmospheric cloud wisps
      if (dir.y > 0.03 && uCloudIntensity > 0.01) {
        vec2 cloudUv = dir.xz / (dir.y + 0.18) * 1.6 + vec2(uTime * 0.012, uTime * 0.006);
        float c = noise(cloudUv) * 0.65 + noise(cloudUv * 2.3) * 0.35;
        float cloudMask = smoothstep(0.48, 0.82, c) * smoothstep(0.03, 0.25, dir.y);
        sky = mix(sky, mix(uHorizonColor, vec3(1.0), 0.35), cloudMask * uCloudIntensity);
      }

      // Twinkling stars at dusk / night
      if (uStarIntensity > 0.01 && dir.y > 0.08) {
        vec2 starUv = floor(dir.xz / (dir.y + 0.25) * 180.0);
        float s = hash(starUv);
        if (s > 0.993) {
          float twinkle = 0.6 + 0.4 * sin(uTime * 3.0 + s * 100.0);
          sky += vec3(0.9, 0.95, 1.0) * uStarIntensity * twinkle * smoothstep(0.08, 0.35, dir.y);
        }
      }

      gl_FragColor = vec4(sky, 1.0);
    }
  `,
};

export interface TouchInputState {
  steer: number;
  throttle: number;
  brake: number;
  nitro: boolean;
  handbrake: boolean;
  fire: boolean;
}

interface DebrisChunk {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  rx: number;
  ry: number;
  life: number;
}

interface SmokePuff {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
}

interface Projectile {
  mesh: THREE.Mesh;
  active: boolean;
  fromEnemy: boolean;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  damage: number;
  explosiveRadius: number;
}

interface ExplosionEffect {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  maxScale: number;
}

interface TrafficCar {
  rig: VehicleRig;
  x: number;
  y: number;
  z: number;
  yaw: number;
  targetYaw: number;
  cruiseSpeed: number;
  currentSpeed: number;
  axis: 'x' | 'z';
  dir: 1 | -1;
  roadCoord: number;
  laneCoord: number;
  turnCooldown: number;
  blocked: boolean;
  id: VehicleId;
  color: string;
}

interface PoliceCar {
  rig: VehicleRig;
  x: number;
  y: number;
  z: number;
  yaw: number;
  speed: number;
  hp: number;
  active: boolean;
}

interface PoliceHelicopter {
  rig: PoliceHelicopterRig;
  x: number;
  y: number;
  z: number;
  yaw: number;
  orbitAngle: number;
  hp: number;
  maxHp: number;
  active: boolean;
  crashing: boolean;
  crashTimer: number;
  fireCooldown: number;
}

interface RemotePeerActor {
  id: string;
  carRig: VehicleRig;
  charRig: CharacterRig;
  vehicleId: VehicleId;
  vehicleColor: string;
  charConfigKey: string;
  targetX: number;
  targetY: number;
  targetZ: number;
  targetYaw: number;
  curX: number;
  curY: number;
  curZ: number;
  curYaw: number;
  onFoot: boolean;
  speed: number;
  lastSeen: number;
}

interface PedestrianActor {
  rig: CharacterRig;
  x: number;
  z: number;
  homeX: number;
  homeZ: number;
  yaw: number;
  walkRadius: number;
  speed: number;
  alive: boolean;
  respawnTimer: number;
  turnTimer: number;
}

interface CityFire {
  group: THREE.Group;
  flame1: THREE.Mesh;
  flame2: THREE.Mesh;
  x: number;
  z: number;
  hp: number;
  active: boolean;
  smokeAccum: number;
}

interface WaterJetParticle {
  mesh: THREE.Mesh;
  active: boolean;
  vx: number;
  vy: number;
  vz: number;
  life: number;
}

interface RogueBountyCar {
  rig: VehicleRig;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  active: boolean;
}

export interface EngineCallbacks {
  onTelemetry: (t: LiveTelemetry) => void;
  onMissionComplete: (mission: MissionDef) => void;
  onMissionFailed: (mission: MissionDef, reason: string) => void;
  onJobComplete: (job: JobDef) => void;
  onJobFailed: (job: JobDef, reason: string) => void;
  onPlayerBusted: (fineAmount: number, wantedStars: number) => void;
  onPlayerWasted: (billAmount: number, hospitalName: string) => void;
  onPropSmashed: (propId: number, vx: number, vz: number, totalCount: number) => void;
  onCombatReward: (cash: number, rep: number, label: string) => void;
  onTopSpeedRecord: (speedKmh: number) => void;
  onWebglError: (msg: string) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private sound: SoundEngine;
  private callbacks: EngineCallbacks;

  private isSoftwareGl = false;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private speedWarpPass: ShaderPass | null = null;
  private skyDome!: THREE.Mesh;
  private skyMaterial!: THREE.ShaderMaterial;
  private textures!: ProceduralTexturePack;
  private world!: IndiaWorldHandles;

  private sunLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private cubeRenderTarget: THREE.WebGLCubeRenderTarget | null = null;
  private cubeCamera: THREE.CubeCamera | null = null;
  private reflectionFrameCounter = 0;

  // Player state
  private playerVehicleId: VehicleId = 'ferrari_sf90';
  private playerVehicleColor = '#d91616';
  private selectedWeapon: WeaponId = 'pistol';
  private playerCharConfig: CharacterConfig;
  private playerCarRig!: VehicleRig;
  private playerCharRig!: CharacterRig;
  private aircraftRig!: AircraftRig;

  private inAircraft = false;
  private airSpeed = 0;
  private airPitch = 0;
  private airRoll = 0;

  private carX = 160;
  private carY = 0;
  private carZ = -80;
  private carVx = 0;
  private carVy = 0;
  private carVz = 0;
  private carYaw = 0;
  private carSteerAngle = 0;
  private carAirborne = false;
  private carAirtime = 0;
  private carPitch = 0;
  private carRoll = 0;

  private onFoot = false;
  private footX = 163;
  private footY = 0;
  private footZ = -80;
  private footVy = 0;
  private footYaw = 0;

  private nitro = 100;
  private fuel = 100;
  private armor = 0;
  private health = 100;
  private maxHealth = 100;
  private smoothThrottle = 0;
  private nitroBlend = 0;
  private wantedLevel = 0;
  private wantedDecayTimer = 0;
  private bustedProgress = 0;
  private bustedCooldown = 0;
  private driftScore = 0;
  private totalSmashed = 0;
  private bestSpeedKmh = 0;

  // Weapons & projectiles
  private fireCooldown = 0;
  private aimingTimer = 0;
  private mouseFireDown = false;
  private projectilePool: Projectile[] = [];
  private projectileCursor = 0;
  private explosionPool: ExplosionEffect[] = [];
  private explosionCursor = 0;

  // Modes & atmosphere
  private isTitleShowcase = true;
  private paused = false;
  private cameraMode: CameraMode = 'chase';
  private weatherMode: WeatherMode = 'sunset';
  private graphicsPreset: GraphicsPreset = 'ultra4k';
  private lightningTimer = 0;
  private lightningFlash = 0;

  // Rain, wind-streaks, smoke & debris pools
  private rainMesh!: THREE.InstancedMesh;
  private rainOffsets!: Float32Array;
  private windStreakMesh!: THREE.InstancedMesh;
  private windOffsets!: Float32Array;
  private smokePool: SmokePuff[] = [];
  private smokeCursor = 0;
  private debrisPool: DebrisChunk[] = [];
  private debrisCursor = 0;

  // Traffic, pedestrians, ground police & police helicopters
  private trafficCars: TrafficCar[] = [];
  private pedestrians: PedestrianActor[] = [];
  private policeCars: PoliceCar[] = [];
  private policeHelicopters: PoliceHelicopter[] = [];

  // Fire Brigade, City Fires, Water Jet & Trains
  private firePool: CityFire[] = [];
  private waterJetPool: WaterJetParticle[] = [];
  private waterJetCursor = 0;
  private aiFireRig!: VehicleRig;
  private aiFirePos = { x: 485, z: -28, yaw: 0, active: false };
  private fireSpawnTimer = 14;
  private metroProgress = 0.2;
  private metroDir = 1;
  private metroPause = 0;
  private expressX = -480;
  private expressPause = 2.0;
  private expressHornCooldown = 0;

  // Career Jobs
  private activeJob: JobDef | null = null;
  private jobStageIdx = 0;
  private jobTimeLeft = 0;
  private jobWaypoints: Array<{ x: number; z: number; label: string }> = [];
  private rogueCar!: RogueBountyCar;

  // Mission & GPS waypoint
  private activeMission: MissionDef | null = null;
  private missionWaypointIdx = 0;
  private missionSmashCount = 0;
  private missionTimeLeft = 0;
  private customWaypoint: { x: number; z: number } | null = null;
  private waypointBeacon!: THREE.Group;
  private gpsRibbonMesh!: THREE.Mesh;
  private gpsRibbonPositions!: Float32Array;
  private gpsArrowInst!: THREE.InstancedMesh;
  private gpsArrowPositions: Array<{ x: number; y: number; z: number; yaw: number }> = [];
  private gpsRoutePoints: GpsPoint[] = [];
  private lastGpsOriginX = 1e9;
  private lastGpsOriginZ = 1e9;
  private lastGpsDestX = 1e9;
  private lastGpsDestZ = 1e9;

  // Multiplayer peers
  private remotePeers = new Map<string, RemotePeerActor>();

  // Input state
  private keys: Record<string, boolean> = {};
  private touchInput: TouchInputState = {
    steer: 0,
    throttle: 0,
    brake: 0,
    nitro: false,
    handbrake: false,
    fire: false,
  };

  // Loop timing & game feel
  private frameId = 0;
  private disposed = false;
  private lastTime = 0;
  private elapsedTime = 0;
  private hitstopTimer = 0;
  private cameraTrauma = 0;
  private currentSpeedRatio = 0;
  private currentNitroActive = false;
  private telemetryAccum = 0;
  private titleAngle = 0;

  constructor(
    container: HTMLElement,
    sound: SoundEngine,
    initial: {
      vehicleId: VehicleId;
      vehicleColor: string;
      weaponId: WeaponId;
      characterConfig: CharacterConfig;
      weather: WeatherMode;
      graphics: GraphicsPreset;
      district: DistrictId;
      totalSmashed: number;
      bestSpeedKmh: number;
      maxHealth?: number;
    },
    callbacks: EngineCallbacks,
  ) {
    this.container = container;
    this.sound = sound;
    this.callbacks = callbacks;
    this.playerVehicleId = initial.vehicleId;
    this.playerVehicleColor = initial.vehicleColor;
    this.selectedWeapon = initial.weaponId || 'pistol';
    this.playerCharConfig = { ...initial.characterConfig };
    this.weatherMode = initial.weather;
    this.graphicsPreset = initial.graphics;
    this.totalSmashed = initial.totalSmashed;
    this.bestSpeedKmh = initial.bestSpeedKmh;
    this.maxHealth = Math.max(100, initial.maxHealth || 100);
    this.health = this.maxHealth;

    const d = resolveRajasthanDistrict(initial.district);
    this.carX = d.x;
    this.carZ = d.z;
    this.footX = d.x + 3;
    this.footZ = d.z;

    this.initThree();
  }

  private detectSoftwareGl(): boolean {
    try {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      return true;
    }
  }

  private initThree(): void {
    this.isSoftwareGl = this.detectSoftwareGl();

    try {
      this.renderer = new THREE.WebGLRenderer({
        antialias: !this.isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      this.callbacks.onWebglError('WebGL initialization unavailable');
      return;
    }

    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;

    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(w, h);
    this.applyPixelRatio();

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      this.callbacks.onWebglError('WebGL context lost');
    });
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(62, w / h, 0.25, 3400);

    // Procedural Atmospheric Sky Dome
    this.skyMaterial = new THREE.ShaderMaterial({
      uniforms: THREE.UniformsUtils.clone(SkyDomeShader.uniforms),
      vertexShader: SkyDomeShader.vertexShader,
      fragmentShader: SkyDomeShader.fragmentShader,
      side: THREE.BackSide,
      depthWrite: false,
    });
    this.skyDome = new THREE.Mesh(new THREE.SphereGeometry(2800, 24, 16), this.skyMaterial);
    this.scene.add(this.skyDome);

    // Studio RoomEnvironment for crisp PBR metallic/clearcoat reflections
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // Lighting rig: warm directional key light + cool HemisphereLight fill
    this.hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x33261d, 0.78);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xffedd5, 2.35);
    this.sunLight.position.set(70, 95, 55);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    this.sunLight.shadow.camera.near = 5;
    this.sunLight.shadow.camera.far = 260;
    const sd = 85;
    this.sunLight.shadow.camera.left = -sd;
    this.sunLight.shadow.camera.right = sd;
    this.sunLight.shadow.camera.top = sd;
    this.sunLight.shadow.camera.bottom = -sd;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.025;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Procedural textures & Open-World India Map
    this.textures = createProceduralTextures(this.renderer);
    this.world = buildIndiaWorld(this.textures, this.isSoftwareGl);
    this.scene.add(this.world.worldGroup);

    // Player Hypercar, Customizable Character & Private Jet
    this.spawnPlayerVehicle(this.playerVehicleId, this.playerVehicleColor);
    this.playerCharRig = buildCharacterModel(this.playerCharConfig, this.textures);
    this.playerCharRig.setWeapon(this.selectedWeapon);
    this.playerCharRig.root.visible = false;
    this.scene.add(this.playerCharRig.root);

    this.aircraftRig = buildJetAircraft('#0284c7', this.isSoftwareGl);
    this.aircraftRig.root.visible = false;
    this.scene.add(this.aircraftRig.root);

    // Dynamic CubeCamera for Ultra 4K Real-Time Reflections (GPU only)
    if (!this.isSoftwareGl) {
      this.cubeRenderTarget = new THREE.WebGLCubeRenderTarget(256, {
        generateMipmaps: true,
        minFilter: THREE.LinearMipmapLinearFilter,
      });
      this.cubeCamera = new THREE.CubeCamera(0.5, 450, this.cubeRenderTarget);
      this.scene.add(this.cubeCamera);
      if (this.graphicsPreset === 'ultra4k') {
        this.playerCarRig.paintMaterial.envMap = this.cubeRenderTarget.texture;
      }
    }

    // Post-processing composer with UnrealBloom + Custom Radial SpeedWarpShader (GPU only)
    if (!this.isSoftwareGl) {
      this.composer = new EffectComposer(this.renderer);
      this.composer.addPass(new RenderPass(this.scene, this.camera));
      this.bloomPass = new UnrealBloomPass(new THREE.Vector2(w, h), 0.36, 0.4, 0.9);
      this.composer.addPass(this.bloomPass);
      this.speedWarpPass = new ShaderPass(SpeedWarpShader);
      this.composer.addPass(this.speedWarpPass);
      this.composer.addPass(new OutputPass());
    }

    this.buildWaypointBeacon();
    this.initDebrisPool();
    this.initSmokePool();
    this.initProjectileAndExplosionPools();
    this.initFireAndWaterPools();
    this.initRainPool();
    this.initWindStreakPool();
    this.initTrafficAndPolice();
    this.initPedestrians();

    this.setWeather(this.weatherMode);
    this.setGraphicsPreset(this.graphicsPreset);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.lastTime = performance.now();
    this.tick();
  }

  private buildWaypointBeacon(): void {
    this.waypointBeacon = new THREE.Group();
    const beamMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
    });
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 85, 16, 1, true), beamMat);
    beam.position.y = 42.5;
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(4.2, 0.32, 8, 28),
      new THREE.MeshBasicMaterial({ color: 0xfbbf24 }),
    );
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.4;
    this.waypointBeacon.add(beam, ring);
    this.waypointBeacon.visible = false;
    this.scene.add(this.waypointBeacon);

    // 3D Road-Following GPS Highlight Ribbon (preallocated quad strip)
    const maxSegs = 128;
    const ribbonGeo = new THREE.BufferGeometry();
    this.gpsRibbonPositions = new Float32Array((maxSegs + 1) * 2 * 3);
    ribbonGeo.setAttribute('position', new THREE.BufferAttribute(this.gpsRibbonPositions, 3));
    const indices: number[] = [];
    for (let i = 0; i < maxSegs; i++) {
      const v0 = i * 2;
      const v1 = v0 + 1;
      const v2 = v0 + 2;
      const v3 = v0 + 3;
      indices.push(v0, v2, v1, v1, v2, v3);
    }
    ribbonGeo.setIndex(indices);
    ribbonGeo.setDrawRange(0, 0);
    const ribbonMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      transparent: true,
      opacity: 0.56,
      side: THREE.DoubleSide,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      polygonOffsetUnits: -4,
    });
    this.gpsRibbonMesh = new THREE.Mesh(ribbonGeo, ribbonMat);
    this.gpsRibbonMesh.frustumCulled = false;
    this.gpsRibbonMesh.visible = false;
    this.scene.add(this.gpsRibbonMesh);

    // 3D Glowing Amber Directional GPS Chevrons along the road path
    const arrowGeo = new THREE.ConeGeometry(0.95, 2.2, 3);
    arrowGeo.rotateX(-Math.PI / 2);
    arrowGeo.scale(1.15, 0.16, 1.0);
    const arrowMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      transparent: true,
      opacity: 0.92,
      depthWrite: false,
    });
    this.gpsArrowInst = new THREE.InstancedMesh(arrowGeo, arrowMat, 120);
    this.gpsArrowInst.frustumCulled = false;
    this.gpsArrowInst.count = 0;
    this.gpsArrowInst.visible = false;
    this.scene.add(this.gpsArrowInst);
  }

  private initDebrisPool(): void {
    const geo = new THREE.BoxGeometry(0.55, 0.42, 0.55);
    for (let i = 0; i < 64; i++) {
      const mat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.7 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      mesh.castShadow = !this.isSoftwareGl;
      this.scene.add(mesh);
      this.debrisPool.push({ mesh, vx: 0, vy: 0, vz: 0, rx: 0, ry: 0, life: 0 });
    }
  }

  private initSmokePool(): void {
    const geo = new THREE.SphereGeometry(0.45, 7, 6);
    for (let i = 0; i < 48; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xe2e8f0,
        transparent: true,
        opacity: 0.4,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.smokePool.push({ mesh, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 0.65 });
    }
  }

  private spawnSmokePuff(x: number, y: number, z: number): void {
    const puff = this.smokePool[this.smokeCursor];
    this.smokeCursor = (this.smokeCursor + 1) % this.smokePool.length;
    puff.mesh.visible = true;
    puff.mesh.position.set(x + (Math.random() - 0.5) * 0.4, y + 0.18, z + (Math.random() - 0.5) * 0.4);
    puff.mesh.scale.setScalar(0.6);
    puff.vx = (Math.random() - 0.5) * 1.8;
    puff.vy = 0.8 + Math.random() * 1.4;
    puff.vz = (Math.random() - 0.5) * 1.8;
    puff.life = 0.6;
    puff.maxLife = 0.6;
  }

  private spawnDebrisBurst(x: number, z: number, colorHex: number, impactVx: number, impactVz: number): void {
    for (let i = 0; i < 6; i++) {
      const chunk = this.debrisPool[this.debrisCursor];
      this.debrisCursor = (this.debrisCursor + 1) % this.debrisPool.length;
      chunk.mesh.visible = true;
      chunk.mesh.position.set(x + (Math.random() - 0.5) * 1.4, 0.6 + Math.random() * 1.2, z + (Math.random() - 0.5) * 1.4);
      (chunk.mesh.material as THREE.MeshStandardMaterial).color.setHex(colorHex);
      chunk.vx = impactVx * 0.45 + (Math.random() - 0.5) * 14;
      chunk.vy = 5 + Math.random() * 9;
      chunk.vz = impactVz * 0.45 + (Math.random() - 0.5) * 14;
      chunk.rx = (Math.random() - 0.5) * 9;
      chunk.ry = (Math.random() - 0.5) * 9;
      chunk.life = 2.4;
    }
  }

  private initRainPool(): void {
    const count = 1100;
    const geo = new THREE.CylinderGeometry(0.015, 0.015, 1.45, 4);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xcbd5e1,
      transparent: true,
      opacity: 0.42,
    });
    this.rainMesh = new THREE.InstancedMesh(geo, mat, count);
    this.rainMesh.frustumCulled = false;
    this.rainMesh.visible = false;
    this.rainOffsets = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      this.rainOffsets[i * 3] = (Math.random() - 0.5) * 90;
      this.rainOffsets[i * 3 + 1] = Math.random() * 42;
      this.rainOffsets[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    this.scene.add(this.rainMesh);
  }

  private initWindStreakPool(): void {
    const count = 64;
    const geo = new THREE.CylinderGeometry(0.014, 0.014, 3.6, 4);
    geo.rotateX(Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xe0f2fe,
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
    });
    this.windStreakMesh = new THREE.InstancedMesh(geo, mat, count);
    this.windStreakMesh.frustumCulled = false;
    this.windStreakMesh.visible = false;
    this.windOffsets = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      // Tunnel around the player view (avoid blocking direct center)
      const angle = Math.random() * Math.PI * 2;
      const rad = 3.2 + Math.random() * 11;
      this.windOffsets[i * 3] = Math.cos(angle) * rad;
      this.windOffsets[i * 3 + 1] = 0.8 + Math.abs(Math.sin(angle)) * 6;
      this.windOffsets[i * 3 + 2] = (Math.random() - 0.5) * 44;
    }
    this.scene.add(this.windStreakMesh);
  }

  private computeTrafficLane(axis: 'x' | 'z', roadCoord: number, dir: 1 | -1): number {
    const laneOffset = 4.2;
    if (axis === 'x') {
      // Indian left-hand traffic: heading East (+X) stays on North (-Z) side; West (-X) stays on South (+Z)
      return roadCoord + (dir === 1 ? -laneOffset : laneOffset);
    }
    // Heading South (+Z) stays on East (+X) side; North (-Z) stays on West (-X)
    return roadCoord + (dir === 1 ? laneOffset : -laneOffset);
  }

  private computeTrafficYaw(axis: 'x' | 'z', dir: 1 | -1): number {
    if (axis === 'x') return dir === 1 ? -Math.PI / 2 : Math.PI / 2;
    return dir === 1 ? Math.PI : 0;
  }

  private initProjectileAndExplosionPools(): void {
    const bulletGeo = new THREE.SphereGeometry(0.18, 6, 6);
    for (let i = 0; i < 60; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xfde047 });
      const mesh = new THREE.Mesh(bulletGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.projectilePool.push({
        mesh,
        active: false,
        fromEnemy: false,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        damage: 25,
        explosiveRadius: 0,
      });
    }

    const expGeo = new THREE.SphereGeometry(1, 12, 10);
    for (let i = 0; i < 12; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xf97316,
        transparent: true,
        opacity: 0.85,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(expGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.explosionPool.push({ mesh, life: 0, maxLife: 0.65, maxScale: 9 });
    }
  }

  private initFireAndWaterPools(): void {
    const flameMat1 = new THREE.MeshBasicMaterial({ color: 0xf97316, transparent: true, opacity: 0.88 });
    const flameMat2 = new THREE.MeshBasicMaterial({ color: 0xfacc15, transparent: true, opacity: 0.92 });
    const emberGeo = new THREE.ConeGeometry(2.2, 5.2, 7);
    const innerGeo = new THREE.ConeGeometry(1.3, 3.6, 6);

    for (let i = 0; i < 6; i++) {
      const group = new THREE.Group();
      const flame1 = new THREE.Mesh(emberGeo, flameMat1);
      flame1.position.y = 2.6;
      const flame2 = new THREE.Mesh(innerGeo, flameMat2);
      flame2.position.y = 1.9;
      group.add(flame1, flame2);
      group.visible = false;
      this.scene.add(group);
      this.firePool.push({ group, flame1, flame2, x: 0, z: 0, hp: 100, active: false, smokeAccum: 0 });
    }

    const waterGeo = new THREE.SphereGeometry(0.32, 6, 6);
    const waterMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.82 });
    for (let i = 0; i < 48; i++) {
      const mesh = new THREE.Mesh(waterGeo, waterMat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.waterJetPool.push({ mesh, active: false, vx: 0, vy: 0, vz: 0, life: 0 });
    }

    // Seed 2 initial fires so Fire Brigade & Fire Tender gameplay is immediately live
    this.spawnCityFire(310, 82);
    this.spawnCityFire(-360, 480);
  }

  private spawnCityFire(x: number, z: number): CityFire | null {
    let slot = this.firePool.find((f) => !f.active);
    if (!slot) slot = this.firePool[0];
    slot.x = THREE.MathUtils.clamp(x, -1380, 1380);
    slot.z = THREE.MathUtils.clamp(z, -1380, 1380);
    slot.hp = 100;
    slot.active = true;
    slot.group.visible = true;
    slot.group.position.set(slot.x, this.world.groundHeightAt(slot.x, slot.z), slot.z);
    return slot;
  }

  private initTrafficAndPolice(): void {
    const trafficSpecs: Array<{ id: VehicleId; color: string; baseSpeed: number }> = [
      { id: 'auto_rickshaw', color: '#eab308', baseSpeed: 13.0 },
      { id: 'e_rickshaw', color: '#10b981', baseSpeed: 10.5 },
      { id: 'mumbai_taxi', color: '#eab308', baseSpeed: 17.5 },
      { id: 'city_sedan', color: '#e2e8f0', baseSpeed: 18.5 },
      { id: 'bullet_350', color: '#1e293b', baseSpeed: 19.0 },
      { id: 'swift_hatch', color: '#dc2626', baseSpeed: 18.5 },
      { id: 'alto_hatch', color: '#38bdf8', baseSpeed: 15.5 },
      { id: 'activa_scooter', color: '#0284c7', baseSpeed: 14.5 },
      { id: 'ambassador_classic', color: '#f1f5f9', baseSpeed: 15.5 },
      { id: 'thar_suv', color: '#b91c1c', baseSpeed: 18.0 },
      { id: 'fortuner_suv', color: '#f8fafc', baseSpeed: 19.5 },
      { id: 'jaipur_bus', color: '#dc2626', baseSpeed: 13.5 },
      { id: 'cargo_van', color: '#cbd5e1', baseSpeed: 16.0 },
      { id: 'duke_390', color: '#ea580c', baseSpeed: 22.0 },
      { id: 'ferrari_sf90', color: '#dc2626', baseSpeed: 24.5 },
      { id: 'lamborghini_svj', color: '#10b981', baseSpeed: 25.0 },
    ];

    const ewRoads = JAIPUR_EW_ROADS;
    const nsRoads = JAIPUR_NS_ROADS;

    for (let i = 0; i < 64; i++) {
      const spec = trafficSpecs[i % trafficSpecs.length];
      const rig = buildVehicleModel(spec.id, spec.color, this.textures, this.isSoftwareGl, false);
      const axis: 'x' | 'z' = i % 2 === 0 ? 'x' : 'z';
      const dir: 1 | -1 = i % 4 < 2 ? 1 : -1;
      const roadList = axis === 'x' ? ewRoads : nsRoads;
      const roadCoord = roadList[Math.floor(i / 2) % roadList.length];
      const laneCoord = this.computeTrafficLane(axis, roadCoord, dir);
      const along = -1340 + ((i * 197) % 2680);
      const x = axis === 'x' ? along : laneCoord;
      const z = axis === 'x' ? laneCoord : along;
      const y = this.world.groundHeightAt(x, z);
      const yaw = this.computeTrafficYaw(axis, dir);

      rig.root.position.set(x, y, z);
      rig.root.rotation.y = yaw;
      this.scene.add(rig.root);

      const cruiseSpeed = spec.baseSpeed + (i % 3) * 1.4;
      this.trafficCars.push({
        rig,
        x,
        y,
        z,
        yaw,
        targetYaw: yaw,
        cruiseSpeed,
        currentSpeed: cruiseSpeed,
        axis,
        dir,
        roadCoord,
        laneCoord,
        turnCooldown: 2 + (i % 5),
        blocked: false,
        id: spec.id,
        color: spec.color,
      });
    }

    for (let i = 0; i < 4; i++) {
      const rig = buildVehicleModel('police', '#1e293b', this.textures, this.isSoftwareGl, false);
      rig.root.visible = false;
      this.scene.add(rig.root);
      this.policeCars.push({ rig, x: 0, y: 0, z: 0, yaw: 0, speed: 0, hp: 100, active: false });
    }

    // AI Jaipur Fire Brigade Tender stationed at Ghat Gate HQ
    this.aiFireRig = buildVehicleModel('fire_truck', '#dc2626', this.textures, this.isSoftwareGl, false);
    this.aiFirePos = { x: this.world.fireHqPos.x, z: this.world.fireHqPos.z - 12, yaw: 0, active: false };
    this.aiFireRig.root.position.set(this.aiFirePos.x, 0, this.aiFirePos.z);
    this.scene.add(this.aiFireRig.root);

    // Bounty Pursuit Rogue Gangster Car
    const rogueRig = buildVehicleModel('lamborghini_svj', '#7c3aed', this.textures, this.isSoftwareGl, false);
    rogueRig.root.visible = false;
    this.scene.add(rogueRig.root);
    this.rogueCar = { rig: rogueRig, x: 0, z: 0, yaw: 0, hp: 160, active: false };

    // 2 Composite Police Helicopters
    for (let i = 0; i < 2; i++) {
      const rig = buildPoliceHelicopter(this.textures, this.isSoftwareGl);
      rig.root.visible = false;
      this.scene.add(rig.root);
      this.scene.add(rig.groundSpot);
      this.policeHelicopters.push({
        rig,
        x: POLICE_STATION.x,
        y: 45,
        z: POLICE_STATION.z,
        yaw: 0,
        orbitAngle: i * Math.PI,
        hp: 100,
        maxHp: 100,
        active: false,
        crashing: false,
        crashTimer: 0,
        fireCooldown: 2.2,
      });
    }
  }

  private initPedestrians(): void {
    const outfitPalette = ['#f59e0b', '#ec4899', '#3b82f6', '#10b981', '#e11d48', '#f97316', '#8b5cf6', '#eab308'];
    const skinTones = ['#d2996c', '#c68642', '#8d5524', '#e0ac69'];
    const headgearOpts: CharacterConfig['headgear'][] = ['turban', 'fade', 'cap', 'turban'];

    const patrolHubs: Array<{ x: number; z: number; radius: number }> = JAIPUR_LOCALITIES.slice(0, 22).map((loc) => ({
      x: loc.x + 12,
      z: loc.z + 12,
      radius: 20,
    }));

    for (let i = 0; i < 36; i++) {
      const hub = patrolHubs[i % patrolHubs.length];
      const ang = (i * 2.399) % (Math.PI * 2);
      const dist = 4 + (i % 4) * 3.5;
      const x = hub.x + Math.cos(ang) * dist;
      const z = hub.z + Math.sin(ang) * dist;

      const rig = buildCharacterModel(
        {
          archetype: i % 3 === 0 ? 'royal' : 'racer',
          outfitColor: outfitPalette[i % outfitPalette.length],
          skinTone: skinTones[i % skinTones.length],
          headgear: headgearOpts[i % headgearOpts.length],
          eyewear: 'none',
        },
        this.textures,
      );
      rig.setWeapon('fists');
      rig.root.position.set(x, this.world.groundHeightAt(x, z), z);
      this.scene.add(rig.root);

      this.pedestrians.push({
        rig,
        x,
        z,
        homeX: hub.x,
        homeZ: hub.z,
        yaw: ang,
        walkRadius: hub.radius,
        speed: 2.1 + (i % 3) * 0.45,
        alive: true,
        respawnTimer: 0,
        turnTimer: 1.5 + (i % 4),
      });
    }
  }

  private spawnPlayerVehicle(vehicleId: VehicleId, color: string): void {
    if (this.playerCarRig) {
      this.scene.remove(this.playerCarRig.root);
    }
    this.playerVehicleId = vehicleId;
    this.playerVehicleColor = color;
    this.playerCarRig = buildVehicleModel(vehicleId, color, this.textures, this.isSoftwareGl, true);
    this.playerCarRig.root.position.set(this.carX, this.carY, this.carZ);
    this.playerCarRig.root.rotation.y = this.carYaw;
    if (this.cubeRenderTarget && this.graphicsPreset === 'ultra4k' && !this.isSoftwareGl) {
      this.playerCarRig.paintMaterial.envMap = this.cubeRenderTarget.texture;
    }
    this.scene.add(this.playerCarRig.root);
    this.applyVehicleLightsForWeather();
  }

  private applyVehicleLightsForWeather(): void {
    if (!this.playerCarRig) return;
    const isNightOrRain = this.weatherMode === 'night' || this.weatherMode === 'monsoon';
    for (const sp of this.playerCarRig.headlightSpots) {
      sp.intensity = isNightOrRain ? 30 : 5;
    }
  }

  setTitleShowcase(active: boolean): void {
    this.isTitleShowcase = active;
    if (active) {
      this.sound.silenceLoops();
    }
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
    if (paused) {
      this.sound.silenceLoops();
    }
  }

  setCameraMode(mode: CameraMode): void {
    this.cameraMode = mode;
  }

  cycleCamera(): CameraMode {
    const order: CameraMode[] = ['chase', 'action', 'hood', 'cinematic'];
    const next = order[(order.indexOf(this.cameraMode) + 1) % order.length];
    this.cameraMode = next;
    return next;
  }

  setVehicle(vehicleId: VehicleId, color: string): void {
    this.spawnPlayerVehicle(vehicleId, color);
    if (this.inAircraft) {
      this.inAircraft = false;
      this.aircraftRig.root.visible = false;
      this.playerCarRig.root.visible = true;
    }
    if (this.onFoot) {
      this.onFoot = false;
      this.playerCharRig.root.visible = false;
    }
  }

  setPaintColor(color: string): void {
    this.playerVehicleColor = color;
    this.playerCarRig?.setPaintColor(color);
  }

  setWeapon(weaponId: WeaponId): void {
    this.selectedWeapon = weaponId;
    this.playerCharRig?.setWeapon(weaponId);
  }

  setCharacterConfig(cfg: CharacterConfig): void {
    this.playerCharConfig = { ...cfg };
    this.playerCharRig?.updateConfig(cfg);
  }

  setWeather(mode: WeatherMode): void {
    this.weatherMode = mode;
    const isRain = mode === 'monsoon';
    const isNight = mode === 'night';
    const isSand = mode === 'sandstorm';
    const isClear = mode === 'clear';

    const skyU = this.skyMaterial.uniforms;

    if (isNight) {
      this.scene.fog = new THREE.FogExp2(0x070b19, 0.0024);
      skyU.uTopColor.value.setHex(0x030712);
      skyU.uHorizonColor.value.setHex(0x0f172a);
      skyU.uSunColor.value.setHex(0x93c5fd);
      skyU.uSunDir.value.set(-0.4, 0.35, -0.6).normalize();
      skyU.uStarIntensity.value = 0.95;
      skyU.uCloudIntensity.value = 0.18;

      this.sunLight.color.setHex(0x818cf8);
      this.sunLight.intensity = 0.85;
      this.hemiLight.color.setHex(0x312e81);
      this.hemiLight.groundColor.setHex(0x0f172a);
      this.hemiLight.intensity = 0.62;
      this.world.techGlassMat.emissiveIntensity = 2.25;
    } else if (isRain) {
      this.scene.fog = new THREE.FogExp2(0x1e293b, 0.0042);
      skyU.uTopColor.value.setHex(0x0f172a);
      skyU.uHorizonColor.value.setHex(0x334155);
      skyU.uSunColor.value.setHex(0x94a3b8);
      skyU.uStarIntensity.value = 0.0;
      skyU.uCloudIntensity.value = 0.85;

      this.sunLight.color.setHex(0x94a3b8);
      this.sunLight.intensity = 1.25;
      this.hemiLight.color.setHex(0x64748b);
      this.hemiLight.groundColor.setHex(0x1e293b);
      this.hemiLight.intensity = 0.72;
      this.world.techGlassMat.emissiveIntensity = 1.4;
    } else if (isSand) {
      this.scene.fog = new THREE.FogExp2(0xd99b66, 0.0048);
      skyU.uTopColor.value.setHex(0x92400e);
      skyU.uHorizonColor.value.setHex(0xd99b66);
      skyU.uSunColor.value.setHex(0xfef08a);
      skyU.uStarIntensity.value = 0.0;
      skyU.uCloudIntensity.value = 0.45;

      this.sunLight.color.setHex(0xfde68a);
      this.sunLight.intensity = 2.15;
      this.hemiLight.color.setHex(0xfbbf24);
      this.hemiLight.groundColor.setHex(0x78350f);
      this.hemiLight.intensity = 0.76;
      this.world.techGlassMat.emissiveIntensity = 0.55;
    } else if (isClear) {
      this.scene.fog = new THREE.FogExp2(0x7dd3fc, 0.0014);
      skyU.uTopColor.value.setHex(0x0284c7);
      skyU.uHorizonColor.value.setHex(0xbae6fd);
      skyU.uSunColor.value.setHex(0xfffbeb);
      skyU.uSunDir.value.set(0.45, 0.68, 0.35).normalize();
      skyU.uStarIntensity.value = 0.0;
      skyU.uCloudIntensity.value = 0.38;

      this.sunLight.color.setHex(0xfffbeb);
      this.sunLight.intensity = 2.45;
      this.hemiLight.color.setHex(0xbae6fd);
      this.hemiLight.groundColor.setHex(0x475569);
      this.hemiLight.intensity = 0.85;
      this.world.techGlassMat.emissiveIntensity = 0.45;
    } else {
      // Golden Sunset
      this.scene.fog = new THREE.FogExp2(0xd97706, 0.0021);
      skyU.uTopColor.value.setHex(0x1e1b4b);
      skyU.uHorizonColor.value.setHex(0xf97316);
      skyU.uSunColor.value.setHex(0xfef08a);
      skyU.uSunDir.value.set(-0.65, 0.16, 0.32).normalize();
      skyU.uStarIntensity.value = 0.25;
      skyU.uCloudIntensity.value = 0.48;

      this.sunLight.color.setHex(0xfdba74);
      this.sunLight.intensity = 2.3;
      this.hemiLight.color.setHex(0xfb923c);
      this.hemiLight.groundColor.setHex(0x1e1b4b);
      this.hemiLight.intensity = 0.75;
      this.world.techGlassMat.emissiveIntensity = 0.95;
    }

    this.rainMesh.visible = isRain;

    for (const road of this.world.roadNetworkMeshes) {
      const m = road.material as THREE.MeshStandardMaterial;
      m.roughness = isRain ? 0.45 : 0.94;
      m.metalness = isRain ? 0.04 : 0.0;
      m.envMapIntensity = isRain ? 0.52 : 0.16;
    }

    for (const nm of this.world.neonMaterials) {
      nm.emissiveIntensity = isNight || isRain ? 3.2 : 1.75;
    }

    this.applyVehicleLightsForWeather();
  }

  setGraphicsPreset(preset: GraphicsPreset): void {
    this.graphicsPreset = preset;
    this.applyPixelRatio();
    if (!this.isSoftwareGl) {
      this.renderer.shadowMap.enabled = true;
      const mapDim = preset === 'ultra4k' ? 2048 : preset === 'high' ? 1024 : 512;
      if (this.sunLight.shadow.mapSize.width !== mapDim) {
        this.sunLight.shadow.mapSize.set(mapDim, mapDim);
        this.sunLight.shadow.map?.dispose();
        this.sunLight.shadow.map = null;
      }
      if (this.bloomPass) {
        this.bloomPass.enabled = preset !== 'mobile';
        this.bloomPass.strength = preset === 'ultra4k' ? 0.36 : 0.24;
        this.bloomPass.threshold = 0.9;
      }
      if (this.speedWarpPass) {
        this.speedWarpPass.enabled = preset !== 'mobile';
      }
      if (this.playerCarRig && this.cubeRenderTarget) {
        this.playerCarRig.paintMaterial.envMap = preset === 'ultra4k' ? this.cubeRenderTarget.texture : null;
        this.playerCarRig.paintMaterial.needsUpdate = true;
      }
    }
  }

  private applyPixelRatio(): void {
    if (!this.renderer) return;
    if (this.isSoftwareGl) {
      this.renderer.setPixelRatio(1);
      return;
    }
    const maxDpr = this.graphicsPreset === 'ultra4k' ? 2 : this.graphicsPreset === 'high' ? 1.5 : 1;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr));
  }

  teleportToDistrict(districtId: DistrictId): void {
    const d = resolveRajasthanDistrict(districtId);
    this.teleportToCoords(d.x, d.z);
  }

  teleportToCoords(x: number, z: number): void {
    if (this.inAircraft) {
      this.inAircraft = false;
      this.aircraftRig.root.visible = false;
      this.playerCarRig.root.visible = !this.onFoot;
    }
    this.carX = x;
    this.carZ = z;
    this.carY = this.world.groundHeightAt(x, z);
    this.carVx = 0;
    this.carVy = 0;
    this.carVz = 0;
    this.footX = x + 3.2;
    this.footZ = z;
    this.footY = this.world.groundHeightAt(this.footX, this.footZ);
  }

  boardAirportJet(airportId = 'airport_jaipur'): void {
    const fac = WORLD_FACILITIES.find((f) => f.id === airportId && f.type === 'airport')
      || WORLD_FACILITIES.find((f) => f.type === 'airport');
    const runwayX = fac ? fac.x - 125 : 115;
    const runwayZ = fac ? fac.z + 95 : 1205;

    this.onFoot = false;
    this.inAircraft = true;
    this.playerCharRig.root.visible = false;
    this.playerCarRig.root.visible = false;

    this.carX = runwayX;
    this.carZ = runwayZ;
    this.carY = this.world.groundHeightAt(runwayX, runwayZ);
    this.carVx = 0;
    this.carVy = 0;
    this.carVz = 0;
    this.carYaw = -Math.PI / 2; // Facing East down Runway 09 -> 27
    this.airSpeed = 0;
    this.airPitch = 0;
    this.airRoll = 0;

    this.aircraftRig.root.visible = true;
    this.aircraftRig.root.position.set(this.carX, this.carY, this.carZ);
    this.aircraftRig.root.rotation.set(0, this.carYaw, 0, 'YXZ');
    this.aircraftRig.landingGear.visible = true;
    this.sound.playMissionStinger(true);
  }

  playPlayerHorn(): void {
    this.sound.playHorn(this.playerVehicleId, this.inAircraft);
  }

  setCustomWaypoint(x: number, z: number): void {
    this.customWaypoint = { x, z };
    this.lastGpsDestX = 1e9;
  }

  getGpsRoutePoints(): GpsPoint[] {
    return this.gpsRoutePoints;
  }

  getBlueprintBuildings(): BlueprintBuilding[] {
    return this.world ? this.world.blueprintBuildings : [];
  }

  getEnterableBuildings(): EnterableBuildingInfo[] {
    return this.world ? this.world.enterableBuildings : [];
  }

  getActiveWaypoint(): { x: number; z: number } | null {
    if (this.activeJob) {
      if (this.activeJob.id === 'police_bounty' && this.rogueCar?.active) {
        return { x: this.rogueCar.x, z: this.rogueCar.z };
      }
      const jwp = this.jobWaypoints[this.jobStageIdx] || this.jobWaypoints[0];
      if (jwp) return { x: jwp.x, z: jwp.z };
    }
    if (this.activeMission) {
      const wp = this.activeMission.waypoints[this.missionWaypointIdx] || this.activeMission.waypoints[0];
      if (wp) return { x: wp.x, z: wp.z };
    }
    return this.customWaypoint;
  }

  setMaxHealth(hp: number): void {
    this.maxHealth = Math.max(100, hp);
    this.health = Math.min(this.health, this.maxHealth);
  }

  healPlayer(amount?: number, newMaxHp?: number): void {
    if (newMaxHp !== undefined) {
      this.maxHealth = Math.max(100, newMaxHp);
    }
    if (amount === undefined) {
      this.health = this.maxHealth;
    } else {
      this.health = Math.min(this.maxHealth, this.health + amount);
    }
  }

  restAtHome(): void {
    this.health = this.maxHealth;
    this.nitro = 100;
    this.fuel = 100;
    this.clearWanted();
  }

  refuelVehicle(amount = 100): void {
    this.fuel = Math.min(100, this.fuel + amount);
    this.sound.playFuelPump();
  }

  repairVehicle(): void {
    this.nitro = 100;
    this.health = Math.min(this.maxHealth, this.health + 20);
  }

  refillNitro(): void {
    this.nitro = 100;
  }

  addArmor(amount: number): void {
    this.armor = Math.min(100, this.armor + amount);
  }

  getFuel(): number {
    return Math.round(this.fuel);
  }

  getArmor(): number {
    return Math.round(this.armor);
  }

  spawnServiceVehicle(vehicleId: VehicleId, color?: string): void {
    const spec = VEHICLE_CATALOG[vehicleId];
    this.fuel = 100;
    this.nitro = 100;
    this.setVehicle(vehicleId, color || spec.defaultColor);
  }

  triggerRobberyAlert(x: number, z: number, stars = 2): void {
    this.wantedLevel = Math.min(5, Math.max(this.wantedLevel + 1, stars));
    this.wantedDecayTimer = 20;
    this.sound.playRobberyAlarm();
    this.spawnPoliceBehindPlayer();
    if (Math.hypot(x - this.carX, z - this.carZ) > 35) {
      this.customWaypoint = null;
    }
  }

  startJob(jobType: JobType): void {
    const def = JOBS_CATALOG.find((j) => j.id === jobType);
    if (!def) return;
    this.activeMission = null;
    this.activeJob = def;
    this.jobStageIdx = 0;
    this.jobTimeLeft = def.timeLimitSec;
    this.customWaypoint = null;
    this.rogueCar.active = false;
    this.rogueCar.rig.root.visible = false;

    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;

    if (jobType === 'bus_driver') {
      if (this.playerVehicleId !== 'jaipur_bus' || this.onFoot) {
        this.spawnServiceVehicle('jaipur_bus');
      }
      this.jobWaypoints = [
        { x: 160, z: -210, label: 'Board Passengers · Badi Chaupar' },
        { x: 160, z: 140, label: 'Stop 2 · Albert Hall Circle' },
        { x: 160, z: 340, label: 'Stop 3 · Rambagh Circle' },
        { x: 160, z: 840, label: 'Terminus · Patrika Gate' },
      ];
    } else if (jobType === 'firefighter') {
      if (this.playerVehicleId !== 'fire_truck' || this.onFoot) {
        this.spawnServiceVehicle('fire_truck');
      }
      let activeFire = this.firePool.find((f) => f.active);
      if (!activeFire) {
        activeFire = this.spawnCityFire(px + 220, pz - 160) || this.firePool[0];
      }
      this.jobWaypoints = [{ x: activeFire.x, z: activeFire.z, label: 'Drive Fire Tender to Blaze & Spray [E]' }];
    } else if (jobType === 'cash_escort') {
      if (this.playerVehicleId !== 'cargo_van' || this.onFoot) {
        this.spawnServiceVehicle('cargo_van');
      }
      this.jobWaypoints = [
        { x: 52, z: 190, label: 'Load Bullion · State Bank MI Rd' },
        { x: 400, z: 632, label: 'Deliver Bullion · WTP Vault' },
      ];
    } else if (jobType === 'ambulance') {
      if (this.onFoot) this.spawnServiceVehicle('cargo_van', '#f8fafc');
      this.jobWaypoints = [
        { x: -240, z: -210, label: 'Pick Up Patient · Choti Chaupar' },
        { x: 180, z: 205, label: 'Rush to SMS Medical Hospital' },
      ];
    } else if (jobType === 'food_delivery') {
      if (this.onFoot) this.spawnServiceVehicle('activa_scooter');
      this.jobWaypoints = [
        { x: 186, z: -245, label: 'Collect Hot Order · LMB Johari' },
        { x: -206, z: 160, label: 'Deliver Order · C-Scheme' },
        { x: 390, z: 195, label: 'Deliver Order · Raja Park' },
      ];
    } else if (jobType === 'office_teacher') {
      if (this.onFoot) this.spawnServiceVehicle('city_sedan');
      this.jobWaypoints = [
        { x: 186, z: 300, label: 'Collect Exam Dossier · SMS School' },
        { x: -94, z: 385, label: 'Submit Files · Secretariat Office' },
        { x: 388, z: 635, label: 'Final Audit · WTP Chambers' },
      ];
    } else if (jobType === 'police_bounty') {
      if (this.onFoot) this.spawnServiceVehicle('fortuner_suv', '#1e293b');
      this.rogueCar.x = THREE.MathUtils.clamp(px + 135, -1320, 1320);
      this.rogueCar.z = THREE.MathUtils.clamp(pz - 95, -1320, 1320);
      this.rogueCar.hp = 140;
      this.rogueCar.active = true;
      this.rogueCar.rig.root.visible = true;
      this.jobWaypoints = [{ x: this.rogueCar.x, z: this.rogueCar.z, label: 'Destroy Fleeing Gangster Car' }];
    } else {
      // cab_driver
      if (this.onFoot) this.spawnServiceVehicle('mumbai_taxi');
      this.jobWaypoints = [
        { x: -480, z: 232, label: 'Pick Up Fare · Jaipur Junction' },
        { x: 160, z: -210, label: 'Drop Passenger · Hawa Mahal' },
      ];
    }
    this.lastGpsDestX = 1e9;
    this.sound.playMissionStinger(true);
  }

  cancelJob(): void {
    this.activeJob = null;
    this.rogueCar.active = false;
    this.rogueCar.rig.root.visible = false;
  }

  startMission(mission: MissionDef): void {
    this.activeJob = null;
    this.rogueCar.active = false;
    this.rogueCar.rig.root.visible = false;
    this.activeMission = mission;
    this.missionWaypointIdx = 0;
    this.missionSmashCount = 0;
    this.missionTimeLeft = mission.timeLimitSec;
    this.customWaypoint = null;

    if (mission.type === 'survival') {
      this.wantedLevel = Math.max(4, this.wantedLevel);
      this.wantedDecayTimer = 22;
      this.setWeather('monsoon');
    } else {
      const d = resolveRajasthanDistrict(mission.district);
      const dist = Math.hypot(this.carX - d.x, this.carZ - d.z);
      if (dist > 180) {
        this.teleportToDistrict(mission.district);
      }
    }
    this.sound.playMissionStinger(true);
  }

  cancelMission(): void {
    this.activeMission = null;
  }

  clearWanted(): void {
    this.wantedLevel = 0;
    this.bustedProgress = 0;
    for (const pc of this.policeCars) {
      pc.active = false;
      pc.rig.root.visible = false;
    }
    for (const h of this.policeHelicopters) {
      h.active = false;
      h.crashing = false;
      h.rig.root.visible = false;
      h.rig.groundSpot.visible = false;
    }
  }

  private spawnPoliceBehindPlayer(): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const yaw = this.onFoot ? this.footYaw : this.carYaw;
    const fwdX = -Math.sin(yaw);
    const fwdZ = -Math.cos(yaw);

    // Pick first inactive cruiser, otherwise reposition the farthest active cruiser right behind player
    let chosen = this.policeCars.find((p) => !p.active);
    if (!chosen) {
      let maxD = -1;
      for (const pc of this.policeCars) {
        const d = Math.hypot(pc.x - px, pc.z - pz);
        if (d > maxD) {
          maxD = d;
          chosen = pc;
        }
      }
    }
    if (!chosen) return;

    const sideJitter = (Math.random() - 0.5) * 8;
    const rightX = Math.cos(yaw);
    const rightZ = -Math.sin(yaw);
    chosen.x = THREE.MathUtils.clamp(px - fwdX * 52 + rightX * sideJitter, -1400, 1400);
    chosen.z = THREE.MathUtils.clamp(pz - fwdZ * 52 + rightZ * sideJitter, -1400, 1400);
    chosen.y = this.world.groundHeightAt(chosen.x, chosen.z);
    chosen.yaw = yaw;
    chosen.speed = 32;
    chosen.hp = 100;
    chosen.active = true;
    chosen.rig.root.visible = true;
    chosen.rig.root.position.set(chosen.x, chosen.y, chosen.z);
    chosen.rig.root.rotation.y = chosen.yaw;
  }

  private handlePedestrianKilled(ped: PedestrianActor, impactVx: number, impactVz: number): void {
    if (!ped.alive) return;
    ped.alive = false;
    ped.respawnTimer = 18;
    ped.rig.root.visible = false;
    this.spawnDebrisBurst(ped.x, ped.z, 0xef4444, impactVx * 0.4, impactVz * 0.4);
    this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.16);
    this.wantedLevel = Math.min(5, Math.max(1, this.wantedLevel + 1));
    this.wantedDecayTimer = 16;
    this.spawnPoliceBehindPlayer();
    this.callbacks.onCombatReward(800, 30, 'Civilian Down · Police Behind You! +₹800');
  }

  private handlePlayerWasted(): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    let nearestHosp = WORLD_FACILITIES.find((f) => f.type === 'hospital')!;
    let bestDist = Infinity;
    for (const f of WORLD_FACILITIES) {
      if (f.type !== 'hospital') continue;
      const d = Math.hypot(px - f.entryX, pz - f.entryZ);
      if (d < bestDist) {
        bestDist = d;
        nearestHosp = f;
      }
    }

    const bill = 2000;
    this.health = this.maxHealth;
    this.bustedProgress = 0;
    this.bustedCooldown = 3.0;
    this.clearWanted();

    this.inAircraft = false;
    this.aircraftRig.root.visible = false;
    this.playerCarRig.root.visible = true;

    const gx = nearestHosp.entryX;
    const gz = nearestHosp.entryZ;
    const gy = this.world.groundHeightAt(gx, gz);
    this.carX = gx;
    this.carY = gy;
    this.carZ = gz;
    this.carVx = 0;
    this.carVy = 0;
    this.carVz = 0;
    this.carYaw = 0;
    this.carPitch = 0;
    this.carRoll = 0;
    this.playerCarRig.root.position.set(gx, gy, gz);
    this.playerCarRig.root.rotation.set(0, 0, 0, 'YXZ');

    this.footX = gx + (this.onFoot ? 0 : 2.6);
    this.footZ = gz;
    this.footY = this.world.groundHeightAt(this.footX, this.footZ);
    this.footVy = 0;
    this.footYaw = 0;
    this.playerCharRig.root.position.set(this.footX, this.footY, this.footZ);
    this.playerCharRig.root.rotation.y = this.footYaw;

    this.camera.position.set(gx, gy + 4.4, gz + 12);
    this.camera.lookAt(nearestHosp.x, gy + 2.5, nearestHosp.z);

    if (this.activeMission) {
      const failed = this.activeMission;
      this.activeMission = null;
      this.waypointBeacon.visible = false;
      this.callbacks.onMissionFailed(failed, 'Wasted — Admitted to Hospital');
    }

    this.sound.playMissionStinger(false);
    this.callbacks.onPlayerWasted(bill, nearestHosp.name);
  }

  private handlePlayerBusted(): void {
    const stars = Math.max(1, this.wantedLevel);
    const fine = stars * 2500;
    this.health = this.maxHealth;
    this.bustedProgress = 0;
    this.bustedCooldown = 3.0;
    this.clearWanted();

    this.inAircraft = false;
    this.aircraftRig.root.visible = false;
    this.playerCarRig.root.visible = true;

    // Teleport player right outside Jaipur Police Commissionerate Gate
    const gx = POLICE_STATION.gateX;
    const gz = POLICE_STATION.gateZ;
    const gy = this.world.groundHeightAt(gx, gz);
    this.carX = gx;
    this.carY = gy;
    this.carZ = gz;
    this.carVx = 0;
    this.carVy = 0;
    this.carVz = 0;
    this.carYaw = Math.PI;
    this.carPitch = 0;
    this.carRoll = 0;
    this.playerCarRig.root.position.set(gx, gy, gz);
    this.playerCarRig.root.rotation.set(0, Math.PI, 0, 'YXZ');

    this.footX = gx + (this.onFoot ? 0 : 2.6);
    this.footZ = gz;
    this.footY = this.world.groundHeightAt(this.footX, this.footZ);
    this.footVy = 0;
    this.footYaw = Math.PI;
    this.playerCharRig.root.position.set(this.footX, this.footY, this.footZ);
    this.playerCharRig.root.rotation.y = this.footYaw;

    // Snap camera immediately so player sees Jaipur Police HQ Gate
    this.camera.position.set(gx, gy + 4.4, gz + 12);
    this.camera.lookAt(gx, gy + 2.4, gz - 20);

    if (this.activeMission) {
      const failed = this.activeMission;
      this.activeMission = null;
      this.waypointBeacon.visible = false;
      this.callbacks.onMissionFailed(failed, 'Busted by Jaipur Police');
    }

    this.sound.playMissionStinger(false);
    this.callbacks.onPlayerBusted(fine, stars);
  }

  fireWeapon(): void {
    if (this.isTitleShowcase || this.paused || this.fireCooldown > 0) return;

    // Fire Tender shoots pressurized Water Hose Jet instead of gunfire!
    if (!this.onFoot && !this.inAircraft && this.playerVehicleId === 'fire_truck') {
      this.fireCooldown = 0.08;
      this.sound.playWaterHose();
      const fwdX = -Math.sin(this.carYaw);
      const fwdZ = -Math.cos(this.carYaw);
      for (let k = 0; k < 2; k++) {
        const drop = this.waterJetPool[this.waterJetCursor];
        this.waterJetCursor = (this.waterJetCursor + 1) % this.waterJetPool.length;
        drop.active = true;
        drop.mesh.visible = true;
        drop.mesh.position.set(this.carX + fwdX * 3.8, this.carY + 3.2, this.carZ + fwdZ * 3.8);
        drop.vx = fwdX * 38 + (Math.random() - 0.5) * 3.2 + this.carVx * 0.4;
        drop.vy = 2.5 + Math.random() * 1.4;
        drop.vz = fwdZ * 38 + (Math.random() - 0.5) * 3.2 + this.carVz * 0.4;
        drop.life = 0.95;
      }
      return;
    }

    const spec = WEAPONS_CATALOG[this.selectedWeapon];
    this.fireCooldown = spec.fireRateSec;
    this.aimingTimer = 0.55;
    this.sound.playGunshot(this.selectedWeapon);
    if (this.onFoot) {
      this.playerCharRig.triggerMuzzleFlash();
    }

    const px = this.onFoot ? this.footX : this.carX;
    const py = this.onFoot ? this.footY + 1.35 : this.carY + 1.45;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const yaw = this.onFoot ? this.footYaw : this.carYaw;
    const baseFwdX = -Math.sin(yaw);
    const baseFwdZ = -Math.cos(yaw);

    if (this.selectedWeapon === 'fists') {
      if (this.inAircraft) return;
      for (const prop of this.world.destructibles) {
        if (!prop.smashed && Math.hypot(px - prop.x, pz - prop.z) < 4.5) {
          this.smashDestructibleProp(prop, baseFwdX * 14, baseFwdZ * 14);
        }
      }
      for (const pc of this.policeCars) {
        if (pc.active && Math.hypot(px - pc.x, pz - pc.z) < 5.0) {
          pc.hp -= spec.damage;
          this.spawnDebrisBurst(pc.x, pc.z, 0x3b82f6, baseFwdX * 12, baseFwdZ * 12);
        }
      }
      for (const ped of this.pedestrians) {
        if (ped.alive && Math.hypot(px - ped.x, pz - ped.z) < 4.2) {
          this.handlePedestrianKilled(ped, baseFwdX * 14, baseFwdZ * 14);
        }
      }
      return;
    }

    let dirX = baseFwdX;
    let dirY = this.inAircraft ? -Math.sin(this.airPitch) : 0.01;
    let dirZ = baseFwdZ;
    let bestScore = Infinity;

    for (const heli of this.policeHelicopters) {
      if (!heli.active || heli.crashing) continue;
      const dx = heli.x - px;
      const dy = heli.y + 0.8 - py;
      const dz = heli.z - pz;
      const dist = Math.hypot(dx, dy, dz);
      if (dist < spec.range * 1.1 && dist < bestScore) {
        bestScore = dist;
        dirX = dx / dist;
        dirY = dy / dist;
        dirZ = dz / dist;
      }
    }

    if (bestScore === Infinity) {
      for (const pc of this.policeCars) {
        if (!pc.active) continue;
        const dx = pc.x - px;
        const dy = pc.y + 0.8 - py;
        const dz = pc.z - pz;
        const dist = Math.hypot(dx, dy, dz);
        const dot = (dx * baseFwdX + dz * baseFwdZ) / (dist || 1);
        if (dist < spec.range && dot > 0.25 && dist < bestScore) {
          bestScore = dist;
          dirX = dx / dist;
          dirY = dy / dist;
          dirZ = dz / dist;
        }
      }
    }

    const muzzleForward = this.inAircraft ? 6.8 : 1.4;
    for (let p = 0; p < spec.pellets; p++) {
      const proj = this.projectilePool[this.projectileCursor];
      this.projectileCursor = (this.projectileCursor + 1) % this.projectilePool.length;
      const sx = dirX + (Math.random() - 0.5) * spec.spread;
      const sy = dirY + (Math.random() - 0.5) * spec.spread * 0.6;
      const sz = dirZ + (Math.random() - 0.5) * spec.spread;
      const len = Math.hypot(sx, sy, sz) || 1;

      proj.active = true;
      proj.fromEnemy = false;
      proj.vx = (sx / len) * spec.projectileSpeed;
      proj.vy = (sy / len) * spec.projectileSpeed;
      proj.vz = (sz / len) * spec.projectileSpeed;
      proj.life = spec.range / spec.projectileSpeed;
      proj.damage = spec.damage;
      proj.explosiveRadius = spec.explosiveRadius;

      const mat = proj.mesh.material as THREE.MeshBasicMaterial;
      mat.color.set(spec.color);
      proj.mesh.scale.setScalar(spec.id === 'rpg' ? 2.4 : spec.id === 'shotgun' ? 0.9 : 1.15);
      proj.mesh.position.set(px + dirX * muzzleForward, py, pz + dirZ * muzzleForward);
      proj.mesh.visible = true;
    }

    if (spec.id === 'rpg' || spec.id === 'shotgun') {
      this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.24);
    }
  }

  private triggerExplosion(x: number, y: number, z: number, radius: number, damage: number): void {
    const exp = this.explosionPool[this.explosionCursor];
    this.explosionCursor = (this.explosionCursor + 1) % this.explosionPool.length;
    exp.mesh.position.set(x, Math.max(0.5, y), z);
    exp.mesh.scale.setScalar(1);
    exp.mesh.visible = true;
    exp.life = 0.65;
    exp.maxLife = 0.65;
    exp.maxScale = Math.max(6, radius * 0.85);
    this.sound.playExplosion();
    this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.45);
    this.spawnDebrisBurst(x, z, 0xf97316, (Math.random() - 0.5) * 18, (Math.random() - 0.5) * 18);
    // Explosions spark live city fires for Fire Brigade response!
    this.spawnCityFire(x, z);

    for (const heli of this.policeHelicopters) {
      if (!heli.active || heli.crashing) continue;
      if (Math.hypot(heli.x - x, heli.y - y, heli.z - z) < radius + 5) {
        heli.hp -= damage;
        if (heli.hp <= 0) {
          this.downHelicopter(heli);
        }
      }
    }
    for (const pc of this.policeCars) {
      if (!pc.active) continue;
      if (Math.hypot(pc.x - x, pc.z - z) < radius + 3) {
        pc.hp -= damage;
        if (pc.hp <= 0) {
          this.disablePoliceCar(pc);
        }
      }
    }
    if (this.rogueCar?.active && Math.hypot(this.rogueCar.x - x, this.rogueCar.z - z) < radius + 4) {
      this.rogueCar.hp -= damage;
    }
    for (const prop of this.world.destructibles) {
      if (!prop.smashed && Math.hypot(prop.x - x, prop.z - z) < radius) {
        this.smashDestructibleProp(prop, (prop.x - x) * 2, (prop.z - z) * 2);
      }
    }
    for (const ped of this.pedestrians) {
      if (ped.alive && Math.hypot(ped.x - x, ped.z - z) < radius + 2) {
        this.handlePedestrianKilled(ped, (ped.x - x) * 3, (ped.z - z) * 3);
      }
    }
  }

  private disablePoliceCar(pc: PoliceCar): void {
    pc.active = false;
    pc.rig.root.visible = false;
    pc.hp = 100;
    this.spawnDebrisBurst(pc.x, pc.z, 0x1e3a8a, 0, 0);
    this.callbacks.onCombatReward(5000, 150, 'Interceptor Disabled! +₹5,000');
  }

  private downHelicopter(heli: PoliceHelicopter): void {
    if (heli.crashing) return;
    heli.crashing = true;
    heli.crashTimer = 2.6;
    heli.rig.searchBeam.visible = false;
    heli.rig.groundSpot.visible = false;
    this.sound.playExplosion();
    this.callbacks.onCombatReward(15000, 400, 'Police Helicopter Shot Down! +₹15,000');
  }

  private smashDestructibleProp(prop: IndiaWorldHandles['destructibles'][number], impactVx: number, impactVz: number): void {
    prop.smashed = true;
    prop.respawnTimer = 24;
    prop.mesh.visible = false;
    this.totalSmashed += 1;
    this.spawnDebrisBurst(prop.x, prop.z, prop.colorHex, impactVx, impactVz);
    this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.18);

    // Less strict police: only escalate wanted star every 10 props smashed
    if (this.totalSmashed % 10 === 0) {
      this.wantedLevel = Math.min(5, this.wantedLevel + 1);
      this.wantedDecayTimer = 11;
    }
    if (this.activeMission?.type === 'smash') {
      this.missionSmashCount += 1;
    }
    this.callbacks.onPropSmashed(prop.id, impactVx, impactVz, this.totalSmashed);
  }

  toggleOnFoot(): void {
    if (this.inAircraft) {
      const groundY = this.world.groundHeightAt(this.carX, this.carZ);
      if (this.carY <= groundY + 14) {
        this.inAircraft = false;
        this.aircraftRig.root.visible = false;
        this.playerCarRig.root.visible = true;
        this.carY = groundY;
        this.carVx = 0;
        this.carVy = 0;
        this.carVz = 0;
        this.airSpeed = 0;
        this.airPitch = 0;
        this.airRoll = 0;
      }
      return;
    }
    if (this.onFoot) {
      const distToOwn = Math.hypot(this.footX - this.carX, this.footZ - this.carZ);
      if (distToOwn < 5.5) {
        this.onFoot = false;
        this.playerCharRig.root.visible = false;
        return;
      }
      for (const tc of this.trafficCars) {
        if (Math.hypot(this.footX - tc.x, this.footZ - tc.z) < 5.2) {
          this.carX = tc.x;
          this.carY = tc.y;
          this.carZ = tc.z;
          this.carYaw = tc.yaw;
          this.carVx = 0;
          this.carVz = 0;
          this.spawnPlayerVehicle(tc.id, tc.color);
          this.onFoot = false;
          this.playerCharRig.root.visible = false;
          this.wantedLevel = Math.min(5, this.wantedLevel + 1);
          this.wantedDecayTimer = 12;

          if (tc.axis === 'x') tc.x = tc.dir === 1 ? -1260 : 1260;
          else tc.z = tc.dir === 1 ? -1260 : 1260;
          tc.currentSpeed = 0;
          tc.y = this.world.groundHeightAt(tc.x, tc.z);
          tc.rig.root.position.set(tc.x, tc.y, tc.z);
          return;
        }
      }
    } else {
      this.onFoot = true;
      const sideX = Math.cos(this.carYaw) * 2.4;
      const sideZ = -Math.sin(this.carYaw) * 2.4;
      this.footX = this.carX + sideX;
      this.footZ = this.carZ + sideZ;
      this.footY = this.world.groundHeightAt(this.footX, this.footZ);
      this.footVy = 0;
      this.footYaw = this.carYaw;
      this.playerCharRig.root.visible = true;
      this.playerCharRig.root.position.set(this.footX, this.footY, this.footZ);
    }
  }

  setTouchInput(next: Partial<TouchInputState>): void {
    Object.assign(this.touchInput, next);
  }

  syncRemotePeers(peers: RemotePeerState[]): void {
    const now = performance.now();
    const seen = new Set<string>();

    for (const p of peers) {
      seen.add(p.id);
      let actor = this.remotePeers.get(p.id);
      const cfgKey = `${p.characterConfig.archetype}_${p.characterConfig.outfitColor}_${p.characterConfig.headgear}_${p.characterConfig.eyewear}`;
      if (!actor) {
        const carRig = buildVehicleModel(p.vehicleId || 'ferrari_sf90', p.vehicleColor || '#ef4444', this.textures, this.isSoftwareGl, false);
        const charRig = buildCharacterModel(p.characterConfig, this.textures);
        this.scene.add(carRig.root);
        this.scene.add(charRig.root);
        actor = {
          id: p.id,
          carRig,
          charRig,
          vehicleId: p.vehicleId,
          vehicleColor: p.vehicleColor,
          charConfigKey: cfgKey,
          targetX: p.x,
          targetY: p.y,
          targetZ: p.z,
          targetYaw: p.yaw,
          curX: p.x,
          curY: p.y,
          curZ: p.z,
          curYaw: p.yaw,
          onFoot: p.onFoot,
          speed: p.speed,
          lastSeen: now,
        };
        this.remotePeers.set(p.id, actor);
      } else {
        if (actor.vehicleId !== p.vehicleId) {
          this.scene.remove(actor.carRig.root);
          actor.carRig = buildVehicleModel(p.vehicleId || 'ferrari_sf90', p.vehicleColor || '#ef4444', this.textures, this.isSoftwareGl, false);
          this.scene.add(actor.carRig.root);
          actor.vehicleId = p.vehicleId;
        } else if (actor.vehicleColor !== p.vehicleColor) {
          actor.carRig.setPaintColor(p.vehicleColor);
        }
        actor.vehicleColor = p.vehicleColor;
        if (actor.charConfigKey !== cfgKey) {
          actor.charRig.updateConfig(p.characterConfig);
          actor.charConfigKey = cfgKey;
        }
        actor.targetX = p.x;
        actor.targetY = p.y;
        actor.targetZ = p.z;
        actor.targetYaw = p.yaw;
        actor.onFoot = p.onFoot;
        actor.speed = p.speed;
        actor.lastSeen = now;
      }
    }

    for (const [id, actor] of this.remotePeers.entries()) {
      if (!seen.has(id) && now - actor.lastSeen > 3500) {
        this.scene.remove(actor.carRig.root);
        this.scene.remove(actor.charRig.root);
        this.remotePeers.delete(id);
      }
    }
  }

  applyRemotePropSmash(propId: number, vx: number, vz: number): void {
    const prop = this.world.destructibles.find((d) => d.id === propId);
    if (prop && !prop.smashed) {
      prop.smashed = true;
      prop.respawnTimer = 22;
      prop.mesh.visible = false;
      this.spawnDebrisBurst(prop.x, prop.z, prop.colorHex, vx, vz);
    }
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    this.renderer.domElement.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
  }

  private onMouseDown = (e: MouseEvent): void => {
    if (e.button !== 0 || this.isTitleShowcase || this.paused) return;
    this.sound.init();
    this.mouseFireDown = true;
    this.fireWeapon();
  };

  private onMouseUp = (): void => {
    this.mouseFireDown = false;
  };

  private onResize = (): void => {
    if (!this.renderer || !this.camera) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.composer?.setSize(w, h);
    this.bloomPass?.resolution.set(w, h);
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
    const code = e.code;
    const wasDown = this.keys[code];
    this.keys[code] = true;

    if (!wasDown && !this.isTitleShowcase && !this.paused) {
      this.sound.init();
      if (code === 'KeyF') this.toggleOnFoot();
      else if (code === 'KeyE') this.fireWeapon();
      else if (code === 'KeyH') this.sound.playHorn(this.playerVehicleId, this.inAircraft);
      else if (code === 'KeyC') this.cycleCamera();
      else if (code === 'Space' && this.onFoot && this.footY <= this.world.groundHeightAt(this.footX, this.footZ) + 0.08) {
        this.footVy = 8.8;
      }
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys[e.code] = false;
  };

  private onBlur = (): void => {
    this.keys = {};
    this.mouseFireDown = false;
    this.touchInput = { steer: 0, throttle: 0, brake: 0, nitro: false, handbrake: false, fire: false };
  };

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;
    const now = performance.now();
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (!this.paused) {
      if (this.hitstopTimer > 0) {
        this.hitstopTimer -= dt;
      } else {
        this.elapsedTime += dt;
        this.stepSimulation(dt);
      }
    }

    // Center sky dome on camera so horizon never clips
    this.skyDome.position.copy(this.camera.position);
    this.skyMaterial.uniforms.uTime.value = this.elapsedTime;

    // Drive SpeedWarpShader radial blur & chromatic aberration from smooth speed
    if (this.speedWarpPass) {
      const speedT = THREE.MathUtils.smoothstep(this.currentSpeedRatio, 0.25, 1.0);
      this.speedWarpPass.uniforms['uSpeedBlur'].value = speedT * 0.28 + this.nitroBlend * 0.08;
      this.speedWarpPass.uniforms['uChromatic'].value = speedT * 0.0014 + this.nitroBlend * 0.0006;
      this.speedWarpPass.uniforms['uVignette'].value = 0.22 + speedT * 0.16;
    }

    if (this.isSoftwareGl || !this.composer) {
      this.renderer.render(this.scene, this.camera);
    } else {
      if (this.graphicsPreset === 'ultra4k' && this.cubeCamera && !this.isTitleShowcase) {
        this.reflectionFrameCounter = (this.reflectionFrameCounter + 1) % 4;
        if (this.reflectionFrameCounter === 0) {
          const activeMesh = this.inAircraft ? this.aircraftRig.root : this.playerCarRig.root;
          const wasVis = activeMesh.visible;
          activeMesh.visible = false;
          this.cubeCamera.position.set(this.carX, this.carY + 1.1, this.carZ);
          this.cubeCamera.update(this.renderer, this.scene);
          activeMesh.visible = wasVis;
        }
      }
      this.composer.render();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private stepSimulation(dt: number): void {
    this.world.waterUniforms.uTime.value = this.elapsedTime;
    this.fireCooldown = Math.max(0, this.fireCooldown - dt);
    this.aimingTimer = Math.max(0, this.aimingTimer - dt);

    if (this.isTitleShowcase) {
      this.sound.silenceLoops();
      this.currentSpeedRatio = 0;
      this.currentNitroActive = false;
      this.titleAngle += dt * 0.16;
      const focusX = 120;
      const focusZ = -225;
      const r = 46;
      this.camera.position.set(
        focusX + Math.cos(this.titleAngle) * r,
        16 + Math.sin(this.titleAngle * 0.7) * 4,
        focusZ + Math.sin(this.titleAngle) * r,
      );
      this.camera.lookAt(focusX, 5, focusZ);
      this.stepWeatherEffects(dt);
      return;
    }

    if (this.keys['KeyE'] || this.mouseFireDown || this.touchInput.fire) {
      this.fireWeapon();
    }

    if (this.inAircraft) {
      this.stepAircraftPhysics(dt);
    } else if (this.onFoot) {
      this.stepOnFoot(dt);
      this.currentSpeedRatio = 0;
      this.currentNitroActive = false;
    } else {
      this.stepVehiclePhysics(dt);
    }

    this.stepTrafficSignals(dt);
    this.stepTrains(dt);
    this.stepFiresAndWater(dt);
    this.stepTraffic(dt);
    this.stepPedestrians(dt);
    this.stepPolice(dt);
    this.stepPoliceHelicopters(dt);
    this.stepProjectiles(dt);
    this.stepExplosions(dt);
    this.stepDestructibles(dt);
    this.stepDebris(dt);
    this.stepSmoke(dt);
    this.stepRemotePeers(dt);
    this.stepWeatherEffects(dt);
    this.stepWindStreaks(dt);
    this.stepJob(dt);
    this.stepMission(dt);
    this.stepCamera(dt);

    // Animate interactive facility entry rings, Airport ATC radars & Showroom turntables
    for (let i = 0; i < this.world.facilityRings.length; i++) {
      const ring = this.world.facilityRings[i];
      ring.rotation.z += dt * 1.4;
      ring.position.y = 0.22 + Math.sin(this.elapsedTime * 3.0 + i) * 0.08;
    }
    for (let i = 0; i < this.world.airportRadars.length; i++) {
      this.world.airportRadars[i].rotation.y += dt * 1.35;
    }
    for (let i = 0; i < this.world.showroomTurntables.length; i++) {
      this.world.showroomTurntables[i].rotation.y += dt * 0.65;
    }

    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    // Texel-snap shadow frustum origin to 2m grid to eliminate shadow edge flicker
    const snapX = Math.round(px / 2) * 2;
    const snapZ = Math.round(pz / 2) * 2;
    this.sunLight.position.set(snapX + 65, 95, snapZ + 52);
    this.sunLight.target.position.set(snapX, 0, snapZ);

    this.telemetryAccum += dt;
    if (this.telemetryAccum >= 0.05) {
      this.telemetryAccum = 0;
      this.emitTelemetry(px, pz);
    }
  }

  private getSignalPhase(phaseOffset: number, axis: 'x' | 'z'): 'GREEN' | 'AMBER' | 'RED' {
    const t = (this.elapsedTime + phaseOffset) % 24;
    if (axis === 'x') {
      if (t < 9.5) return 'GREEN';
      if (t < 12.0) return 'AMBER';
      return 'RED';
    }
    if (t >= 12.0 && t < 21.5) return 'GREEN';
    if (t >= 21.5) return 'AMBER';
    return 'RED';
  }

  private stepTrafficSignals(_dt: number): void {
    for (const tl of this.world.trafficLights) {
      const ew = this.getSignalPhase(tl.phaseOffset, 'x');
      const ns = this.getSignalPhase(tl.phaseOffset, 'z');
      tl.ewGreenMat.emissiveIntensity = ew === 'GREEN' ? 3.5 : 0.08;
      tl.ewAmberMat.emissiveIntensity = ew === 'AMBER' ? 3.5 : 0.08;
      tl.ewRedMat.emissiveIntensity = ew === 'RED' ? 3.5 : 0.08;
      tl.nsGreenMat.emissiveIntensity = ns === 'GREEN' ? 3.5 : 0.08;
      tl.nsAmberMat.emissiveIntensity = ns === 'AMBER' ? 3.5 : 0.08;
      tl.nsRedMat.emissiveIntensity = ns === 'RED' ? 3.5 : 0.08;
    }
  }

  private stepTrains(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    this.expressHornCooldown = Math.max(0, this.expressHornCooldown - dt);

    // 1. Jaipur Metro Pink Line elevated train oscillating between Mansarovar (-880) & Badi Chaupar (145)
    if (this.metroPause > 0) {
      this.metroPause -= dt;
    } else {
      this.metroProgress += this.metroDir * dt * 0.055;
      if (this.metroProgress >= 1) {
        this.metroProgress = 1;
        this.metroDir = -1;
        this.metroPause = 2.5;
      } else if (this.metroProgress <= 0) {
        this.metroProgress = 0;
        this.metroDir = 1;
        this.metroPause = 2.5;
      }
      const mx = THREE.MathUtils.lerp(-880, 145, this.metroProgress);
      this.world.metroTrain.position.set(mx, 9.55, 112);
    }

    // 2. Indian Railways Broad-Gauge Express Train along z = 248
    if (this.expressPause > 0) {
      this.expressPause -= dt;
    } else {
      const prevX = this.expressX;
      this.expressX += 34 * dt;
      if ((prevX < -480 && this.expressX >= -480) || (prevX < 260 && this.expressX >= 260)) {
        this.expressPause = 4.0;
        if (Math.hypot(px - this.expressX, pz - 248) < 150 && this.expressHornCooldown <= 0) {
          this.expressHornCooldown = 8;
          this.sound.playTrainHorn();
        }
      }
      if (this.expressX > 1420) this.expressX = -1420;
      this.world.expressTrain.position.set(this.expressX, 0.14, 248);

      // Train crossing horn warning + impact push if player blocks tracks at z = 248
      const dTrain = Math.hypot(px - this.expressX, pz - 248);
      if (dTrain < 110 && this.expressHornCooldown <= 0) {
        this.expressHornCooldown = 7;
        this.sound.playTrainHorn();
      }
      if (!this.inAircraft && Math.abs(pz - 248) < 4.5 && Math.abs(px - this.expressX) < 38) {
        if (!this.onFoot) {
          this.carVz += (pz >= 248 ? 1 : -1) * 26;
          this.carZ += (pz >= 248 ? 1 : -1) * 3.5;
          this.sound.playCrash(1.0);
          this.applyPlayerDamage(18);
        }
      }
    }
  }

  private stepFiresAndWater(dt: number): void {
    this.fireSpawnTimer -= dt;
    const activeFires = this.firePool.filter((f) => f.active);
    if (this.fireSpawnTimer <= 0) {
      this.fireSpawnTimer = 28;
      if (activeFires.length < 2) {
        const loc = JAIPUR_LOCALITIES[Math.floor(Math.random() * JAIPUR_LOCALITIES.length)];
        this.spawnCityFire(loc.x + 18, loc.z - 18);
      }
    }

    for (let i = 0; i < this.firePool.length; i++) {
      const f = this.firePool[i];
      if (!f.active) continue;
      f.flame1.scale.set(1, 0.85 + Math.sin(this.elapsedTime * 11 + i) * 0.25, 1);
      f.flame2.scale.set(1, 0.85 + Math.cos(this.elapsedTime * 14 + i) * 0.28, 1);
      f.smokeAccum += dt;
      if (f.smokeAccum > 0.25) {
        f.smokeAccum = 0;
        this.spawnSmokePuff(f.x, 4.2, f.z);
      }
    }

    // AI Fire Brigade Truck dispatches from Fire HQ to active fires when player isn't extinguishing
    const targetFire = this.firePool.find((f) => f.active);
    if (targetFire) {
      this.aiFirePos.active = true;
      const dx = targetFire.x - this.aiFirePos.x;
      const dz = targetFire.z - this.aiFirePos.z;
      const dist = Math.hypot(dx, dz) || 1;
      if (dist > 14) {
        const desiredYaw = Math.atan2(-dx, -dz);
        this.aiFirePos.yaw = desiredYaw;
        this.aiFirePos.x += (-Math.sin(desiredYaw)) * 16 * dt;
        this.aiFirePos.z += (-Math.cos(desiredYaw)) * 16 * dt;
      } else if (!this.activeJob || this.activeJob.id !== 'firefighter') {
        targetFire.hp -= 10 * dt;
        if (targetFire.hp <= 0) {
          targetFire.active = false;
          targetFire.group.visible = false;
        }
      }
    } else {
      this.aiFirePos.active = false;
    }
    this.aiFireRig.root.position.set(this.aiFirePos.x, this.world.groundHeightAt(this.aiFirePos.x, this.aiFirePos.z), this.aiFirePos.z);
    this.aiFireRig.root.rotation.y = this.aiFirePos.yaw;
    if (this.aiFireRig.policeLightBar) {
      const fl = Math.floor(this.elapsedTime * 8) % 2 === 0;
      (this.aiFireRig.policeLightBar.red.material as THREE.MeshStandardMaterial).emissiveIntensity =
        this.aiFirePos.active ? (fl ? 4.5 : 0.2) : 0.4;
      (this.aiFireRig.policeLightBar.blue.material as THREE.MeshStandardMaterial).emissiveIntensity =
        this.aiFirePos.active ? (fl ? 0.2 : 4.5) : 0.4;
    }

    // Step player water hose droplets
    for (let i = 0; i < this.waterJetPool.length; i++) {
      const w = this.waterJetPool[i];
      if (!w.active) continue;
      w.life -= dt;
      w.vy -= 14 * dt;
      w.mesh.position.x += w.vx * dt;
      w.mesh.position.y += w.vy * dt;
      w.mesh.position.z += w.vz * dt;
      const wx = w.mesh.position.x;
      const wz = w.mesh.position.z;

      for (const f of this.firePool) {
        if (!f.active) continue;
        if (Math.hypot(wx - f.x, wz - f.z) < 6.5) {
          f.hp -= 16;
          this.spawnSmokePuff(f.x, 2.8, f.z);
          w.life = 0;
          if (f.hp <= 0) {
            f.active = false;
            f.group.visible = false;
            this.sound.playMissionStinger(true);
            this.callbacks.onCombatReward(12000, 250, 'City Fire Extinguished! +₹12,000');
            if (this.activeJob?.id === 'firefighter') {
              const completed = this.activeJob;
              this.activeJob = null;
              this.callbacks.onJobComplete(completed);
            }
          }
          break;
        }
      }

      if (w.life <= 0 || w.mesh.position.y < 0.1) {
        w.active = false;
        w.mesh.visible = false;
      }
    }
  }

  private applyPlayerDamage(rawDmg: number): void {
    let remaining = rawDmg;
    if (this.armor > 0) {
      const absorbed = Math.min(this.armor, rawDmg * 0.72);
      this.armor = Math.max(0, this.armor - absorbed);
      remaining = Math.max(1, rawDmg - absorbed);
    }
    this.health = Math.max(0, this.health - remaining);
  }

  private stepJob(dt: number): void {
    if (!this.activeJob) return;
    this.jobTimeLeft -= dt;
    if (this.jobTimeLeft <= 0) {
      const failed = this.activeJob;
      this.cancelJob();
      this.sound.playMissionStinger(false);
      this.callbacks.onJobFailed(failed, 'Shift timer expired');
      return;
    }

    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;

    if (this.activeJob.id === 'police_bounty' && this.rogueCar.active) {
      // Rogue gangster drives evasively through Jaipur
      const dx = this.rogueCar.x - px;
      const dz = this.rogueCar.z - pz;
      const dist = Math.hypot(dx, dz) || 1;
      const escapeYaw = Math.atan2(-dx, -dz) + Math.sin(this.elapsedTime * 0.8) * 0.45;
      this.rogueCar.yaw = escapeYaw;
      this.rogueCar.x = THREE.MathUtils.clamp(this.rogueCar.x + (-Math.sin(escapeYaw)) * 23 * dt, -1380, 1380);
      this.rogueCar.z = THREE.MathUtils.clamp(this.rogueCar.z + (-Math.cos(escapeYaw)) * 23 * dt, -1380, 1380);
      const ry = this.world.groundHeightAt(this.rogueCar.x, this.rogueCar.z);
      this.rogueCar.rig.root.position.set(this.rogueCar.x, ry, this.rogueCar.z);
      this.rogueCar.rig.root.rotation.y = this.rogueCar.yaw;

      if (!this.onFoot && dist < 4.5 && Math.hypot(this.carVx, this.carVz) > 10) {
        this.rogueCar.hp -= 38;
        this.sound.playCrash(0.8);
        this.spawnDebrisBurst(this.rogueCar.x, this.rogueCar.z, 0x7c3aed, this.carVx, this.carVz);
        this.rogueCar.x += (dx / dist) * 8;
        this.rogueCar.z += (dz / dist) * 8;
      }
      if (this.rogueCar.hp <= 0) {
        const done = this.activeJob;
        this.triggerExplosion(this.rogueCar.x, 1, this.rogueCar.z, 9, 40);
        this.cancelJob();
        this.sound.playMissionStinger(true);
        this.callbacks.onJobComplete(done);
      }
      return;
    }

    if (this.activeJob.id === 'firefighter') {
      const f = this.firePool.find((fire) => fire.active);
      if (f) {
        this.jobWaypoints[0] = { x: f.x, z: f.z, label: 'Drive Fire Tender & Spray Water [E]' };
      }
      return;
    }

    const wp = this.jobWaypoints[this.jobStageIdx];
    if (wp && Math.hypot(px - wp.x, pz - wp.z) < 12.5) {
      this.jobStageIdx += 1;
      this.lastGpsDestX = 1e9;
      this.sound.playCashRegister();
      if (this.jobStageIdx >= this.jobWaypoints.length) {
        const done = this.activeJob;
        this.cancelJob();
        this.sound.playMissionStinger(true);
        this.callbacks.onJobComplete(done);
      }
    }
  }

  private stepAircraftPhysics(dt: number): void {
    const throttle = Math.max(this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0, this.touchInput.throttle);
    const brake = Math.max(this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0, this.touchInput.brake);
    const steerLeft = this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0;
    const steerRight = this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0;
    const steerInput = THREE.MathUtils.clamp(steerLeft - steerRight - this.touchInput.steer, -1, 1);
    const climbKey = Boolean(this.keys['Space'] || this.touchInput.handbrake);
    const wantAfterburner = Boolean(
      (this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchInput.nitro) && this.nitro > 1,
    );

    const afterburner = wantAfterburner && (throttle > 0 || this.airSpeed > 20);
    this.currentNitroActive = afterburner;
    if (afterburner) {
      this.nitro = Math.max(0, this.nitro - 18 * dt);
    } else {
      this.nitro = Math.min(100, this.nitro + 12 * dt);
    }

    this.nitroBlend = THREE.MathUtils.damp(this.nitroBlend, afterburner ? 1 : 0, 3.5, dt);
    const maxAirSpeed = 122 * (1 + this.nitroBlend * 0.3);

    if (throttle > 0) {
      this.airSpeed += (26 + this.nitroBlend * 22) * throttle * dt;
    } else if (brake > 0) {
      this.airSpeed -= 34 * brake * dt;
    } else {
      this.airSpeed *= Math.max(0, 1 - 0.14 * dt);
    }
    this.airSpeed = THREE.MathUtils.clamp(this.airSpeed, 0, maxAirSpeed);

    const groundY = this.world.groundHeightAt(this.carX, this.carZ);
    const altitude = this.carY - groundY;
    const canFly = this.airSpeed >= 28;
    const turnScale = altitude > 2 ? 1.05 : THREE.MathUtils.clamp(this.airSpeed / 22, 0.35, 1.0);
    this.carYaw += steerInput * turnScale * dt;

    // Smooth vertical pitch & climb/descend physics
    let climbVy = 0;
    let targetPitch = 0;
    if (climbKey && canFly) {
      climbVy = 24;
      targetPitch = 0.28;
    } else if (throttle > 0 && this.airSpeed > 44 && altitude < 18) {
      // Natural runway liftoff once takeoff speed reached
      climbVy = 12;
      targetPitch = 0.16;
    } else if (brake > 0 && altitude > 0.2) {
      climbVy = -20;
      targetPitch = -0.2;
    } else if (altitude > 0.2 && !canFly) {
      climbVy = -14;
      targetPitch = -0.15;
    }

    this.carY = THREE.MathUtils.clamp(this.carY + climbVy * dt, groundY, 260);
    const newAlt = this.carY - groundY;

    const fwdX = -Math.sin(this.carYaw);
    const fwdZ = -Math.cos(this.carYaw);
    this.carVx = fwdX * this.airSpeed;
    this.carVz = fwdZ * this.airSpeed;
    this.carVy = climbVy;

    this.carX = THREE.MathUtils.clamp(this.carX + this.carVx * dt, -1450, 1450);
    this.carZ = THREE.MathUtils.clamp(this.carZ + this.carVz * dt, -1450, 1450);

    // Building collision only while low near ground
    for (let i = 0; i < this.world.buildings.length; i++) {
      const b = this.world.buildings[i];
      if (this.carY >= b.height + 1.5) continue;
      const closestX = THREE.MathUtils.clamp(this.carX, b.minX, b.maxX);
      const closestZ = THREE.MathUtils.clamp(this.carZ, b.minZ, b.maxZ);
      const dx = this.carX - closestX;
      const dz = this.carZ - closestZ;
      const distSq = dx * dx + dz * dz;
      const jetRad = 4.5;
      if (distSq < jetRad * jetRad) {
        const dist = Math.sqrt(distSq) || 0.001;
        this.carX += (dx / dist) * (jetRad - dist);
        this.carZ += (dz / dist) * (jetRad - dist);
        if (this.airSpeed > 18) {
          this.sound.playCrash(0.6);
          this.airSpeed *= 0.45;
        }
      }
    }

    this.airPitch = THREE.MathUtils.damp(this.airPitch, targetPitch, 6, dt);
    const targetRoll = newAlt > 1.5 ? steerInput * 0.56 : 0;
    this.airRoll = THREE.MathUtils.damp(this.airRoll, targetRoll, 5.5, dt);

    this.aircraftRig.root.position.set(this.carX, this.carY, this.carZ);
    this.aircraftRig.root.rotation.set(this.airPitch, this.carYaw, this.airRoll, 'YXZ');
    this.aircraftRig.landingGear.visible = newAlt < 8;

    for (const fan of this.aircraftRig.turbineFans) {
      fan.rotation.y += (12 + this.airSpeed * 0.8) * dt;
    }
    for (const flame of this.aircraftRig.afterburners) {
      flame.visible = throttle > 0.25 || afterburner;
      if (flame.visible) {
        const s = afterburner ? 1.55 : 0.85;
        flame.scale.set(s, (0.8 + Math.random() * 0.5) * s, s);
      }
    }

    const speedKmh = this.airSpeed * 3.6;
    this.currentSpeedRatio = THREE.MathUtils.clamp(speedKmh / 500, 0, 1);
    if (speedKmh > this.bestSpeedKmh + 2) {
      this.bestSpeedKmh = Math.round(speedKmh);
      this.callbacks.onTopSpeedRecord(this.bestSpeedKmh);
    }

    const rpmRatio = THREE.MathUtils.clamp(0.18 + (this.airSpeed / maxAirSpeed) * 0.82, 0.15, 1);
    this.sound.updateLoop(
      dt,
      true,
      rpmRatio,
      afterburner,
      0,
      this.weatherMode === 'monsoon',
      this.wantedLevel,
      this.playerVehicleId,
      true,
    );
  }

  private stepVehiclePhysics(dt: number): void {
    const spec = VEHICLE_CATALOG[this.playerVehicleId];
    const throttle = Math.max(
      this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0,
      this.touchInput.throttle,
    );
    const reverse = Math.max(
      this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0,
      this.touchInput.brake,
    );
    const steerLeft = this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0;
    const steerRight = this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0;
    const steerInput = THREE.MathUtils.clamp(steerLeft - steerRight - this.touchInput.steer, -1, 1);
    const handbrake = Boolean(this.keys['Space'] || this.touchInput.handbrake);
    const wantNitro = Boolean((this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchInput.nitro) && this.nitro > 1);

    const nitroActive = wantNitro && (throttle > 0 || Math.hypot(this.carVx, this.carVz) > 5) && this.fuel > 0.5;
    this.currentNitroActive = nitroActive;
    if (nitroActive) {
      this.nitro = Math.max(0, this.nitro - 20 * dt);
    } else {
      this.nitro = Math.min(100, this.nitro + 11 * dt);
    }

    // Gentle authentic fuel consumption (electric e-rickshaw recharges slowly!)
    if (this.playerVehicleId === 'e_rickshaw') {
      this.fuel = Math.min(100, this.fuel + 0.35 * dt);
    } else if (throttle > 0.05 || reverse > 0.05) {
      const burn = (nitroActive ? 1.05 : 0.42) * Math.max(throttle, reverse);
      this.fuel = Math.max(0, this.fuel - burn * dt);
    }

    this.smoothThrottle = THREE.MathUtils.damp(this.smoothThrottle, throttle, 5.2, dt);
    this.nitroBlend = THREE.MathUtils.damp(this.nitroBlend, nitroActive ? 1 : 0, 3.2, dt);

    const fwdX = -Math.sin(this.carYaw);
    const fwdZ = -Math.cos(this.carYaw);
    const rightX = Math.cos(this.carYaw);
    const rightZ = -Math.sin(this.carYaw);

    let forwardSpeed = this.carVx * fwdX + this.carVz * fwdZ;
    let lateralSpeed = this.carVx * rightX + this.carVz * rightZ;

    // Progressive natural torque curve & aerodynamic drag (limp mode at 0% fuel)
    const rawMaxMs = (spec.topSpeedKmh / 3.6) * (1 + this.nitroBlend * 0.14);
    const maxSpeedMs = this.fuel <= 0.2 ? Math.min(rawMaxMs, 7.5) : rawMaxMs;
    const baseAccel = spec.accel * (this.fuel <= 0.2 ? 0.12 : 0.36);
    const speedFrac = THREE.MathUtils.clamp(Math.max(0, forwardSpeed) / maxSpeedMs, 0, 1);
    const torqueFactor = Math.max(0.18, 1 - 0.65 * Math.pow(speedFrac, 1.35));
    const accelForce = baseAccel * torqueFactor * (1 + this.nitroBlend * 0.35);

    if (this.smoothThrottle > 0.01) {
      forwardSpeed += accelForce * this.smoothThrottle * dt;
    }
    if (reverse > 0) {
      if (forwardSpeed > 2) {
        forwardSpeed -= 52 * reverse * dt;
      } else {
        forwardSpeed -= 20 * reverse * dt;
      }
    }

    const rollingDrag = this.smoothThrottle > 0.05 || reverse > 0 ? 0.18 : 0.95;
    const aeroDrag = 0.0022 * Math.abs(forwardSpeed);
    forwardSpeed *= Math.max(0, 1 - (rollingDrag + aeroDrag) * dt);
    if (handbrake) {
      forwardSpeed *= Math.max(0, 1 - 1.6 * dt);
    }
    forwardSpeed = THREE.MathUtils.clamp(forwardSpeed, -24, maxSpeedMs);

    const speedFactor = THREE.MathUtils.clamp(Math.abs(forwardSpeed) / 14, 0, 1);
    const reverseSign = forwardSpeed >= -0.5 ? 1 : -1;
    const targetSteer = steerInput * 0.52;
    this.carSteerAngle = THREE.MathUtils.damp(this.carSteerAngle, targetSteer, 12, dt);

    if (!this.carAirborne) {
      const turnRate = spec.handling * (handbrake ? 1.38 : 1.0) * speedFactor * reverseSign;
      this.carYaw += steerInput * turnRate * dt;
    }

    const weatherSlip = this.weatherMode === 'monsoon' ? 0.78 : 1.0;
    const grip = (handbrake ? 1.8 : 7.5 * spec.driftGrip) * weatherSlip;
    if (!this.carAirborne) {
      lateralSpeed *= Math.max(0, 1 - grip * dt);
    }

    const driftIntensity = Math.abs(lateralSpeed) / 14;
    if (driftIntensity > 0.35 && Math.abs(forwardSpeed) > 12) {
      this.driftScore += Math.round(driftIntensity * 85 * dt);
      if (!this.carAirborne && Math.random() < 0.65) {
        this.spawnSmokePuff(this.carX - fwdX * 1.4 - rightX * 0.85, this.carY, this.carZ - fwdZ * 1.4 - rightZ * 0.85);
        this.spawnSmokePuff(this.carX - fwdX * 1.4 + rightX * 0.85, this.carY, this.carZ - fwdZ * 1.4 + rightZ * 0.85);
      }
    }

    const newFwdX = -Math.sin(this.carYaw);
    const newFwdZ = -Math.cos(this.carYaw);
    const newRightX = Math.cos(this.carYaw);
    const newRightZ = -Math.sin(this.carYaw);
    this.carVx = newFwdX * forwardSpeed + newRightX * lateralSpeed;
    this.carVz = newFwdZ * forwardSpeed + newRightZ * lateralSpeed;

    const prevGround = this.world.groundHeightAt(this.carX, this.carZ);
    let nextX = this.carX + this.carVx * dt;
    let nextZ = this.carZ + this.carVz * dt;

    nextX = THREE.MathUtils.clamp(nextX, -1450, 1450);
    nextZ = THREE.MathUtils.clamp(nextZ, -1450, 1450);

    const carRadius = 1.9;
    for (let i = 0; i < this.world.buildings.length; i++) {
      const b = this.world.buildings[i];
      const closestX = THREE.MathUtils.clamp(nextX, b.minX, b.maxX);
      const closestZ = THREE.MathUtils.clamp(nextZ, b.minZ, b.maxZ);
      const dx = nextX - closestX;
      const dz = nextZ - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < carRadius * carRadius) {
        const dist = Math.sqrt(distSq) || 0.001;
        const nx = dx / dist;
        const nz = dz / dist;
        const push = carRadius - dist;
        nextX += nx * push;
        nextZ += nz * push;
        const impact = Math.abs(this.carVx * nx + this.carVz * nz);
        if (impact > 9) {
          this.cameraTrauma = Math.min(1, this.cameraTrauma + impact * 0.025);
          this.sound.playCrash(impact / 22);
          if (impact > 24) this.hitstopTimer = 0.04;
        }
        this.carVx *= 0.42;
        this.carVz *= 0.42;
      }
    }

    this.carX = nextX;
    this.carZ = nextZ;

    const groundY = this.world.groundHeightAt(this.carX, this.carZ);
    const dGround = groundY - prevGround;
    if (!this.carAirborne && dGround > 0.02 && dGround < 2.5) {
      this.carY = groundY;
      if (dGround > 0.06 && forwardSpeed > 14) {
        const slopeVy = (dGround / dt) * 0.68;
        this.carVy = Math.max(this.carVy, Math.min(slopeVy, 18));
      }
    }

    this.carVy -= 24 * dt;
    this.carY += this.carVy * dt;

    if (this.carY <= groundY) {
      if (this.carAirborne && this.carVy < -7) {
        this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.35);
        this.sound.playCrash(0.65);
      }
      this.carY = groundY;
      this.carVy = 0;
      this.carAirborne = false;
      this.carAirtime = 0;
    } else {
      this.carAirborne = true;
      this.carAirtime += dt;
    }

    const targetPitch = (throttle > 0 ? 0.032 : 0) - (reverse > 0 ? 0.048 : 0) + (this.carAirborne ? THREE.MathUtils.clamp(this.carVy * 0.025, -0.28, 0.28) : 0);
    // 2-wheelers lean naturally INTO turns, whereas 4-wheelers roll outward slightly
    const targetRoll = this.playerCarRig.isTwoWheeler
      ? steerInput * speedFactor * 0.42
      : -steerInput * speedFactor * 0.055;
    this.carPitch = THREE.MathUtils.damp(this.carPitch, targetPitch, 9, dt);
    this.carRoll = THREE.MathUtils.damp(this.carRoll, targetRoll, 9, dt);

    this.playerCarRig.root.position.set(this.carX, this.carY, this.carZ);
    this.playerCarRig.root.rotation.set(this.carPitch, this.carYaw, this.carRoll, 'YXZ');

    const wheelSpin = (forwardSpeed / Math.max(0.2, this.playerCarRig.wheelRadius)) * dt;
    for (const w of this.playerCarRig.wheels) {
      w.rotation.x -= wheelSpin;
    }
    for (const pivot of this.playerCarRig.frontWheelPivots) {
      pivot.rotation.y = this.carSteerAngle;
    }

    // Taillights, Brake Rotor Glow & Nitro Plasma Cones
    const heavyBraking = (reverse > 0 || handbrake) && forwardSpeed > 12;
    this.playerCarRig.taillightMat.emissiveIntensity = reverse > 0 || handbrake ? 4.5 : 1.8;
    for (const disc of this.playerCarRig.brakeDiscMats) {
      disc.emissiveIntensity = THREE.MathUtils.damp(disc.emissiveIntensity, heavyBraking ? 2.8 : 0, 8, dt);
    }

    for (const flame of this.playerCarRig.nitroFlames) {
      flame.visible = nitroActive;
      if (nitroActive) {
        flame.scale.set(1, 0.8 + Math.random() * 0.65, 1);
      }
    }

    const speedKmh = Math.hypot(this.carVx, this.carVz) * 3.6;
    this.currentSpeedRatio = THREE.MathUtils.clamp(speedKmh / 400, 0, 1);

    if (speedKmh > this.bestSpeedKmh + 2) {
      this.bestSpeedKmh = Math.round(speedKmh);
      this.callbacks.onTopSpeedRecord(this.bestSpeedKmh);
    }

    const rpmRatio = THREE.MathUtils.clamp((speedKmh % 76) / 76 * 0.65 + (speedKmh / spec.topSpeedKmh) * 0.35, 0.12, 1);
    this.sound.updateLoop(
      dt,
      true,
      rpmRatio,
      nitroActive,
      driftIntensity,
      this.weatherMode === 'monsoon',
      this.wantedLevel,
      this.playerVehicleId,
      false,
    );
  }

  private stepOnFoot(dt: number): void {
    const moveF = (this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0) + this.touchInput.throttle;
    const moveB = (this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0) + this.touchInput.brake;
    const turnL = this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0;
    const turnR = this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0;
    const sprint = Boolean(this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchInput.nitro);

    const steer = turnL - turnR - this.touchInput.steer;
    this.footYaw += steer * 3.2 * dt;

    const moveAxis = THREE.MathUtils.clamp(moveF - moveB, -1, 1);
    const speed = (sprint ? 12.5 : 7.0) * Math.abs(moveAxis);

    const fwdX = -Math.sin(this.footYaw);
    const fwdZ = -Math.cos(this.footYaw);
    let nextX = this.footX + fwdX * moveAxis * (sprint ? 12.5 : 7.0) * dt;
    let nextZ = this.footZ + fwdZ * moveAxis * (sprint ? 12.5 : 7.0) * dt;
    nextX = THREE.MathUtils.clamp(nextX, -1450, 1450);
    nextZ = THREE.MathUtils.clamp(nextZ, -1450, 1450);

    // Building AABB collision for on-foot character
    const footRadius = 0.65;
    for (let i = 0; i < this.world.buildings.length; i++) {
      const b = this.world.buildings[i];
      const closestX = THREE.MathUtils.clamp(nextX, b.minX, b.maxX);
      const closestZ = THREE.MathUtils.clamp(nextZ, b.minZ, b.maxZ);
      const dx = nextX - closestX;
      const dz = nextZ - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < footRadius * footRadius) {
        const dist = Math.sqrt(distSq) || 0.001;
        nextX += (dx / dist) * (footRadius - dist);
        nextZ += (dz / dist) * (footRadius - dist);
      }
    }

    this.footX = nextX;
    this.footZ = nextZ;

    const gy = this.world.groundHeightAt(this.footX, this.footZ);
    this.footVy -= 22 * dt;
    this.footY += this.footVy * dt;
    let airborne = true;
    if (this.footY <= gy) {
      this.footY = gy;
      this.footVy = 0;
      airborne = false;
    }

    this.playerCharRig.root.position.set(this.footX, this.footY, this.footZ);
    this.playerCharRig.root.rotation.y = this.footYaw;
    this.playerCharRig.animateWalk(speed, this.elapsedTime, airborne, this.aimingTimer > 0);

    this.sound.updateLoop(
      dt,
      false,
      0,
      false,
      0,
      this.weatherMode === 'monsoon',
      this.wantedLevel,
      this.playerVehicleId,
      false,
    );
  }

  private stepPedestrians(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const carSpeed = this.onFoot ? 0 : Math.hypot(this.carVx, this.carVz);

    for (let i = 0; i < this.pedestrians.length; i++) {
      const ped = this.pedestrians[i];
      if (!ped.alive) {
        ped.respawnTimer -= dt;
        if (ped.respawnTimer <= 0) {
          ped.alive = true;
          ped.x = ped.homeX + (Math.random() - 0.5) * 8;
          ped.z = ped.homeZ + (Math.random() - 0.5) * 8;
          ped.rig.root.position.set(ped.x, this.world.groundHeightAt(ped.x, ped.z), ped.z);
          ped.rig.root.visible = true;
        }
        continue;
      }

      ped.turnTimer -= dt;
      if (ped.turnTimer <= 0) {
        ped.turnTimer = 2.5 + Math.random() * 3.5;
        const distHome = Math.hypot(ped.x - ped.homeX, ped.z - ped.homeZ);
        if (distHome > ped.walkRadius) {
          ped.yaw = Math.atan2(-(ped.homeX - ped.x), -(ped.homeZ - ped.z));
        } else {
          ped.yaw += (Math.random() - 0.5) * 2.1;
        }
      }

      ped.x += -Math.sin(ped.yaw) * ped.speed * dt;
      ped.z += -Math.cos(ped.yaw) * ped.speed * dt;
      const gy = this.world.groundHeightAt(ped.x, ped.z);
      ped.rig.root.position.set(ped.x, gy, ped.z);
      ped.rig.root.rotation.y = ped.yaw;

      // Animate only reasonably close pedestrians to save CPU
      const distSq = (px - ped.x) * (px - ped.x) + (pz - ped.z) * (pz - ped.z);
      if (distSq < 180 * 180) {
        ped.rig.animateWalk(ped.speed, this.elapsedTime + i * 0.4, false, false);
      }

      if (!this.onFoot && !this.inAircraft && carSpeed > 6.5 && distSq < 4.84) {
        this.sound.playCrash(Math.min(0.85, carSpeed / 22));
        this.handlePedestrianKilled(ped, this.carVx, this.carVz);
      }
    }
  }

  private stepTraffic(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const ewRoads = JAIPUR_EW_ROADS;
    const nsRoads = JAIPUR_NS_ROADS;

    for (let i = 0; i < this.trafficCars.length; i++) {
      const tc = this.trafficCars[i];
      tc.turnCooldown = Math.max(0, tc.turnCooldown - dt);

      let blocked = false;
      const fwdX = tc.axis === 'x' ? tc.dir : 0;
      const fwdZ = tc.axis === 'z' ? tc.dir : 0;

      const pDx = px - tc.x;
      const pDz = pz - tc.z;
      const pFwd = pDx * fwdX + pDz * fwdZ;
      const pLat = Math.abs(pDx * fwdZ - pDz * fwdX);
      if (pFwd > 1.5 && pFwd < 15.5 && pLat < 3.0 && !this.inAircraft) {
        blocked = true;
      }

      if (!blocked) {
        for (let j = 0; j < this.trafficCars.length; j++) {
          if (i === j) continue;
          const other = this.trafficCars[j];
          const dx = other.x - tc.x;
          const dz = other.z - tc.z;
          const fwd = dx * fwdX + dz * fwdZ;
          const lat = Math.abs(dx * fwdZ - dz * fwdX);
          if (fwd > 1.0 && fwd < 13.5 && lat < 2.6) {
            blocked = true;
            break;
          }
        }
      }

      // Obey Red / Amber Jaipur Traffic Signals!
      if (!blocked) {
        for (let ti = 0; ti < this.world.trafficLights.length; ti++) {
          const tl = this.world.trafficLights[ti];
          const sdx = tl.x - tc.x;
          const sdZ = tl.z - tc.z;
          const sFwd = sdx * fwdX + sdZ * fwdZ;
          const sLat = Math.abs(sdx * fwdZ - sdZ * fwdX);
          if (sLat < 11 && sFwd > 13 && sFwd < 25) {
            const sig = this.getSignalPhase(tl.phaseOffset, tc.axis);
            if (sig === 'RED' || sig === 'AMBER') {
              blocked = true;
              break;
            }
          }
        }
      }

      // Smoothly curve around Jaipur Circle center islands
      let desiredLane = tc.laneCoord;
      for (let ci = 0; ci < JAIPUR_CIRCLES.length; ci++) {
        const c = JAIPUR_CIRCLES[ci];
        const dc = Math.hypot(tc.x - c.x, tc.z - c.z);
        if (dc < 24) {
          const islandR = Math.max(5.5, Math.min(10.5, c.radius * 0.42));
          if (tc.axis === 'x') desiredLane = c.z + (tc.dir === 1 ? -(islandR + 4.5) : islandR + 4.5);
          else desiredLane = c.x + (tc.dir === 1 ? islandR + 4.5 : -(islandR + 4.5));
          break;
        }
      }

      tc.blocked = blocked;
      const targetSpeed = blocked ? 0 : tc.cruiseSpeed;
      tc.currentSpeed = THREE.MathUtils.damp(tc.currentSpeed, targetSpeed, blocked ? 7.5 : 3.2, dt);
      tc.rig.taillightMat.emissiveIntensity = blocked ? 4.2 : 1.6;

      if (tc.axis === 'x') {
        tc.x += tc.dir * tc.currentSpeed * dt;
        tc.z = THREE.MathUtils.damp(tc.z, desiredLane, 6, dt);
        if (tc.x > 1360) tc.x = -1360;
        if (tc.x < -1360) tc.x = 1360;

        if (tc.turnCooldown <= 0) {
          for (const crossX of nsRoads) {
            if (Math.abs(tc.x - crossX) < 1.6) {
              if (Math.random() < 0.36) {
                const newDir: 1 | -1 = Math.random() > 0.5 ? 1 : -1;
                tc.axis = 'z';
                tc.dir = newDir;
                tc.roadCoord = crossX;
                tc.laneCoord = this.computeTrafficLane('z', crossX, newDir);
                tc.x = tc.laneCoord;
                tc.targetYaw = this.computeTrafficYaw('z', newDir);
                tc.turnCooldown = 6.5;
              } else {
                tc.turnCooldown = 2.0;
              }
              break;
            }
          }
        }
      } else {
        tc.z += tc.dir * tc.currentSpeed * dt;
        tc.x = THREE.MathUtils.damp(tc.x, desiredLane, 6, dt);
        if (tc.z > 1360) tc.z = -1360;
        if (tc.z < -1360) tc.z = 1360;

        if (tc.turnCooldown <= 0) {
          for (const crossZ of ewRoads) {
            if (Math.abs(tc.z - crossZ) < 1.6) {
              if (Math.random() < 0.36) {
                const newDir: 1 | -1 = Math.random() > 0.5 ? 1 : -1;
                tc.axis = 'x';
                tc.dir = newDir;
                tc.roadCoord = crossZ;
                tc.laneCoord = this.computeTrafficLane('x', crossZ, newDir);
                tc.z = tc.laneCoord;
                tc.targetYaw = this.computeTrafficYaw('x', newDir);
                tc.turnCooldown = 6.5;
              } else {
                tc.turnCooldown = 2.0;
              }
              break;
            }
          }
        }
      }

      let yawDiff = tc.targetYaw - tc.yaw;
      while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
      while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
      tc.yaw += yawDiff * Math.min(1, 7.5 * dt);

      tc.y = this.world.groundHeightAt(tc.x, tc.z);
      tc.rig.root.position.set(tc.x, tc.y, tc.z);
      const bikeLean = tc.rig.isTwoWheeler ? THREE.MathUtils.clamp(yawDiff * 0.45, -0.35, 0.35) : 0;
      tc.rig.root.rotation.set(0, tc.yaw, bikeLean, 'YXZ');

      const spin = (tc.currentSpeed / Math.max(0.2, tc.rig.wheelRadius)) * dt;
      for (const w of tc.rig.wheels) {
        w.rotation.x -= spin;
      }

      if (!this.onFoot) {
        const dx = px - tc.x;
        const dz = pz - tc.z;
        const distSq = dx * dx + dz * dz;
        const hitDistSq = tc.rig.isTwoWheeler ? 7.5 : 11.5;
        if (distSq < hitDistSq) {
          const dist = Math.sqrt(distSq) || 0.1;
          const nx = dx / dist;
          const nz = dz / dist;
          this.carX += nx * 0.85;
          this.carZ += nz * 0.85;
          const relSpeed = Math.hypot(this.carVx, this.carVz);
          this.carVx = this.carVx * 0.64 + nx * 7;
          this.carVz = this.carVz * 0.64 + nz * 7;
          tc.currentSpeed = 0;
          if (relSpeed > 24) {
            this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.38);
            this.sound.playCrash(relSpeed / 22);
            this.hitstopTimer = 0.03;
            this.spawnDebrisBurst(tc.x, tc.z, 0xeab308, this.carVx, this.carVz);
            this.wantedLevel = Math.min(5, Math.max(1, this.wantedLevel + 1));
            this.wantedDecayTimer = 11;
          }
        }
      }
    }
  }

  private stepPolice(dt: number): void {
    if (this.bustedCooldown > 0) {
      this.bustedCooldown = Math.max(0, this.bustedCooldown - dt);
    }

    if (this.wantedLevel <= 0) {
      this.bustedProgress = Math.max(0, this.bustedProgress - dt * 2.5);
      for (const pc of this.policeCars) {
        pc.active = false;
        pc.rig.root.visible = false;
      }
      return;
    }

    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const playerSpeedKmh = this.onFoot ? 6 : Math.hypot(this.carVx, this.carVz) * 3.6;
    const desiredCount = Math.min(this.policeCars.length, this.wantedLevel);
    const flashRed = Math.floor(this.elapsedTime * 8) % 2 === 0;
    let closestDist = Infinity;

    for (let i = 0; i < this.policeCars.length; i++) {
      const pc = this.policeCars[i];
      if (i >= desiredCount) {
        pc.active = false;
        pc.rig.root.visible = false;
        continue;
      }

      if (!pc.active) {
        if (i === 0) {
          // Spawn primary pursuer directly behind player heading
          const yaw = this.onFoot ? this.footYaw : this.carYaw;
          const fwdX = -Math.sin(yaw);
          const fwdZ = -Math.cos(yaw);
          pc.x = THREE.MathUtils.clamp(px - fwdX * 58, -1400, 1400);
          pc.z = THREE.MathUtils.clamp(pz - fwdZ * 58, -1400, 1400);
          pc.yaw = yaw;
        } else {
          const ang = (i / desiredCount) * Math.PI * 2 + this.elapsedTime;
          pc.x = THREE.MathUtils.clamp(px + Math.cos(ang) * 90, -1400, 1400);
          pc.z = THREE.MathUtils.clamp(pz + Math.sin(ang) * 90, -1400, 1400);
        }
        pc.hp = 100;
        pc.active = true;
        pc.rig.root.visible = true;
      }

      if (pc.rig.policeLightBar) {
        (pc.rig.policeLightBar.red.material as THREE.MeshStandardMaterial).emissiveIntensity = flashRed ? 4.5 : 0.2;
        (pc.rig.policeLightBar.blue.material as THREE.MeshStandardMaterial).emissiveIntensity = flashRed ? 0.2 : 4.5;
      }

      const dx = px - pc.x;
      const dz = pz - pc.z;
      const dist = Math.hypot(dx, dz) || 1;
      if (dist < closestDist) closestDist = dist;

      const targetYaw = Math.atan2(-dx, -dz);
      let diff = targetYaw - pc.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      pc.yaw += diff * Math.min(1, 2.8 * dt);

      // Less strict pursuit speed + building AABB push-out
      const chaseSpeed = 22 + this.wantedLevel * 3.6;
      pc.x += -Math.sin(pc.yaw) * chaseSpeed * dt;
      pc.z += -Math.cos(pc.yaw) * chaseSpeed * dt;
      const pRad = 1.9;
      for (let bi = 0; bi < this.world.buildings.length; bi++) {
        const b = this.world.buildings[bi];
        const cx = THREE.MathUtils.clamp(pc.x, b.minX, b.maxX);
        const cz = THREE.MathUtils.clamp(pc.z, b.minZ, b.maxZ);
        const bdx = pc.x - cx;
        const bdz = pc.z - cz;
        const dSq = bdx * bdx + bdz * bdz;
        if (dSq < pRad * pRad) {
          const dLen = Math.sqrt(dSq) || 0.001;
          pc.x += (bdx / dLen) * (pRad - dLen);
          pc.z += (bdz / dLen) * (pRad - dLen);
        }
      }
      pc.y = this.world.groundHeightAt(pc.x, pc.z);
      pc.rig.root.position.set(pc.x, pc.y, pc.z);
      pc.rig.root.rotation.y = pc.yaw;

      const spin = (chaseSpeed / Math.max(0.2, pc.rig.wheelRadius)) * dt;
      for (const w of pc.rig.wheels) {
        w.rotation.x -= spin;
      }

      if (dist > 220) {
        pc.active = false;
        pc.rig.root.visible = false;
      }

      if (dist < 3.3) {
        if (!this.onFoot) {
          this.carVx += (-Math.sin(pc.yaw)) * 7;
          this.carVz += (-Math.cos(pc.yaw)) * 7;
          this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.25);
          this.sound.playCrash(0.75);
          this.applyPlayerDamage(5);
        } else {
          this.applyPlayerDamage(10);
        }
        pc.x -= (-Math.sin(pc.yaw)) * 8;
        pc.z -= (-Math.cos(pc.yaw)) * 8;
        if (this.health <= 0 && this.bustedCooldown <= 0) {
          this.handlePlayerWasted();
          return;
        }
      }
    }

    // Cool down wanted faster when far away from cruisers
    const decayRate = closestDist > 65 ? 1.8 : 1.0;
    this.wantedDecayTimer -= dt * decayRate;
    if (this.wantedDecayTimer <= 0 && (!this.activeMission || this.activeMission.type !== 'survival')) {
      this.wantedLevel = Math.max(0, this.wantedLevel - 1);
      this.wantedDecayTimer = 10;
    }

    // Fairer, less strict busted arrest rule (requires pinning at <8 km/h for 4s)
    if (this.bustedCooldown <= 0 && closestDist < 4.8 && playerSpeedKmh < 8) {
      this.bustedProgress = Math.min(1, this.bustedProgress + dt / 4.0);
      if (this.bustedProgress >= 1) {
        this.handlePlayerBusted();
      }
    } else {
      this.bustedProgress = Math.max(0, this.bustedProgress - dt * 1.8);
    }
  }

  private stepPoliceHelicopters(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    // Police helicopters deploy at 4-star (1 chopper) and 5-star (2 choppers)
    const desiredHelis = this.wantedLevel >= 5 ? 2 : this.wantedLevel >= 4 ? 1 : 0;
    const flashRed = Math.floor(this.elapsedTime * 10) % 2 === 0;

    for (let i = 0; i < this.policeHelicopters.length; i++) {
      const h = this.policeHelicopters[i];

      if (h.crashing) {
        h.crashTimer -= dt;
        h.y -= 15 * dt;
        h.x += Math.cos(h.orbitAngle) * 14 * dt;
        h.z += Math.sin(h.orbitAngle) * 14 * dt;
        h.yaw += 6.5 * dt;
        h.rig.root.position.set(h.x, h.y, h.z);
        h.rig.root.rotation.y = h.yaw;
        h.rig.bodyGroup.rotation.z = 0.55;
        h.rig.mainRotor.rotation.y += 16 * dt;
        if (Math.random() < 0.7) {
          this.spawnSmokePuff(h.x, h.y + 1, h.z);
        }
        const gy = this.world.groundHeightAt(h.x, h.z);
        if (h.y <= gy + 1.5 || h.crashTimer <= 0) {
          this.triggerExplosion(h.x, gy + 1.2, h.z, 12, 80);
          h.crashing = false;
          h.active = false;
          h.rig.root.visible = false;
          h.rig.groundSpot.visible = false;
        }
        continue;
      }

      if (i >= desiredHelis) {
        if (h.active) {
          h.active = false;
          h.rig.root.visible = false;
          h.rig.groundSpot.visible = false;
        }
        continue;
      }

      if (!h.active) {
        const ang = i * Math.PI + this.elapsedTime;
        h.x = px + Math.cos(ang) * 155;
        h.z = pz + Math.sin(ang) * 155;
        h.y = 46;
        h.hp = h.maxHp;
        h.orbitAngle = ang;
        h.active = true;
        h.rig.root.visible = true;
        h.rig.searchBeam.visible = true;
        h.rig.groundSpot.visible = true;
        h.rig.bodyGroup.rotation.set(0, 0, 0);
      }

      // Spin main & tail rotors + police strobes
      h.rig.mainRotor.rotation.y += 24 * dt;
      h.rig.tailRotor.rotation.x += 28 * dt;
      h.rig.redMat.emissiveIntensity = flashRed ? 4.8 : 0.2;
      h.rig.blueMat.emissiveIntensity = flashRed ? 0.2 : 4.8;

      // Orbit smoothly around the player
      h.orbitAngle += (i === 0 ? 0.42 : -0.38) * dt;
      const orbitRad = 28 + i * 11;
      const targetX = px + Math.cos(h.orbitAngle) * orbitRad;
      const targetZ = pz + Math.sin(h.orbitAngle) * orbitRad;
      const targetY = 33 + Math.sin(this.elapsedTime * 1.4 + i) * 3.5;

      const vx = (targetX - h.x) * 1.65;
      const vz = (targetZ - h.z) * 1.65;
      h.x += vx * dt;
      h.z += vz * dt;
      h.y = THREE.MathUtils.damp(h.y, targetY, 3.2, dt);

      const desiredYaw = Math.atan2(-(px - h.x), -(pz - h.z));
      let yDiff = desiredYaw - h.yaw;
      while (yDiff > Math.PI) yDiff -= Math.PI * 2;
      while (yDiff < -Math.PI) yDiff += Math.PI * 2;
      h.yaw += yDiff * Math.min(1, 4.0 * dt);

      h.rig.root.position.set(h.x, h.y, h.z);
      h.rig.root.rotation.y = h.yaw;
      h.rig.bodyGroup.rotation.x = 0.14;
      h.rig.bodyGroup.rotation.z = THREE.MathUtils.clamp(-yDiff * 0.22, -0.32, 0.32);

      // Searchlight ground spotlight tracking near player
      const spotX = px + Math.sin(this.elapsedTime * 1.8 + i) * 4.5;
      const spotZ = pz + Math.cos(this.elapsedTime * 1.5 + i) * 4.5;
      h.rig.groundSpot.position.set(spotX, this.world.groundHeightAt(spotX, spotZ) + 0.15, spotZ);

      // Tracer fire at Wanted 4+
      if (this.wantedLevel >= 4) {
        h.fireCooldown -= dt;
        if (h.fireCooldown <= 0) {
          h.fireCooldown = 2.6;
          const proj = this.projectilePool[this.projectileCursor];
          this.projectileCursor = (this.projectileCursor + 1) % this.projectilePool.length;
          const dx = px - h.x + (Math.random() - 0.5) * 6;
          const dy = (this.onFoot ? this.footY + 1 : this.carY + 0.8) - h.y;
          const dz = pz - h.z + (Math.random() - 0.5) * 6;
          const len = Math.hypot(dx, dy, dz) || 1;
          proj.active = true;
          proj.fromEnemy = true;
          proj.vx = (dx / len) * 68;
          proj.vy = (dy / len) * 68;
          proj.vz = (dz / len) * 68;
          proj.life = 1.6;
          proj.damage = 3;
          proj.explosiveRadius = 0;
          (proj.mesh.material as THREE.MeshBasicMaterial).color.setHex(0xef4444);
          proj.mesh.scale.setScalar(1.3);
          proj.mesh.position.set(h.x, h.y - 0.5, h.z);
          proj.mesh.visible = true;
        }
      }
    }
  }

  private stepProjectiles(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const py = this.onFoot ? this.footY + 1 : this.carY + 0.9;
    const pz = this.onFoot ? this.footZ : this.carZ;

    for (let i = 0; i < this.projectilePool.length; i++) {
      const p = this.projectilePool[i];
      if (!p.active) continue;
      p.life -= dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;

      const x = p.mesh.position.x;
      const y = p.mesh.position.y;
      const z = p.mesh.position.z;

      if (p.life <= 0 || y <= this.world.groundHeightAt(x, z)) {
        if (!p.fromEnemy && p.explosiveRadius > 0) {
          this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
        }
        p.active = false;
        p.mesh.visible = false;
        continue;
      }

      if (p.fromEnemy) {
        if (Math.hypot(x - px, y - py, z - pz) < 2.2) {
          this.applyPlayerDamage(p.damage);
          this.cameraTrauma = Math.min(1, this.cameraTrauma + 0.14);
          p.active = false;
          p.mesh.visible = false;
          if (this.health <= 0 && this.bustedCooldown <= 0) {
            this.handlePlayerWasted();
            return;
          }
        }
        continue;
      }

      // Check Police Helicopters
      let hit = false;
      for (const heli of this.policeHelicopters) {
        if (!heli.active || heli.crashing) continue;
        if (Math.hypot(x - heli.x, y - (heli.y + 0.6), z - heli.z) < 6.2) {
          hit = true;
          if (p.explosiveRadius > 0) {
            this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
          } else {
            heli.hp -= p.damage;
            this.spawnDebrisBurst(heli.x, heli.z, 0x38bdf8, p.vx * 0.2, p.vz * 0.2);
            if (heli.hp <= 0) {
              this.downHelicopter(heli);
            }
          }
          break;
        }
      }

      // Check Bounty Gangster Car
      if (!hit && this.rogueCar?.active) {
        if (Math.hypot(x - this.rogueCar.x, z - this.rogueCar.z) < 3.2 && y < 2.5) {
          hit = true;
          if (p.explosiveRadius > 0) {
            this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
          } else {
            this.rogueCar.hp -= p.damage;
            this.spawnDebrisBurst(this.rogueCar.x, this.rogueCar.z, 0x7c3aed, p.vx * 0.2, p.vz * 0.2);
          }
        }
      }

      // Check Police Cars
      if (!hit) {
        for (const pc of this.policeCars) {
          if (!pc.active) continue;
          if (Math.hypot(x - pc.x, y - (pc.y + 0.9), z - pc.z) < 2.9) {
            hit = true;
            if (p.explosiveRadius > 0) {
              this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
            } else {
              pc.hp -= p.damage;
              this.spawnDebrisBurst(pc.x, pc.z, 0x2563eb, p.vx * 0.2, p.vz * 0.2);
              if (pc.hp <= 0) {
                this.disablePoliceCar(pc);
              }
            }
            break;
          }
        }
      }

      // Check Pedestrians
      if (!hit) {
        for (const ped of this.pedestrians) {
          if (!ped.alive) continue;
          if (Math.hypot(x - ped.x, z - ped.z) < 1.35 && y < 2.4) {
            hit = true;
            if (p.explosiveRadius > 0) {
              this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
            } else {
              this.handlePedestrianKilled(ped, p.vx * 0.35, p.vz * 0.35);
            }
            break;
          }
        }
      }

      // Check Destructible Props
      if (!hit) {
        for (const prop of this.world.destructibles) {
          if (prop.smashed) continue;
          if (Math.hypot(x - prop.x, z - prop.z) < prop.radius + 1.1 && y < 5.5) {
            hit = true;
            if (p.explosiveRadius > 0) {
              this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
            } else {
              this.smashDestructibleProp(prop, p.vx * 0.3, p.vz * 0.3);
            }
            break;
          }
        }
      }

      // Check Buildings
      if (!hit) {
        for (const b of this.world.buildings) {
          if (x >= b.minX && x <= b.maxX && z >= b.minZ && z <= b.maxZ && y <= b.height) {
            hit = true;
            if (p.explosiveRadius > 0) {
              this.triggerExplosion(x, y, z, p.explosiveRadius, p.damage);
            } else {
              this.spawnDebrisBurst(x, z, 0xfbbf24, -p.vx * 0.15, -p.vz * 0.15);
            }
            break;
          }
        }
      }

      if (hit) {
        p.active = false;
        p.mesh.visible = false;
      }
    }
  }

  private stepExplosions(dt: number): void {
    for (let i = 0; i < this.explosionPool.length; i++) {
      const e = this.explosionPool[i];
      if (e.life <= 0) continue;
      e.life -= dt;
      const t = 1 - e.life / e.maxLife;
      e.mesh.scale.setScalar(1 + t * e.maxScale);
      (e.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * 0.85;
      if (e.life <= 0) e.mesh.visible = false;
    }
  }

  private stepDestructibles(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const speed = this.onFoot ? 8 : Math.hypot(this.carVx, this.carVz);
    const hitPad = this.onFoot ? 0.9 : 1.7;

    for (let i = 0; i < this.world.destructibles.length; i++) {
      const prop = this.world.destructibles[i];
      if (prop.smashed) {
        prop.respawnTimer -= dt;
        if (prop.respawnTimer <= 0) {
          this.world.resetProp(prop);
        }
        continue;
      }

      const dx = px - prop.x;
      const dz = pz - prop.z;
      const r = prop.radius + hitPad;
      if (dx * dx + dz * dz < r * r && speed > 4) {
        this.sound.playCrash(Math.min(1.2, speed / 24));
        this.smashDestructibleProp(prop, this.carVx, this.carVz);
      }
    }
  }

  private stepDebris(dt: number): void {
    for (let i = 0; i < this.debrisPool.length; i++) {
      const d = this.debrisPool[i];
      if (d.life <= 0) continue;
      d.life -= dt;
      d.vy -= 22 * dt;
      d.mesh.position.x += d.vx * dt;
      d.mesh.position.y += d.vy * dt;
      d.mesh.position.z += d.vz * dt;
      d.mesh.rotation.x += d.rx * dt;
      d.mesh.rotation.y += d.ry * dt;
      if (d.mesh.position.y < 0.25) {
        d.mesh.position.y = 0.25;
        d.vy = Math.abs(d.vy) * 0.42;
        d.vx *= 0.72;
        d.vz *= 0.72;
      }
      if (d.life <= 0) d.mesh.visible = false;
    }
  }

  private stepSmoke(dt: number): void {
    for (let i = 0; i < this.smokePool.length; i++) {
      const s = this.smokePool[i];
      if (s.life <= 0) continue;
      s.life -= dt;
      s.mesh.position.x += s.vx * dt;
      s.mesh.position.y += s.vy * dt;
      s.mesh.position.z += s.vz * dt;
      const t = 1 - s.life / s.maxLife;
      s.mesh.scale.setScalar(0.6 + t * 1.9);
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * 0.36;
      if (s.life <= 0) s.mesh.visible = false;
    }
  }

  private stepWindStreaks(dt: number): void {
    const speedKmh = this.onFoot ? 0 : Math.hypot(this.carVx, this.carVz) * 3.6;
    const windAlpha = THREE.MathUtils.smoothstep(speedKmh, 130, 320) * 0.32;
    this.windStreakMesh.visible = windAlpha > 0.01;
    if (windAlpha <= 0.01) return;
    (this.windStreakMesh.material as THREE.MeshBasicMaterial).opacity = windAlpha;

    const fwdX = -Math.sin(this.carYaw);
    const fwdZ = -Math.cos(this.carYaw);
    const rightX = Math.cos(this.carYaw);
    const rightZ = -Math.sin(this.carYaw);
    const streakSpeed = Math.max(45, speedKmh * 0.45);
    const streakLenScale = THREE.MathUtils.clamp(speedKmh / 240, 0.65, 1.85);

    for (let i = 0; i < this.windStreakMesh.count; i++) {
      let zOff = this.windOffsets[i * 3 + 2] - streakSpeed * dt;
      if (zOff < -20) zOff += 44;
      this.windOffsets[i * 3 + 2] = zOff;

      const xOff = this.windOffsets[i * 3];
      const yOff = this.windOffsets[i * 3 + 1];
      _dummy.position.set(
        this.carX + rightX * xOff + fwdX * zOff,
        this.carY + yOff,
        this.carZ + rightZ * xOff + fwdZ * zOff,
      );
      _dummy.rotation.set(0, this.carYaw, 0);
      _dummy.scale.set(1, 1, streakLenScale);
      _dummy.updateMatrix();
      this.windStreakMesh.setMatrixAt(i, _dummy.matrix);
    }
    this.windStreakMesh.instanceMatrix.needsUpdate = true;
  }

  private stepRemotePeers(dt: number): void {
    const smooth = 1 - Math.exp(-12 * dt);
    for (const actor of this.remotePeers.values()) {
      actor.curX = THREE.MathUtils.lerp(actor.curX, actor.targetX, smooth);
      actor.curY = THREE.MathUtils.lerp(actor.curY, actor.targetY, smooth);
      actor.curZ = THREE.MathUtils.lerp(actor.curZ, actor.targetZ, smooth);

      let diff = actor.targetYaw - actor.curYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      actor.curYaw += diff * smooth;

      if (actor.onFoot) {
        actor.carRig.root.visible = false;
        actor.charRig.root.visible = true;
        actor.charRig.root.position.set(actor.curX, actor.curY, actor.curZ);
        actor.charRig.root.rotation.y = actor.curYaw;
        actor.charRig.animateWalk(actor.speed, this.elapsedTime, false);
      } else {
        actor.charRig.root.visible = false;
        actor.carRig.root.visible = true;
        actor.carRig.root.position.set(actor.curX, actor.curY, actor.curZ);
        actor.carRig.root.rotation.y = actor.curYaw;
      }
    }
  }

  private stepWeatherEffects(dt: number): void {
    if (this.weatherMode !== 'monsoon') return;
    const cx = this.isTitleShowcase ? 120 : this.onFoot ? this.footX : this.carX;
    const cz = this.isTitleShowcase ? -225 : this.onFoot ? this.footZ : this.carZ;
    const count = this.rainMesh.count;

    for (let i = 0; i < count; i++) {
      this.rainOffsets[i * 3 + 1] -= 36 * dt;
      if (this.rainOffsets[i * 3 + 1] < 0) {
        this.rainOffsets[i * 3 + 1] = 36 + Math.random() * 8;
      }
      _dummy.position.set(
        cx + this.rainOffsets[i * 3],
        this.rainOffsets[i * 3 + 1],
        cz + this.rainOffsets[i * 3 + 2],
      );
      _dummy.rotation.set(0, 0, 0.08);
      _dummy.scale.set(1, 1, 1);
      _dummy.updateMatrix();
      this.rainMesh.setMatrixAt(i, _dummy.matrix);
    }
    this.rainMesh.instanceMatrix.needsUpdate = true;

    this.lightningTimer += dt;
    if (this.lightningTimer > 9.5) {
      this.lightningTimer = 0;
      this.lightningFlash = 1.0;
      this.sound.playThunder();
    }
    if (this.lightningFlash > 0) {
      this.lightningFlash = Math.max(0, this.lightningFlash - dt * 3.5);
      this.sunLight.intensity = 1.25 + this.lightningFlash * 3.8;
    }
  }

  private updateGpsHighlight(px: number, pz: number): void {
    const wp = this.getActiveWaypoint();
    if (!wp) {
      this.gpsRoutePoints = [];
      this.gpsRibbonMesh.visible = false;
      this.gpsArrowInst.visible = false;
      return;
    }

    const movedOrigin = Math.hypot(px - this.lastGpsOriginX, pz - this.lastGpsOriginZ);
    const movedDest = Math.hypot(wp.x - this.lastGpsDestX, wp.z - this.lastGpsDestZ);

    if (movedOrigin > 10 || movedDest > 2 || this.gpsRoutePoints.length === 0) {
      this.lastGpsOriginX = px;
      this.lastGpsOriginZ = pz;
      this.lastGpsDestX = wp.x;
      this.lastGpsDestZ = wp.z;
      this.gpsRoutePoints = computeJaipurGpsRoute(px, pz, wp.x, wp.z);

      // Subdivide route into ~18m samples for smooth terrain elevation & bridge slope hugging
      const samples: Array<{ x: number; z: number; nx: number; nz: number }> = [];
      for (let i = 0; i < this.gpsRoutePoints.length - 1; i++) {
        const a = this.gpsRoutePoints[i];
        const b = this.gpsRoutePoints[i + 1];
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const segLen = Math.hypot(dx, dz) || 1;
        const dirX = dx / segLen;
        const dirZ = dz / segLen;
        const rightX = -dirZ;
        const rightZ = dirX;
        const steps = Math.max(1, Math.ceil(segLen / 22));
        for (let s = 0; s < steps; s++) {
          if (samples.length >= 127) break;
          const t = s / steps;
          samples.push({ x: a.x + dx * t, z: a.z + dz * t, nx: rightX, nz: rightZ });
        }
        if (samples.length >= 127) break;
      }
      const lastPt = this.gpsRoutePoints[this.gpsRoutePoints.length - 1];
      const prevSample = samples[samples.length - 1];
      samples.push({
        x: lastPt.x,
        z: lastPt.z,
        nx: prevSample ? prevSample.nx : 1,
        nz: prevSample ? prevSample.nz : 0,
      });

      const halfWidth = 1.65;
      for (let i = 0; i < samples.length; i++) {
        const pt = samples[i];
        const y = this.world.groundHeightAt(pt.x, pt.z) + 0.16;
        const base = i * 6;
        this.gpsRibbonPositions[base] = pt.x - pt.nx * halfWidth;
        this.gpsRibbonPositions[base + 1] = y;
        this.gpsRibbonPositions[base + 2] = pt.z - pt.nz * halfWidth;
        this.gpsRibbonPositions[base + 3] = pt.x + pt.nx * halfWidth;
        this.gpsRibbonPositions[base + 4] = y;
        this.gpsRibbonPositions[base + 5] = pt.z + pt.nz * halfWidth;
      }
      const posAttr = this.gpsRibbonMesh.geometry.getAttribute('position') as THREE.BufferAttribute;
      posAttr.needsUpdate = true;
      this.gpsRibbonMesh.geometry.setDrawRange(0, Math.max(0, (samples.length - 1) * 6));

      // Place directional chevrons every 26m along route
      this.gpsArrowPositions = [];
      let carry = 10;
      for (let i = 0; i < this.gpsRoutePoints.length - 1; i++) {
        const a = this.gpsRoutePoints[i];
        const b = this.gpsRoutePoints[i + 1];
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const segLen = Math.hypot(dx, dz);
        if (segLen < 1) continue;
        const yaw = Math.atan2(dx, dz);
        let d = carry;
        while (d < segLen && this.gpsArrowPositions.length < 120) {
          const t = d / segLen;
          const ax = a.x + dx * t;
          const az = a.z + dz * t;
          const ay = this.world.groundHeightAt(ax, az) + 0.24;
          this.gpsArrowPositions.push({ x: ax, y: ay, z: az, yaw });
          d += 26;
        }
        carry = d - segLen;
      }
      this.gpsArrowInst.count = this.gpsArrowPositions.length;
    }

    this.gpsRibbonMesh.visible = this.gpsRoutePoints.length >= 2;
    this.gpsArrowInst.visible = this.gpsArrowPositions.length > 0;

    // Gentle forward-flowing pulse scale on directional chevrons
    for (let i = 0; i < this.gpsArrowPositions.length; i++) {
      const ap = this.gpsArrowPositions[i];
      const pulse = 0.85 + 0.3 * Math.max(0, Math.sin(this.elapsedTime * 5.2 - i * 0.75));
      _dummy.position.set(ap.x, ap.y, ap.z);
      _dummy.rotation.set(0, ap.yaw, 0);
      _dummy.scale.set(pulse, 1, pulse);
      _dummy.updateMatrix();
      this.gpsArrowInst.setMatrixAt(i, _dummy.matrix);
    }
    this.gpsArrowInst.instanceMatrix.needsUpdate = true;
  }

  private stepMission(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const pz = this.onFoot ? this.footZ : this.carZ;

    if (this.activeJob) {
      const wp = this.getActiveWaypoint();
      if (wp) {
        this.waypointBeacon.visible = true;
        this.waypointBeacon.position.set(wp.x, this.world.groundHeightAt(wp.x, wp.z), wp.z);
        this.waypointBeacon.rotation.y += dt * 2.0;
      } else {
        this.waypointBeacon.visible = false;
      }
      this.updateGpsHighlight(px, pz);
      return;
    }

    if (!this.activeMission) {
      if (this.customWaypoint) {
        this.waypointBeacon.visible = true;
        this.waypointBeacon.position.set(this.customWaypoint.x, 0, this.customWaypoint.z);
        this.waypointBeacon.rotation.y += dt * 1.5;
        if (Math.hypot(px - this.customWaypoint.x, pz - this.customWaypoint.z) < 9) {
          this.customWaypoint = null;
        }
      } else {
        this.waypointBeacon.visible = false;
      }
      this.updateGpsHighlight(px, pz);
      return;
    }

    this.missionTimeLeft -= dt;
    if (this.missionTimeLeft <= 0) {
      const m = this.activeMission;
      this.activeMission = null;
      this.waypointBeacon.visible = false;
      this.updateGpsHighlight(px, pz);
      if (m.type === 'survival') {
        this.clearWanted();
        this.sound.playMissionStinger(true);
        this.callbacks.onMissionComplete(m);
      } else {
        this.sound.playMissionStinger(false);
        this.callbacks.onMissionFailed(m, 'Time expired');
      }
      return;
    }

    if (this.activeMission.type === 'smash') {
      const wp = this.activeMission.waypoints[0];
      this.waypointBeacon.visible = this.missionSmashCount < 1;
      this.waypointBeacon.position.set(wp.x, 0, wp.z);
      if (this.missionSmashCount >= this.activeMission.targetCount) {
        const m = this.activeMission;
        this.activeMission = null;
        this.waypointBeacon.visible = false;
        this.sound.playMissionStinger(true);
        this.callbacks.onMissionComplete(m);
      }
      this.updateGpsHighlight(px, pz);
      return;
    }

    if (this.activeMission.type === 'survival') {
      this.waypointBeacon.visible = false;
      this.updateGpsHighlight(px, pz);
      return;
    }

    const wp = this.activeMission.waypoints[this.missionWaypointIdx];
    if (wp) {
      this.waypointBeacon.visible = true;
      this.waypointBeacon.position.set(wp.x, this.world.groundHeightAt(wp.x, wp.z), wp.z);
      this.waypointBeacon.rotation.y += dt * 2.2;
      if (Math.hypot(px - wp.x, pz - wp.z) < 11.5) {
        this.missionWaypointIdx += 1;
        this.lastGpsDestX = 1e9;
        this.sound.playHorn(this.playerVehicleId, this.inAircraft);
        if (this.missionWaypointIdx >= this.activeMission.waypoints.length) {
          const m = this.activeMission;
          this.activeMission = null;
          this.waypointBeacon.visible = false;
          this.sound.playMissionStinger(true);
          this.callbacks.onMissionComplete(m);
        }
      }
    }
    this.updateGpsHighlight(px, pz);
  }

  private stepCamera(dt: number): void {
    const px = this.onFoot ? this.footX : this.carX;
    const py = this.onFoot ? this.footY + 1.35 : this.inAircraft ? this.carY + 2.2 : this.carY + 0.9;
    const pz = this.onFoot ? this.footZ : this.carZ;
    const yaw = this.onFoot ? this.footYaw : this.carYaw;
    const speedKmh = this.onFoot ? 10 : Math.hypot(this.carVx, this.carVz) * 3.6;

    const fwdX = -Math.sin(yaw);
    const fwdZ = -Math.cos(yaw);

    if (this.cameraMode === 'hood' && !this.onFoot) {
      const noseOff = this.inAircraft ? 2.2 : 0.4;
      _camPos.set(px + fwdX * noseOff, py + 0.65, pz + fwdZ * noseOff);
      _camTarget.set(px + fwdX * 28, py + 0.25, pz + fwdZ * 28);
      this.camera.position.copy(_camPos);
    } else if (this.cameraMode === 'cinematic') {
      const dist = this.onFoot ? 7.5 : this.inAircraft ? 22 : 13.5;
      const angle = yaw + Math.sin(this.elapsedTime * 0.45) * 0.55;
      _camPos.set(px + Math.sin(angle) * dist, py + (this.inAircraft ? 7.5 : 4.8), pz + Math.cos(angle) * dist);
      _camTarget.set(px, py + 0.5, pz);
      this.camera.position.lerp(_camPos, 1 - Math.exp(-5 * dt));
    } else {
      // Dynamic speed-reactive chase lag & low-angle road-hug at >200 km/h
      const speedNorm = THREE.MathUtils.clamp(speedKmh / 380, 0, 1);
      const dist = this.onFoot
        ? 5.8
        : this.inAircraft
          ? 20 + speedNorm * 3.5
          : (this.cameraMode === 'action' ? 7.6 : 9.8) + speedNorm * 1.6;
      const height = this.onFoot
        ? 2.6
        : this.inAircraft
          ? 6.2
          : (this.cameraMode === 'action' ? 2.75 : 3.7) - speedNorm * 0.55;
      _camPos.set(px - fwdX * dist, py + height, pz - fwdZ * dist);
      _camTarget.set(px + fwdX * (8 + speedNorm * 6), py + 0.55, pz + fwdZ * (8 + speedNorm * 6));
      this.camera.position.lerp(_camPos, 1 - Math.exp(-10.5 * dt));
    }

    // Subtle high-speed chassis rumble (>210 km/h) + crash trauma shake
    if (!this.onFoot && speedKmh > 210) {
      const vib = ((speedKmh - 210) / 260) * 0.055;
      this.camera.position.x += (Math.random() - 0.5) * vib;
      this.camera.position.y += (Math.random() - 0.5) * vib;
    }

    if (this.cameraTrauma > 0) {
      const shake = this.cameraTrauma * this.cameraTrauma * 0.65;
      this.camera.position.x += (Math.random() - 0.5) * shake;
      this.camera.position.y += (Math.random() - 0.5) * shake;
      this.cameraTrauma = Math.max(0, this.cameraTrauma - dt * 2.4);
    }

    this.camera.lookAt(_camTarget);

    // Smooth natural speed-reactive FOV widening (60° -> 75.5°)
    const speedT = THREE.MathUtils.smoothstep(speedKmh, 20, 420);
    const targetFov = 60 + speedT * 14 + this.nitroBlend * 1.5;
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 4.2, dt);
    this.camera.updateProjectionMatrix();
  }

  private emitTelemetry(px: number, pz: number): void {
    const speedKmh = this.onFoot
      ? 0
      : this.inAircraft
        ? Math.round(this.airSpeed * 3.6)
        : Math.round(Math.hypot(this.carVx, this.carVz) * 3.6);
    const spec = VEHICLE_CATALOG[this.playerVehicleId];
    const gear = this.inAircraft
      ? 7
      : speedKmh < 5
        ? 1
        : Math.min(7, Math.floor(speedKmh / (spec.topSpeedKmh / 6.5)) + 1);
    const rpmRatio = this.inAircraft
      ? THREE.MathUtils.clamp(0.2 + this.airSpeed / 145, 0.18, 1)
      : THREE.MathUtils.clamp((speedKmh % 70) / 70 * 0.72 + 0.18, 0.15, 1);
    const altitudeM = this.inAircraft
      ? Math.max(0, Math.round(this.carY - this.world.groundHeightAt(px, pz)))
      : 0;

    let canEnterVehicle = false;
    if (this.onFoot) {
      if (Math.hypot(this.footX - this.carX, this.footZ - this.carZ) < 5.5) {
        canEnterVehicle = true;
      } else {
        for (const tc of this.trafficCars) {
          if (Math.hypot(this.footX - tc.x, this.footZ - tc.z) < 5.2) {
            canEnterVehicle = true;
            break;
          }
        }
      }
    }

    let missionLabel: string | null = null;
    let missionProgress = 0;
    let missionTarget = 0;
    if (this.activeMission) {
      missionTarget = this.activeMission.targetCount;
      if (this.activeMission.type === 'smash') {
        missionLabel = `Smash bazaar props (${this.missionSmashCount}/${missionTarget})`;
        missionProgress = this.missionSmashCount;
      } else if (this.activeMission.type === 'survival') {
        const survived = Math.max(0, Math.round(this.activeMission.timeLimitSec - this.missionTimeLeft));
        missionLabel = `Survive monsoon police chase (${Math.ceil(this.missionTimeLeft)}s left)`;
        missionProgress = survived;
      } else {
        const wp = this.activeMission.waypoints[this.missionWaypointIdx];
        missionLabel = wp ? `Reach ${wp.label} (${this.missionWaypointIdx + 1}/${missionTarget})` : this.activeMission.title;
        missionProgress = this.missionWaypointIdx;
      }
    }

    let nearbyFacilityId: string | null = null;
    if (!this.inAircraft || altitudeM < 6) {
      let bestFacilityDist = 11.5;
      for (const f of WORLD_FACILITIES) {
        if (this.inAircraft && f.type !== 'airport') continue;
        const dist = Math.hypot(px - f.entryX, pz - f.entryZ);
        if (dist < bestFacilityDist) {
          bestFacilityDist = dist;
          nearbyFacilityId = f.id;
        }
      }
    }

    let nearbyBuilding: EnterableBuildingInfo | null = null;
    if (!nearbyFacilityId && (!this.inAircraft || altitudeM < 6)) {
      let bestBldDist = 10.5;
      for (let i = 0; i < this.world.enterableBuildings.length; i++) {
        const b = this.world.enterableBuildings[i];
        const dist = Math.hypot(px - b.entryX, pz - b.entryZ);
        if (dist < bestBldDist) {
          bestBldDist = dist;
          nearbyBuilding = b;
        }
      }
    }

    let signalState: 'GREEN' | 'AMBER' | 'RED' | null = null;
    if (!this.onFoot && !this.inAircraft) {
      const yaw = this.carYaw;
      const fwdX = Math.abs(-Math.sin(yaw));
      const fwdZ = Math.abs(-Math.cos(yaw));
      const axis: 'x' | 'z' = fwdX >= fwdZ ? 'x' : 'z';
      for (let i = 0; i < this.world.trafficLights.length; i++) {
        const tl = this.world.trafficLights[i];
        if (Math.hypot(px - tl.x, pz - tl.z) < 38) {
          signalState = this.getSignalPhase(tl.phaseOffset, axis);
          break;
        }
      }
    }

    let activeJobTel: ActiveJobTelemetry | null = null;
    if (this.activeJob) {
      const jwp = this.jobWaypoints[this.jobStageIdx] || this.jobWaypoints[0];
      activeJobTel = {
        type: this.activeJob.id,
        title: this.activeJob.title,
        stageLabel: jwp ? jwp.label : this.activeJob.title,
        rewardCash: this.activeJob.rewardCash,
        timeLeftSec: Math.max(0, Math.ceil(this.jobTimeLeft)),
        stepProgress: this.jobStageIdx,
        stepTarget: Math.max(1, this.jobWaypoints.length),
      };
    }

    const activeFireCount = this.firePool.filter((f) => f.active).length;
    const locality = getNearestJaipurLocality(px, pz);

    this.callbacks.onTelemetry({
      speedKmh,
      rpmRatio,
      gear,
      nitro: Math.round(this.nitro),
      fuel: Math.round(this.fuel),
      armor: Math.round(this.armor),
      onFoot: this.onFoot,
      inAircraft: this.inAircraft,
      altitudeM,
      wantedLevel: this.wantedLevel,
      bustedProgress: this.bustedProgress,
      health: Math.round(this.health),
      maxHealth: this.maxHealth,
      playerX: px,
      playerZ: pz,
      playerYaw: this.onFoot ? this.footYaw : this.carYaw,
      currentDistrict: 'jaipur',
      currentLocalityName: locality.name,
      currentZoneName: locality.zone,
      selectedWeapon: this.selectedWeapon,
      nearbyFacilityId,
      nearbyBuilding,
      signalState,
      activeMissionId: this.activeMission?.id || null,
      missionLabel,
      missionProgress,
      missionTarget,
      missionTimeLeft: Math.max(0, Math.ceil(this.missionTimeLeft)),
      activeJob: activeJobTel,
      activeFireCount,
      canEnterVehicle,
      airtimeSec: this.carAirtime,
      driftScore: this.driftScore,
      policeCount: this.policeCars.filter((p) => p.active).length,
      helicopterCount: this.policeHelicopters.filter((h) => h.active && !h.crashing).length,
    });
  }

  getNetworkSnapshot() {
    const px = this.onFoot ? this.footX : this.carX;
    const py = this.onFoot ? this.footY : this.carY;
    const pz = this.onFoot ? this.footZ : this.carZ;
    return {
      x: px,
      y: py,
      z: pz,
      yaw: this.onFoot ? this.footYaw : this.carYaw,
      speed: this.onFoot ? 7 : Math.hypot(this.carVx, this.carVz),
      vehicleId: this.playerVehicleId,
      vehicleColor: this.playerVehicleColor,
      onFoot: this.onFoot,
      wantedLevel: this.wantedLevel,
      characterConfig: this.playerCharConfig,
    };
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('mouseup', this.onMouseUp);
    this.renderer?.domElement?.removeEventListener('mousedown', this.onMouseDown);

    this.scene?.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        for (const m of mats) {
          m?.dispose();
        }
      }
    });

    this.textures?.dispose();
    this.cubeRenderTarget?.dispose();
    this.composer?.dispose();
    this.renderer?.dispose();
    if (this.renderer?.domElement?.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
