import * as THREE from 'three';
import type { VehicleId } from '../types/game';
import type { ProceduralTexturePack } from './proceduralTextures';

export interface VehicleRig {
  root: THREE.Group;
  bodyMesh: THREE.Mesh;
  paintMaterial: THREE.MeshPhysicalMaterial;
  frontWheelPivots: THREE.Group[];
  wheels: THREE.Group[];
  headlightSpots: THREE.SpotLight[];
  taillightMat: THREE.MeshStandardMaterial;
  brakeDiscMats: THREE.MeshStandardMaterial[];
  nitroFlames: THREE.Mesh[];
  policeLightBar?: { red: THREE.Mesh; blue: THREE.Mesh };
  isTwoWheeler: boolean;
  wheelRadius: number;
  setPaintColor: (hex: string) => void;
}

export interface PoliceHelicopterRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  mainRotor: THREE.Group;
  tailRotor: THREE.Group;
  redMat: THREE.MeshStandardMaterial;
  blueMat: THREE.MeshStandardMaterial;
  searchBeam: THREE.Mesh;
  groundSpot: THREE.Mesh;
}

function buildWheel(
  radius: number,
  width: number,
  rimColor: number,
  brakeDiscMats: THREE.MeshStandardMaterial[],
): THREE.Group {
  const wheelGroup = new THREE.Group();

  const tireGeo = new THREE.CylinderGeometry(radius, radius, width, 24);
  tireGeo.rotateZ(Math.PI / 2);
  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x14161b,
    roughness: 0.82,
    metalness: 0.08,
  });
  const tire = new THREE.Mesh(tireGeo, tireMat);
  tire.castShadow = true;
  wheelGroup.add(tire);

  const rimGeo = new THREE.CylinderGeometry(radius * 0.65, radius * 0.65, width + 0.02, 16);
  rimGeo.rotateZ(Math.PI / 2);
  const rimMat = new THREE.MeshStandardMaterial({
    color: rimColor,
    roughness: 0.16,
    metalness: 0.94,
  });
  const rim = new THREE.Mesh(rimGeo, rimMat);
  wheelGroup.add(rim);

  // Inner brake rotor that glows orange under heavy braking
  const rotorMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    emissive: 0xff4500,
    emissiveIntensity: 0,
    roughness: 0.35,
    metalness: 0.85,
  });
  brakeDiscMats.push(rotorMat);
  const rotorGeo = new THREE.CylinderGeometry(radius * 0.5, radius * 0.5, width - 0.03, 14);
  rotorGeo.rotateZ(Math.PI / 2);
  wheelGroup.add(new THREE.Mesh(rotorGeo, rotorMat));

  // Caliper accent
  const caliperGeo = new THREE.BoxGeometry(0.08, radius * 0.45, radius * 0.45);
  const caliperMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    roughness: 0.32,
    metalness: 0.45,
  });
  const caliper = new THREE.Mesh(caliperGeo, caliperMat);
  caliper.position.set(0, 0.05, -0.07);
  wheelGroup.add(caliper);

  return wheelGroup;
}

function createSilhouetteExtrude(
  points: Array<[number, number]>,
  width: number,
  bevelSize = 0.08,
): THREE.ExtrudeGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) {
    shape.lineTo(points[i][0], points[i][1]);
  }
  shape.closePath();

  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: width,
    bevelEnabled: true,
    bevelThickness: bevelSize,
    bevelSize,
    bevelSegments: 3,
    curveSegments: 10,
  });
  geo.center();
  geo.rotateY(Math.PI / 2);
  geo.computeVertexNormals();
  return geo;
}

function buildCompactRider(
  jacketColor: number,
  helmetColor: number,
  sportLean: boolean,
): THREE.Group {
  const rider = new THREE.Group();
  const jacketMat = new THREE.MeshStandardMaterial({ color: jacketColor, roughness: 0.65, metalness: 0.1 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
  const helmetMat = new THREE.MeshStandardMaterial({ color: helmetColor, roughness: 0.22, metalness: 0.45 });
  const visorMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.08, metalness: 0.9 });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.52, 0.26), jacketMat);
  torso.position.set(0, 0.3, sportLean ? -0.06 : 0.02);
  torso.rotation.x = sportLean ? -0.45 : -0.14;
  torso.castShadow = true;
  rider.add(torso);

  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), helmetMat);
  helmet.position.set(0, 0.65, sportLean ? -0.18 : -0.02);
  helmet.castShadow = true;
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.1, 0.16), visorMat);
  visor.position.set(0, 0.65, (sportLean ? -0.18 : -0.02) - 0.12);
  rider.add(helmet, visor);

  for (const sx of [-0.21, 0.21]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.48, 0.17), pantsMat);
    leg.position.set(sx, 0.0, -0.05);
    leg.rotation.x = 0.55;
    rider.add(leg);

    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.42, 0.13), jacketMat);
    arm.position.set(sx * 1.05, 0.36, -0.22);
    arm.rotation.x = -0.95;
    rider.add(arm);
  }

  return rider;
}

function buildTwoWheelerRig(
  vehicleId: 'bullet_350' | 'activa_scooter' | 'duke_390',
  paintMaterial: THREE.MeshPhysicalMaterial,
  carbonMat: THREE.MeshStandardMaterial,
  chromeMat: THREE.MeshStandardMaterial,
  headlightMat: THREE.MeshStandardMaterial,
  taillightMat: THREE.MeshStandardMaterial,
  textures: ProceduralTexturePack,
  brakeDiscMats: THREE.MeshStandardMaterial[],
  isSoftwareGl: boolean,
  enableHeadlightSpots: boolean,
): VehicleRig {
  const root = new THREE.Group();
  const isScooter = vehicleId === 'activa_scooter';
  const isDuke = vehicleId === 'duke_390';

  const wheelRadius = isScooter ? 0.24 : 0.34;
  const wheelWidth = isScooter ? 0.14 : 0.16;
  const wheelbaseZ = isScooter ? 0.62 : 0.76;

  // Ground contact shadow
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(1.4, 2.7),
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      depthWrite: false,
      opacity: 0.58,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.025;
  root.add(shadowPlane);

  // Wheels
  const frontPivot = new THREE.Group();
  frontPivot.position.set(0, wheelRadius, -wheelbaseZ);
  const frontWheel = buildWheel(wheelRadius, wheelWidth, isDuke ? 0xf97316 : 0xe2e8f0, brakeDiscMats);
  frontPivot.add(frontWheel);

  // Front fork tubes & fender attached to front steering pivot
  const forkLen = isScooter ? 0.65 : 0.78;
  for (const fx of [-0.11, 0.11]) {
    const fork = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.024, forkLen, 8), chromeMat);
    fork.position.set(fx, forkLen * 0.45, 0.06);
    fork.rotation.x = 0.28;
    frontPivot.add(fork);
  }
  const frontFender = new THREE.Mesh(
    new THREE.CylinderGeometry(wheelRadius + 0.04, wheelRadius + 0.04, wheelWidth + 0.04, 12, 1, true, -Math.PI * 0.4, Math.PI * 0.8),
    paintMaterial,
  );
  frontFender.rotation.z = Math.PI / 2;
  frontPivot.add(frontFender);

  // Handlebars + Grips + Headlamp attached to steering stem
  const barY = isScooter ? 0.78 : 0.82;
  const handlebar = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.76, 8), isDuke ? carbonMat : chromeMat);
  handlebar.rotation.z = Math.PI / 2;
  handlebar.position.set(0, barY, 0.14);
  frontPivot.add(handlebar);

  const headlamp = new THREE.Mesh(
    isDuke ? new THREE.BoxGeometry(0.24, 0.16, 0.16) : new THREE.CylinderGeometry(0.1, 0.1, 0.14, 12),
    headlightMat,
  );
  if (!isDuke) headlamp.rotation.x = Math.PI / 2;
  headlamp.position.set(0, barY - 0.1, 0.04);
  frontPivot.add(headlamp);

  root.add(frontPivot);

  const rearPivot = new THREE.Group();
  rearPivot.position.set(0, wheelRadius, wheelbaseZ);
  const rearWheel = buildWheel(wheelRadius, wheelWidth + 0.03, isDuke ? 0xf97316 : 0xe2e8f0, brakeDiscMats);
  rearPivot.add(rearWheel);
  root.add(rearPivot);

  // Main chassis bodyMesh
  let bodyMesh: THREE.Mesh;
  const leatherMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.72, metalness: 0.08 });

  if (isScooter) {
    // Step-through Indian scooter body
    const floor = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.1, 0.7), carbonMat);
    floor.position.set(0, 0.25, -0.1);
    root.add(floor);

    const apron = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.62, 0.26), paintMaterial);
    apron.position.set(0, 0.56, -0.45);
    apron.rotation.x = -0.22;
    apron.castShadow = true;
    root.add(apron);

    bodyMesh = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.36, 0.92), paintMaterial);
    bodyMesh.position.set(0, 0.52, 0.36);
    bodyMesh.castShadow = true;
    root.add(bodyMesh);

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.12, 0.72), leatherMat);
    seat.position.set(0, 0.74, 0.32);
    root.add(seat);

    const grabRail = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.024, 6, 12, Math.PI), chromeMat);
    grabRail.rotation.x = Math.PI / 2;
    grabRail.position.set(0, 0.78, 0.74);
    root.add(grabRail);
  } else {
    // Motorcycle Frame + Engine + Sculpted Fuel Tank + Exhaust
    const engineBlock = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.36, 0.44), isDuke ? carbonMat : chromeMat);
    engineBlock.position.set(0, 0.46, 0.04);
    engineBlock.castShadow = true;
    root.add(engineBlock);

    if (isDuke) {
      const trellis = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.72), new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.35 }));
      trellis.position.set(0, 0.68, 0.02);
      root.add(trellis);
    }

    // Teardrop or Angular Tank
    bodyMesh = new THREE.Mesh(
      isDuke ? new THREE.BoxGeometry(0.38, 0.28, 0.64) : new THREE.SphereGeometry(0.24, 14, 10),
      paintMaterial,
    );
    if (!isDuke) bodyMesh.scale.set(0.85, 0.75, 1.45);
    bodyMesh.position.set(0, 0.86, -0.18);
    bodyMesh.castShadow = true;
    root.add(bodyMesh);

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.12, 0.68), leatherMat);
    seat.position.set(0, 0.78, 0.36);
    root.add(seat);

    const rearFender = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.1, 0.48), isDuke ? carbonMat : paintMaterial);
    rearFender.position.set(0, 0.72, 0.78);
    rearFender.rotation.x = isDuke ? 0.35 : -0.15;
    root.add(rearFender);
  }

  // Taillight & Exhaust + Nitro Flame
  const taillight = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.09, 0.08), taillightMat);
  taillight.position.set(0, 0.72, wheelbaseZ + 0.18);
  root.add(taillight);

  const exhaust = new THREE.Mesh(
    new THREE.CylinderGeometry(0.045, 0.055, 0.68, 10),
    isDuke ? carbonMat : chromeMat,
  );
  exhaust.rotation.x = Math.PI / 2;
  exhaust.position.set(0.22, 0.34, 0.56);
  root.add(exhaust);

  const nitroFlames: THREE.Mesh[] = [];
  const outerFlameMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.85 });
  const outerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.85, 8), outerFlameMat);
  outerFlame.rotation.x = Math.PI / 2;
  outerFlame.position.set(0.22, 0.34, 1.28);
  outerFlame.visible = false;
  root.add(outerFlame);
  nitroFlames.push(outerFlame);

  const headlightSpots: THREE.SpotLight[] = [];
  if (enableHeadlightSpots && !isSoftwareGl) {
    const spot = new THREE.SpotLight(0xfffbeb, 18, 56, Math.PI / 5, 0.55, 1.5);
    spot.position.set(0, barY, -wheelbaseZ - 0.1);
    spot.target.position.set(0, 0.1, -24);
    root.add(spot, spot.target);
    headlightSpots.push(spot);
  }

  // Seated Helmeted Rider
  const rider = buildCompactRider(
    isDuke ? 0xea580c : isScooter ? 0x0f766e : 0x78350f,
    isDuke ? 0x0f172a : 0xf8fafc,
    isDuke,
  );
  rider.position.set(0, isScooter ? 0.72 : 0.76, isScooter ? 0.24 : 0.28);
  root.add(rider);

  return {
    root,
    bodyMesh,
    paintMaterial,
    frontWheelPivots: [frontPivot],
    wheels: [frontWheel, rearWheel],
    headlightSpots,
    taillightMat,
    brakeDiscMats,
    nitroFlames,
    isTwoWheeler: true,
    wheelRadius,
    setPaintColor: (hex: string) => {
      paintMaterial.color.set(hex);
    },
  };
}

function buildAutoRickshawRig(
  isElectric: boolean,
  paintMaterial: THREE.MeshPhysicalMaterial,
  carbonMat: THREE.MeshStandardMaterial,
  glassMat: THREE.MeshPhysicalMaterial,
  chromeMat: THREE.MeshStandardMaterial,
  headlightMat: THREE.MeshStandardMaterial,
  taillightMat: THREE.MeshStandardMaterial,
  textures: ProceduralTexturePack,
  brakeDiscMats: THREE.MeshStandardMaterial[],
  isSoftwareGl: boolean,
  enableHeadlightSpots: boolean,
): VehicleRig {
  const root = new THREE.Group();
  const wheelRadius = 0.23;

  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(2.2, 3.6),
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.025;
  root.add(shadowPlane);

  const greenBandMat = new THREE.MeshStandardMaterial({
    color: isElectric ? 0x0ea5e9 : 0x15803d,
    roughness: 0.45,
    metalness: 0.25,
  });
  const canopyMat = new THREE.MeshStandardMaterial({
    color: isElectric ? 0xf8fafc : 0x111827,
    roughness: 0.85,
    metalness: 0.05,
  });

  // Lower iconic black & yellow sheetmetal body
  const lowerProfile: Array<[number, number]> = [
    [-1.25, 0.08],
    [-1.18, 0.55],
    [-0.55, 0.82],
    [1.15, 0.82],
    [1.25, 0.25],
    [1.15, 0.08],
  ];
  const bodyGeo = createSilhouetteExtrude(lowerProfile, 1.32, 0.05);
  const bodyMesh = new THREE.Mesh(bodyGeo, paintMaterial);
  bodyMesh.position.y = 0.52;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  root.add(bodyMesh);

  // Green/Yellow mid stripe
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.38, 0.14, 2.42), greenBandMat);
  stripe.position.set(0, 0.44, 0.02);
  root.add(stripe);

  // Windshield & Roof Canopy Pillars
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.12, 0.58, 0.06), glassMat);
  windshield.position.set(0, 1.24, -0.78);
  windshield.rotation.x = 0.22;
  root.add(windshield);

  const canopy = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.72, 1.98, 12, 1, false, -Math.PI / 2, Math.PI), canopyMat);
  canopy.rotation.x = Math.PI / 2;
  canopy.rotation.z = Math.PI / 2;
  canopy.scale.set(1, 1.0, 0.58);
  canopy.position.set(0, 1.56, 0.2);
  canopy.castShadow = true;
  root.add(canopy);

  for (const sx of [-0.62, 0.62]) {
    const frontPost = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.75, 6), chromeMat);
    frontPost.position.set(sx, 1.26, -0.74);
    const rearPost = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.75, 6), canopyMat);
    rearPost.position.set(sx, 1.26, 1.12);
    root.add(frontPost, rearPost);
  }

  // Headlight, Taillights, Exhaust
  const hl = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.1, 12), headlightMat);
  hl.rotation.x = Math.PI / 2;
  hl.position.set(0, 0.62, -1.25);
  root.add(hl);

  for (const sx of [-0.46, 0.46]) {
    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.1, 0.08), taillightMat);
    tl.position.set(sx, 0.56, 1.25);
    root.add(tl);
  }

  const exhaust = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.35, 8), chromeMat);
  exhaust.rotation.x = Math.PI / 2;
  exhaust.position.set(0.3, 0.22, 1.26);
  root.add(exhaust);

  const nitroFlames: THREE.Mesh[] = [];
  const outerFlame = new THREE.Mesh(
    new THREE.ConeGeometry(0.09, 0.75, 8),
    new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.85 }),
  );
  outerFlame.rotation.x = Math.PI / 2;
  outerFlame.position.set(0.3, 0.22, 1.65);
  outerFlame.visible = false;
  root.add(outerFlame);
  nitroFlames.push(outerFlame);

  const headlightSpots: THREE.SpotLight[] = [];
  if (enableHeadlightSpots && !isSoftwareGl) {
    const spot = new THREE.SpotLight(0xfffbeb, 16, 48, Math.PI / 5, 0.55, 1.5);
    spot.position.set(0, 0.62, -1.3);
    spot.target.position.set(0, 0.1, -22);
    root.add(spot, spot.target);
    headlightSpots.push(spot);
  }

  // Wheels: 1 Front + 2 Rear
  const frontPivot = new THREE.Group();
  frontPivot.position.set(0, wheelRadius, -0.95);
  const frontWheel = buildWheel(wheelRadius, 0.18, 0xe2e8f0, brakeDiscMats);
  frontPivot.add(frontWheel);
  root.add(frontPivot);

  const wheels: THREE.Group[] = [frontWheel];
  for (const sx of [-0.64, 0.64]) {
    const rwPivot = new THREE.Group();
    rwPivot.position.set(sx, wheelRadius, 0.86);
    const rw = buildWheel(wheelRadius, 0.2, 0xe2e8f0, brakeDiscMats);
    rwPivot.add(rw);
    root.add(rwPivot);
    wheels.push(rw);
  }

  // Driver silhouette inside cab
  const driver = buildCompactRider(0x94a3b8, 0x1e293b, false);
  driver.scale.setScalar(0.85);
  driver.position.set(0, 0.42, -0.18);
  root.add(driver);

  return {
    root,
    bodyMesh,
    paintMaterial,
    frontWheelPivots: [frontPivot],
    wheels,
    headlightSpots,
    taillightMat,
    brakeDiscMats,
    nitroFlames,
    isTwoWheeler: false,
    wheelRadius,
    setPaintColor: (hex: string) => {
      paintMaterial.color.set(hex);
    },
  };
}

function buildBusOrFireRig(
  kind: 'jaipur_bus' | 'fire_truck',
  paintMaterial: THREE.MeshPhysicalMaterial,
  carbonMat: THREE.MeshStandardMaterial,
  glassMat: THREE.MeshPhysicalMaterial,
  chromeMat: THREE.MeshStandardMaterial,
  headlightMat: THREE.MeshStandardMaterial,
  taillightMat: THREE.MeshStandardMaterial,
  textures: ProceduralTexturePack,
  brakeDiscMats: THREE.MeshStandardMaterial[],
  isSoftwareGl: boolean,
  enableHeadlightSpots: boolean,
): VehicleRig {
  const root = new THREE.Group();
  const isFire = kind === 'fire_truck';
  const wheelRadius = 0.46;
  const bodyLen = isFire ? 7.4 : 8.4;
  const bodyW = 2.28;

  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(4.2, bodyLen + 2.2),
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      depthWrite: false,
      opacity: 0.68,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.025;
  root.add(shadowPlane);

  const whiteTrimMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.35, metalness: 0.2 });
  const yellowAccentMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.4, metalness: 0.25 });

  // Heavy chassis frame
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(bodyW + 0.08, 0.32, bodyLen), carbonMat);
  chassis.position.set(0, 0.48, 0);
  chassis.castShadow = !isSoftwareGl;
  root.add(chassis);

  // Main Bus / Fire Tender body
  const bodyMesh = new THREE.Mesh(
    new THREE.BoxGeometry(bodyW, isFire ? 1.8 : 2.15, isFire ? 2.6 : bodyLen),
    paintMaterial,
  );
  bodyMesh.position.set(0, isFire ? 1.54 : 1.72, isFire ? -2.25 : 0);
  bodyMesh.castShadow = !isSoftwareGl;
  bodyMesh.receiveShadow = true;
  root.add(bodyMesh);

  let policeLightBar: { red: THREE.Mesh; blue: THREE.Mesh } | undefined;

  if (isFire) {
    // Rear water tank compartment + yellow/white hazard stripe + ladder + rooftop water cannon
    const tankBody = new THREE.Mesh(new THREE.BoxGeometry(bodyW + 0.04, 1.9, 4.5), paintMaterial);
    tankBody.position.set(0, 1.62, 1.4);
    tankBody.castShadow = !isSoftwareGl;
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(bodyW + 0.08, 0.28, 7.1), whiteTrimMat);
    stripe.position.set(0, 1.15, 0);
    const frontWin = new THREE.Mesh(new THREE.BoxGeometry(bodyW - 0.16, 0.85, 0.08), glassMat);
    frontWin.position.set(0, 1.95, -3.56);
    const shutterMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.72, roughness: 0.32 });
    for (const sx of [-bodyW / 2 - 0.02, bodyW / 2 + 0.02]) {
      for (const sz of [0.3, 2.3]) {
        const rollDoor = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.15, 1.4), shutterMat);
        rollDoor.position.set(sx, 1.38, sz);
        root.add(rollDoor);
      }
    }
    // Roof Ladder
    for (const lx of [-0.45, 0.45]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 5.0), chromeMat);
      rail.position.set(lx, 2.68, 1.2);
      root.add(rail);
    }
    for (let r = -1.0; r <= 3.4; r += 0.55) {
      const rung = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.06, 0.07), chromeMat);
      rung.position.set(0, 2.68, r);
      root.add(rung);
    }
    // Roof Water Cannon Turret
    const turretBase = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.32, 0.35, 10), chromeMat);
    turretBase.position.set(0, 2.75, -0.4);
    const cannon = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 1.15, 10), chromeMat);
    cannon.rotation.x = Math.PI / 2 - 0.15;
    cannon.position.set(0, 2.98, -0.85);
    root.add(tankBody, stripe, frontWin, turretBase, cannon);

    // Fire Beacon Lightbar
    const redMat = new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff2200, emissiveIntensity: 3.4 });
    const amberMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, emissive: 0xf59e0b, emissiveIntensity: 3.0 });
    const redMesh = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.16, 0.32), redMat);
    redMesh.position.set(-0.52, 2.55, -2.6);
    const blueMesh = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.16, 0.32), amberMat);
    blueMesh.position.set(0.52, 2.55, -2.6);
    root.add(redMesh, blueMesh);
    policeLightBar = { red: redMesh, blue: blueMesh };
  } else {
    // JCTSL City Bus white band, AC roof pods, LED destination header & passenger windows
    const whiteBand = new THREE.Mesh(new THREE.BoxGeometry(bodyW + 0.04, 0.42, bodyLen + 0.04), whiteTrimMat);
    whiteBand.position.set(0, 0.92, 0);
    const acPod = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.28, 3.8), whiteTrimMat);
    acPod.position.set(0, 2.92, 0.2);
    const windScreen = new THREE.Mesh(new THREE.BoxGeometry(bodyW - 0.18, 1.15, 0.08), glassMat);
    windScreen.position.set(0, 1.95, -bodyLen / 2 - 0.02);
    const ledBoard = new THREE.Mesh(
      new THREE.BoxGeometry(1.45, 0.28, 0.08),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xf59e0b, emissiveIntensity: 2.0 }),
    );
    ledBoard.position.set(0, 2.66, -bodyLen / 2 - 0.03);
    root.add(whiteBand, acPod, windScreen, ledBoard);
    for (const sx of [-bodyW / 2 - 0.02, bodyW / 2 + 0.02]) {
      const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.95, bodyLen - 1.1), glassMat);
      sideGlass.position.set(sx, 1.92, 0.1);
      root.add(sideGlass);
    }
  }

  // Headlights & Taillights
  const headlightSpots: THREE.SpotLight[] = [];
  const frontZ = -bodyLen / 2;
  const rearZ = bodyLen / 2;
  for (const sx of [-0.78, 0.78]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.16, 0.1), headlightMat);
    hl.position.set(sx, 0.76, frontZ - 0.02);
    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.18, 0.1), taillightMat);
    tl.position.set(sx, 0.85, rearZ + 0.02);
    root.add(hl, tl);

    if (enableHeadlightSpots && !isSoftwareGl) {
      const spot = new THREE.SpotLight(0xfffbeb, 22, 65, Math.PI / 5, 0.55, 1.5);
      spot.position.set(sx, 0.85, frontZ - 0.05);
      spot.target.position.set(sx * 1.1, 0.1, -28);
      root.add(spot, spot.target);
      headlightSpots.push(spot);
    }
  }

  // Exhaust + Nitro cone
  const nitroFlames: THREE.Mesh[] = [];
  const outerFlame = new THREE.Mesh(
    new THREE.ConeGeometry(0.14, 1.1, 8),
    new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.85 }),
  );
  outerFlame.rotation.x = Math.PI / 2;
  outerFlame.position.set(-0.55, 0.36, rearZ + 0.55);
  outerFlame.visible = false;
  root.add(outerFlame);
  nitroFlames.push(outerFlame);

  // 6 Heavy Wheels (Front Steer + Dual Rear Axles)
  const frontWheelPivots: THREE.Group[] = [];
  const wheels: THREE.Group[] = [];
  const zCoords = [-2.55, 1.25, 2.55];
  for (let idx = 0; idx < zCoords.length; idx++) {
    const wz = zCoords[idx];
    for (const sx of [-1.06, 1.06]) {
      const pivot = new THREE.Group();
      pivot.position.set(sx, wheelRadius, wz);
      const wheelMesh = buildWheel(wheelRadius, 0.34, isFire ? 0xe2e8f0 : 0x94a3b8, brakeDiscMats);
      pivot.add(wheelMesh);
      root.add(pivot);
      wheels.push(wheelMesh);
      if (idx === 0) frontWheelPivots.push(pivot);
    }
  }

  return {
    root,
    bodyMesh,
    paintMaterial,
    frontWheelPivots,
    wheels,
    headlightSpots,
    taillightMat,
    brakeDiscMats,
    nitroFlames,
    policeLightBar,
    isTwoWheeler: false,
    wheelRadius,
    setPaintColor: (hex: string) => {
      paintMaterial.color.set(hex);
    },
  };
}

export function buildVehicleModel(
  vehicleId: VehicleId | 'police',
  paintHex: string,
  textures: ProceduralTexturePack,
  isSoftwareGl: boolean,
  enableHeadlightSpots = false,
): VehicleRig {
  const brakeDiscMats: THREE.MeshStandardMaterial[] = [];

  const isLocalMat =
    vehicleId === 'mumbai_taxi' ||
    vehicleId === 'ambassador_classic' ||
    vehicleId === 'city_sedan' ||
    vehicleId === 'alto_hatch' ||
    vehicleId === 'cargo_van' ||
    vehicleId === 'jaipur_bus' ||
    vehicleId === 'fire_truck' ||
    vehicleId === 'auto_rickshaw' ||
    vehicleId === 'e_rickshaw' ||
    vehicleId === 'activa_scooter';

  const paintMaterial = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(paintHex),
    metalness: isLocalMat ? 0.42 : 0.88,
    roughness: isLocalMat ? 0.34 : 0.18,
    clearcoat: 1.0,
    clearcoatRoughness: 0.06,
    envMapIntensity: 1.55,
  });

  const carbonMat = new THREE.MeshStandardMaterial({
    color: 0x1c222e,
    map: textures.carbonMap,
    roughness: 0.62,
    metalness: 0.24,
  });

  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x0b1324,
    metalness: 0.12,
    roughness: 0.04,
    clearcoat: 1.0,
    transmission: isSoftwareGl ? 0 : 0.5,
    transparent: true,
    opacity: isSoftwareGl ? 0.72 : 0.92,
    ior: 1.52,
  });

  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    metalness: 0.97,
    roughness: 0.12,
  });

  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xe0f2fe,
    emissiveIntensity: 2.6,
    roughness: 0.1,
  });

  const taillightMat = new THREE.MeshStandardMaterial({
    color: 0x991b1b,
    emissive: 0xef4444,
    emissiveIntensity: 2.0,
    roughness: 0.14,
  });

  // Dispatch 2-wheelers, Auto/E-Rickshaws, City Bus & Fire Truck
  if (vehicleId === 'bullet_350' || vehicleId === 'activa_scooter' || vehicleId === 'duke_390') {
    return buildTwoWheelerRig(
      vehicleId,
      paintMaterial,
      carbonMat,
      chromeMat,
      headlightMat,
      taillightMat,
      textures,
      brakeDiscMats,
      isSoftwareGl,
      enableHeadlightSpots,
    );
  }
  if (vehicleId === 'auto_rickshaw' || vehicleId === 'e_rickshaw') {
    return buildAutoRickshawRig(
      vehicleId === 'e_rickshaw',
      paintMaterial,
      carbonMat,
      glassMat,
      chromeMat,
      headlightMat,
      taillightMat,
      textures,
      brakeDiscMats,
      isSoftwareGl,
      enableHeadlightSpots,
    );
  }
  if (vehicleId === 'jaipur_bus' || vehicleId === 'fire_truck') {
    return buildBusOrFireRig(
      vehicleId,
      paintMaterial,
      carbonMat,
      glassMat,
      chromeMat,
      headlightMat,
      taillightMat,
      textures,
      brakeDiscMats,
      isSoftwareGl,
      enableHeadlightSpots,
    );
  }

  const root = new THREE.Group();

  // Soft radial contact shadow plane directly beneath car
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(3.4, 6.0),
    new THREE.MeshBasicMaterial({
      map: textures.contactShadowMap,
      transparent: true,
      depthWrite: false,
      opacity: 0.62,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.025;
  root.add(shadowPlane);

  let profile: Array<[number, number]>;
  let bodyWidth = 1.92;
  let bodyCenterY = 0.62;
  let wheelRadius = 0.36;
  let wheelbaseZ = 1.48;
  let trackX = 0.96;
  let chassisLen = 4.6;

  if (vehicleId === 'lamborghini_svj') {
    profile = [
      [-2.32, 0.14],
      [-2.18, 0.38],
      [-1.08, 0.62],
      [-0.3, 1.04],
      [0.85, 1.02],
      [2.15, 0.68],
      [2.28, 0.24],
    ];
    bodyWidth = 2.02;
    bodyCenterY = 0.58;
  } else if (vehicleId === 'koenigsegg_jesko') {
    profile = [
      [-2.38, 0.12],
      [-2.2, 0.42],
      [-1.02, 0.68],
      [-0.18, 1.06],
      [0.72, 1.04],
      [2.22, 0.64],
      [2.34, 0.2],
    ];
    bodyWidth = 2.0;
    bodyCenterY = 0.58;
  } else if (vehicleId === 'bugatti_chiron') {
    profile = [
      [-2.3, 0.16],
      [-2.16, 0.54],
      [-0.95, 0.78],
      [-0.15, 1.12],
      [0.92, 1.08],
      [2.14, 0.72],
      [2.28, 0.26],
    ];
    bodyWidth = 2.04;
    bodyCenterY = 0.62;
  } else if (vehicleId === 'ambassador_classic') {
    profile = [
      [-2.08, 0.24],
      [-1.98, 0.72],
      [-1.12, 0.84],
      [-0.65, 1.42],
      [0.78, 1.42],
      [1.35, 0.92],
      [2.05, 0.74],
      [2.08, 0.26],
    ];
    bodyWidth = 1.78;
    bodyCenterY = 0.82;
    wheelRadius = 0.33;
    wheelbaseZ = 1.34;
    trackX = 0.88;
    chassisLen = 4.2;
  } else if (vehicleId === 'swift_hatch') {
    profile = [
      [-1.88, 0.2],
      [-1.78, 0.66],
      [-0.98, 0.8],
      [-0.42, 1.34],
      [1.18, 1.34],
      [1.78, 0.8],
      [1.86, 0.22],
    ];
    bodyWidth = 1.76;
    bodyCenterY = 0.76;
    wheelRadius = 0.32;
    wheelbaseZ = 1.24;
    trackX = 0.87;
    chassisLen = 3.8;
  } else if (vehicleId === 'thar_suv') {
    profile = [
      [-2.05, 0.32],
      [-1.95, 0.94],
      [-1.08, 1.02],
      [-0.68, 1.66],
      [1.75, 1.66],
      [1.98, 0.98],
      [2.02, 0.34],
    ];
    bodyWidth = 1.88;
    bodyCenterY = 0.98;
    wheelRadius = 0.42;
    wheelbaseZ = 1.38;
    trackX = 0.94;
    chassisLen = 4.15;
  } else if (vehicleId === 'alto_hatch') {
    profile = [
      [-1.75, 0.2],
      [-1.65, 0.64],
      [-0.9, 0.76],
      [-0.38, 1.3],
      [1.12, 1.3],
      [1.68, 0.78],
      [1.75, 0.22],
    ];
    bodyWidth = 1.68;
    bodyCenterY = 0.74;
    wheelRadius = 0.3;
    wheelbaseZ = 1.18;
    trackX = 0.82;
    chassisLen = 3.55;
  } else if (vehicleId === 'fortuner_suv') {
    profile = [
      [-2.28, 0.3],
      [-2.18, 0.92],
      [-1.12, 1.04],
      [-0.62, 1.66],
      [1.82, 1.66],
      [2.16, 1.02],
      [2.24, 0.32],
    ];
    bodyWidth = 1.94;
    bodyCenterY = 0.96;
    wheelRadius = 0.42;
    wheelbaseZ = 1.48;
    trackX = 0.95;
    chassisLen = 4.65;
  } else if (vehicleId === 'cargo_van') {
    profile = [
      [-2.12, 0.24],
      [-2.05, 0.9],
      [-1.42, 1.56],
      [1.88, 1.58],
      [2.05, 0.85],
      [2.08, 0.24],
    ];
    bodyWidth = 1.84;
    bodyCenterY = 0.94;
    wheelRadius = 0.34;
    wheelbaseZ = 1.42;
    trackX = 0.91;
    chassisLen = 4.3;
  } else if (vehicleId === 'city_sedan' || vehicleId === 'mumbai_taxi' || vehicleId === 'police') {
    profile = [
      [-2.16, 0.22],
      [-2.08, 0.66],
      [-1.18, 0.78],
      [-0.65, 1.32],
      [0.95, 1.32],
      [1.76, 0.82],
      [2.14, 0.66],
      [2.18, 0.24],
    ];
    bodyWidth = 1.84;
    bodyCenterY = 0.78;
    wheelRadius = 0.34;
    wheelbaseZ = 1.38;
    trackX = 0.9;
    chassisLen = 4.35;
  } else {
    profile = [
      [-2.28, 0.14],
      [-2.12, 0.46],
      [-1.0, 0.68],
      [-0.22, 1.06],
      [0.82, 1.04],
      [2.12, 0.68],
      [2.24, 0.22],
    ];
    bodyWidth = 1.96;
    bodyCenterY = 0.6;
  }

  // 1. Primary sculpted hull
  const bodyGeo = createSilhouetteExtrude(profile, bodyWidth, 0.08);
  const bodyMesh = new THREE.Mesh(bodyGeo, paintMaterial);
  bodyMesh.position.y = bodyCenterY;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  root.add(bodyMesh);

  // 2. Carbon lower chassis / front splitter / rear diffuser fins
  const splitter = new THREE.Mesh(
    new THREE.BoxGeometry(bodyWidth + 0.14, 0.1, chassisLen),
    carbonMat,
  );
  splitter.position.set(0, vehicleId === 'thar_suv' || vehicleId === 'fortuner_suv' ? 0.34 : 0.22, 0);
  splitter.castShadow = true;
  root.add(splitter);

  const rearZ = chassisLen * 0.48;
  const frontZ = -chassisLen * 0.48;

  for (const fx of [-0.55, -0.2, 0.2, 0.55]) {
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.2, 0.32), carbonMat);
    fin.position.set(fx, 0.28, rearZ);
    root.add(fin);
  }

  // 3. Sculpted Glass Canopy + Aerodynamic Side Mirrors
  const canopyWidth = bodyWidth * 0.74;
  const isBoxy =
    vehicleId === 'mumbai_taxi' ||
    vehicleId === 'city_sedan' ||
    vehicleId === 'police' ||
    vehicleId === 'ambassador_classic' ||
    vehicleId === 'swift_hatch' ||
    vehicleId === 'alto_hatch' ||
    vehicleId === 'cargo_van' ||
    vehicleId === 'fortuner_suv' ||
    vehicleId === 'thar_suv';
  const canopy = new THREE.Mesh(
    new THREE.BoxGeometry(canopyWidth, 0.42, isBoxy ? 2.05 : 1.75),
    glassMat,
  );
  canopy.position.set(
    0,
    bodyCenterY + (isBoxy ? 0.34 : 0.25),
    vehicleId === 'thar_suv' || vehicleId === 'fortuner_suv' ? 0.22 : -0.05,
  );
  root.add(canopy);

  for (const sx of [-bodyWidth / 2 - 0.12, bodyWidth / 2 + 0.12]) {
    const mirrorArm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.05, 0.07), carbonMat);
    mirrorArm.position.set(sx * 0.92, bodyCenterY + 0.18, -0.55);
    const mirrorCap = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.09, 0.12), paintMaterial);
    mirrorCap.position.set(sx, bodyCenterY + 0.2, -0.55);
    root.add(mirrorArm, mirrorCap);
  }

  // 4. Vehicle-specific iconic aero & styling accents
  if (vehicleId === 'mumbai_taxi') {
    const blackRoof = new THREE.Mesh(new THREE.BoxGeometry(canopyWidth + 0.08, 0.12, 1.85), carbonMat);
    blackRoof.position.set(0, 1.36, 0.08);
    root.add(blackRoof);
    const rack = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.08, 1.15), chromeMat);
    rack.position.set(0, 1.46, 0.15);
    root.add(rack);
  } else if (vehicleId === 'ambassador_classic') {
    const grille = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.34, 0.1), chromeMat);
    grille.position.set(0, 0.62, frontZ - 0.02);
    const fBump = new THREE.Mesh(new THREE.BoxGeometry(bodyWidth + 0.12, 0.12, 0.18), chromeMat);
    fBump.position.set(0, 0.34, frontZ - 0.08);
    const rBump = new THREE.Mesh(new THREE.BoxGeometry(bodyWidth + 0.12, 0.12, 0.18), chromeMat);
    rBump.position.set(0, 0.34, rearZ + 0.08);
    root.add(grille, fBump, rBump);
  } else if (vehicleId === 'swift_hatch') {
    const blackRoof = new THREE.Mesh(new THREE.BoxGeometry(canopyWidth + 0.14, 0.08, 1.8), carbonMat);
    blackRoof.position.set(0, 1.38, 0.18);
    const hatchSpoiler = new THREE.Mesh(new THREE.BoxGeometry(bodyWidth * 0.72, 0.08, 0.28), carbonMat);
    hatchSpoiler.position.set(0, 1.38, 1.48);
    root.add(blackRoof, hatchSpoiler);
  } else if (vehicleId === 'thar_suv') {
    const hardtop = new THREE.Mesh(new THREE.BoxGeometry(bodyWidth * 0.86, 0.62, 1.95), carbonMat);
    hardtop.position.set(0, 1.38, 0.55);
    const grille = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.44, 0.12), carbonMat);
    grille.position.set(0, 0.88, frontZ - 0.03);
    const spareTire = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.24, 16), carbonMat);
    spareTire.rotation.x = Math.PI / 2;
    spareTire.position.set(0, 0.96, rearZ + 0.14);
    root.add(hardtop, grille, spareTire);
  } else if (vehicleId === 'lamborghini_svj' || vehicleId === 'koenigsegg_jesko') {
    const wing = new THREE.Mesh(new THREE.BoxGeometry(bodyWidth + 0.22, 0.07, 0.4), carbonMat);
    wing.position.set(0, 1.2, 2.02);
    wing.rotation.x = 0.12;
    wing.castShadow = true;
    root.add(wing);
    for (const sx of [-0.52, 0.52]) {
      const pylon = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.38, 0.18), carbonMat);
      pylon.position.set(sx, 1.0, 2.0);
      root.add(pylon);
    }
    if (vehicleId === 'koenigsegg_jesko') {
      for (const sx of [-0.74, 0.74]) {
        const fin = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.34, 0.55), paintMaterial);
        fin.position.set(sx, 1.12, 1.98);
        root.add(fin);
      }
    }
  } else if (vehicleId === 'bugatti_chiron') {
    for (const sx of [-bodyWidth / 2 - 0.04, bodyWidth / 2 + 0.04]) {
      const cTrim = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.04, 8, 18, Math.PI), chromeMat);
      cTrim.rotation.y = Math.PI / 2;
      cTrim.rotation.z = sx > 0 ? Math.PI / 2 : -Math.PI / 2;
      cTrim.position.set(sx, 0.68, 0.05);
      root.add(cTrim);
    }
    const grille = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.04, 8, 18), chromeMat);
    grille.position.set(0, 0.44, -2.28);
    root.add(grille);
  } else if (vehicleId === 'ferrari_sf90') {
    for (const sx of [-bodyWidth / 2 - 0.03, bodyWidth / 2 + 0.03]) {
      const intake = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.28, 0.75), carbonMat);
      intake.position.set(sx, 0.58, 0.35);
      root.add(intake);
    }
    const lip = new THREE.Mesh(new THREE.BoxGeometry(bodyWidth - 0.1, 0.08, 0.24), carbonMat);
    lip.position.set(0, 0.92, 2.05);
    root.add(lip);
  }

  let policeLightBar: { red: THREE.Mesh; blue: THREE.Mesh } | undefined;
  if (vehicleId === 'police') {
    const barBase = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.08, 0.24), carbonMat);
    barBase.position.set(0, 1.42, 0.05);
    root.add(barBase);
    const redMat = new THREE.MeshStandardMaterial({
      color: 0xff0000,
      emissive: 0xff1111,
      emissiveIntensity: 3.2,
    });
    const blueMat = new THREE.MeshStandardMaterial({
      color: 0x0066ff,
      emissive: 0x2563eb,
      emissiveIntensity: 3.2,
    });
    const redMesh = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.1, 0.22), redMat);
    redMesh.position.set(-0.28, 1.49, 0.05);
    const blueMesh = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.1, 0.22), blueMat);
    blueMesh.position.set(0.28, 1.49, 0.05);
    root.add(redMesh, blueMesh);
    policeLightBar = { red: redMesh, blue: blueMesh };
  }

  // 5. Headlights & Taillights + SpotLight projection
  const headlightSpots: THREE.SpotLight[] = [];
  const lightY = vehicleId === 'thar_suv' ? 0.86 : 0.52;
  for (const sx of [-0.66, 0.66]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.12), headlightMat);
    hl.position.set(sx, lightY, frontZ);
    root.add(hl);

    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.12, 0.12), taillightMat);
    tl.position.set(sx, lightY + 0.1, rearZ);
    root.add(tl);

    if (enableHeadlightSpots && !isSoftwareGl) {
      const spot = new THREE.SpotLight(0xfffbeb, 20, 62, Math.PI / 5, 0.55, 1.5);
      spot.position.set(sx, lightY + 0.08, frontZ - 0.05);
      spot.target.position.set(sx * 1.1, 0.1, -26);
      root.add(spot);
      root.add(spot.target);
      headlightSpots.push(spot);
    }
  }

  // 6. Dual-Layer Exhaust Pipes & Nitro Plasma Flame Cones
  const nitroFlames: THREE.Mesh[] = [];
  const outerFlameMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.85,
  });
  const innerFlameMat = new THREE.MeshBasicMaterial({
    color: 0xfef08a,
    transparent: true,
    opacity: 0.95,
  });
  for (const sx of [-0.36, 0.36]) {
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.068, 0.078, 0.24, 12), chromeMat);
    pipe.rotation.x = Math.PI / 2;
    pipe.position.set(sx, 0.3, rearZ + 0.05);
    root.add(pipe);

    const outerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.13, 1.1, 10), outerFlameMat);
    outerFlame.rotation.x = Math.PI / 2;
    outerFlame.position.set(sx, 0.3, rearZ + 0.62);
    outerFlame.visible = false;
    const innerFlame = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.65, 8), innerFlameMat);
    innerFlame.position.set(0, -0.15, 0);
    outerFlame.add(innerFlame);

    root.add(outerFlame);
    nitroFlames.push(outerFlame);
  }

  // 7. 4 Rotating & Steering Wheels with Glowing Brake Rotors
  const frontWheelPivots: THREE.Group[] = [];
  const wheels: THREE.Group[] = [];
  const rimColor = vehicleId === 'lamborghini_svj' ? 0xd4af37 : 0xe2e8f0;

  const wheelCoords: Array<{ x: number; z: number; isFront: boolean }> = [
    { x: -trackX, z: -wheelbaseZ, isFront: true },
    { x: trackX, z: -wheelbaseZ, isFront: true },
    { x: -trackX, z: wheelbaseZ, isFront: false },
    { x: trackX, z: wheelbaseZ, isFront: false },
  ];

  for (const wc of wheelCoords) {
    const pivot = new THREE.Group();
    pivot.position.set(wc.x, wheelRadius, wc.z);
    const wheelMesh = buildWheel(wheelRadius, 0.29, rimColor, brakeDiscMats);
    pivot.add(wheelMesh);
    root.add(pivot);
    wheels.push(wheelMesh);
    if (wc.isFront) frontWheelPivots.push(pivot);
  }

  return {
    root,
    bodyMesh,
    paintMaterial,
    frontWheelPivots,
    wheels,
    headlightSpots,
    taillightMat,
    brakeDiscMats,
    nitroFlames,
    policeLightBar,
    isTwoWheeler: false,
    wheelRadius,
    setPaintColor: (hex: string) => {
      paintMaterial.color.set(hex);
    },
  };
}

export function buildPoliceHelicopter(
  textures: ProceduralTexturePack,
  isSoftwareGl: boolean,
): PoliceHelicopterRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const navyMat = new THREE.MeshPhysicalMaterial({
    color: 0x0f172a,
    roughness: 0.25,
    metalness: 0.5,
    clearcoat: 0.9,
  });
  const whiteMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.3,
    metalness: 0.2,
  });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x1e293b,
    roughness: 0.08,
    metalness: 0.15,
    transparent: true,
    opacity: 0.72,
    envMapIntensity: 1.8,
  });
  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    roughness: 0.35,
    metalness: 0.85,
  });
  const redMat = new THREE.MeshStandardMaterial({
    color: 0xff1111,
    emissive: 0xff1111,
    emissiveIntensity: 4.0,
  });
  const blueMat = new THREE.MeshStandardMaterial({
    color: 0x2563eb,
    emissive: 0x3b82f6,
    emissiveIntensity: 4.0,
  });

  // Main fuselage pod & white police belly stripe
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1.85, 4.4), navyMat);
  cabin.position.set(0, 0.9, 0.2);
  cabin.castShadow = !isSoftwareGl;
  bodyGroup.add(cabin);

  const whiteStripe = new THREE.Mesh(new THREE.BoxGeometry(2.36, 0.48, 3.8), whiteMat);
  whiteStripe.position.set(0, 0.55, 0.2);
  bodyGroup.add(whiteStripe);

  // Sloped nose & cockpit canopy
  const nose = new THREE.Mesh(new THREE.BoxGeometry(2.05, 1.4, 1.9), glassMat);
  nose.position.set(0, 0.95, -2.15);
  nose.rotation.x = 0.26;
  bodyGroup.add(nose);

  const chinTurret = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 8), metalMat);
  chinTurret.position.set(0, 0.08, -2.55);
  bodyGroup.add(chinTurret);

  // Engine cowling on top
  const cowling = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.72, 2.8), navyMat);
  cowling.position.set(0, 2.05, 0.45);
  bodyGroup.add(cowling);

  // Side police decals
  const decalMat = new THREE.MeshStandardMaterial({
    map: textures.policeStationSign,
    roughness: 0.4,
  });
  for (const sx of [-1.19, 1.19]) {
    const decal = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.8), decalMat);
    decal.position.set(sx, 1.05, 0.3);
    decal.rotation.y = sx > 0 ? Math.PI / 2 : -Math.PI / 2;
    bodyGroup.add(decal);
  }

  // Tail boom + vertical & horizontal stabilizers
  const tailBoom = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.42, 5.4, 10), navyMat);
  tailBoom.rotation.x = Math.PI / 2;
  tailBoom.position.set(0, 1.25, 4.6);
  tailBoom.castShadow = !isSoftwareGl;
  bodyGroup.add(tailBoom);

  const vFin = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.55, 1.05), whiteMat);
  vFin.position.set(0, 1.85, 7.05);
  vFin.rotation.x = -0.25;
  bodyGroup.add(vFin);

  const hStab = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.12, 0.65), whiteMat);
  hStab.position.set(0, 1.25, 6.2);
  bodyGroup.add(hStab);

  // Landing skids
  for (const sx of [-1.15, 1.15]) {
    const skid = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 4.8, 8), metalMat);
    skid.rotation.x = Math.PI / 2;
    skid.position.set(sx, -0.55, -0.1);
    bodyGroup.add(skid);

    for (const sz of [-1.2, 1.1]) {
      const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.95, 6), metalMat);
      strut.position.set(sx * 0.85, -0.15, sz);
      strut.rotation.z = sx > 0 ? -0.35 : 0.35;
      bodyGroup.add(strut);
    }
  }

  // Flashing red & blue strobe beacons under belly & on tail
  const redLight = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 8), redMat);
  redLight.position.set(-0.65, -0.05, 0.6);
  const blueLight = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 8), blueMat);
  blueLight.position.set(0.65, -0.05, 0.6);
  const tailBeacon = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 8), redMat);
  tailBeacon.position.set(0, 2.68, 7.2);
  bodyGroup.add(redLight, blueLight, tailBeacon);

  // 4-Blade Main Rotor
  const mainRotor = new THREE.Group();
  mainRotor.position.set(0, 2.65, 0.2);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.25, 0.45, 10), metalMat);
  mainRotor.add(hub);
  const bladeMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4, metalness: 0.4 });
  for (let b = 0; b < 4; b++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.05, 5.2), bladeMat);
    blade.rotation.y = (b * Math.PI) / 2;
    blade.position.set(Math.sin(blade.rotation.y) * 2.55, 0.08, Math.cos(blade.rotation.y) * 2.55);
    mainRotor.add(blade);
  }
  bodyGroup.add(mainRotor);

  // Tail Rotor
  const tailRotor = new THREE.Group();
  tailRotor.position.set(0.28, 1.82, 7.25);
  for (let b = 0; b < 2; b++) {
    const tBlade = new THREE.Mesh(new THREE.BoxGeometry(0.05, 1.6, 0.16), bladeMat);
    tBlade.rotation.x = (b * Math.PI) / 2;
    tailRotor.add(tBlade);
  }
  bodyGroup.add(tailRotor);

  // Volumetric Searchlight Cone & Ground Spotlight Disc
  const searchBeam = new THREE.Mesh(
    new THREE.ConeGeometry(7.2, 46, 18, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0xfef08a,
      transparent: true,
      opacity: 0.14,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  searchBeam.position.set(0, -23, -2.5);
  bodyGroup.add(searchBeam);

  const groundSpot = new THREE.Mesh(
    new THREE.CircleGeometry(6.5, 24),
    new THREE.MeshBasicMaterial({
      color: 0xfef9c3,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
    }),
  );
  groundSpot.rotation.x = -Math.PI / 2;
  groundSpot.visible = false;

  return {
    root,
    bodyGroup,
    mainRotor,
    tailRotor,
    redMat,
    blueMat,
    searchBeam,
    groundSpot,
  };
}

export interface AircraftRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  landingGear: THREE.Group;
  afterburners: THREE.Mesh[];
  turbineFans: THREE.Mesh[];
}

export function buildJetAircraft(
  accentHex = '#0284c7',
  isSoftwareGl = false,
): AircraftRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const hullMat = new THREE.MeshPhysicalMaterial({
    color: 0xf8fafc,
    roughness: 0.22,
    metalness: 0.35,
    clearcoat: 0.9,
  });
  const accentMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(accentHex),
    roughness: 0.25,
    metalness: 0.55,
    clearcoat: 0.85,
  });
  const darkMetalMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.4,
    metalness: 0.8,
  });
  const canopyMat = new THREE.MeshPhysicalMaterial({
    color: 0x0f172a,
    roughness: 0.08,
    metalness: 0.2,
    transparent: true,
    opacity: 0.78,
  });

  // 1. Sleek Main Fuselage (forward along -Z)
  const fuselage = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.05, 11.5, 16), hullMat);
  fuselage.rotation.x = Math.PI / 2;
  fuselage.position.set(0, 1.75, 0);
  fuselage.castShadow = !isSoftwareGl;
  bodyGroup.add(fuselage);

  // Tapered Nose Cone
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.95, 3.6, 16), accentMat);
  nose.rotation.x = -Math.PI / 2;
  nose.position.set(0, 1.75, -7.55);
  nose.castShadow = !isSoftwareGl;
  bodyGroup.add(nose);

  // Tail Cone
  const tailCone = new THREE.Mesh(new THREE.ConeGeometry(1.05, 2.8, 16), accentMat);
  tailCone.rotation.x = Math.PI / 2;
  tailCone.position.set(0, 1.75, 7.15);
  bodyGroup.add(tailCone);

  // Cheatline Accent Stripe along Cabin
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.14, 0.28, 10.6), accentMat);
  stripe.position.set(0, 1.75, -0.2);
  bodyGroup.add(stripe);

  // 2. Tinted Cockpit Canopy
  const cockpit = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.75, 2.8), canopyMat);
  cockpit.position.set(0, 2.45, -4.6);
  cockpit.rotation.x = 0.14;
  bodyGroup.add(cockpit);

  // 3. Swept Extruded Delta Wings (Port & Starboard)
  const makeWing = (side: -1 | 1) => {
    const shape = new THREE.Shape();
    shape.moveTo(0, -1.6);
    shape.lineTo(side * 8.4, 2.4);
    shape.lineTo(side * 8.4, 3.6);
    shape.lineTo(0, 1.9);
    shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, { depth: 0.18, bevelEnabled: false });
    geo.rotateX(Math.PI / 2);
    const mesh = new THREE.Mesh(geo, hullMat);
    mesh.position.set(side * 0.85, 1.62, 0.2);
    mesh.castShadow = !isSoftwareGl;
    bodyGroup.add(mesh);

    // Wingtip Winglet + Nav Light (Red Port, Green Starboard)
    const winglet = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.05, 1.1), accentMat);
    winglet.position.set(side * 9.25, 2.1, 3.0);
    winglet.rotation.z = side * -0.22;
    bodyGroup.add(winglet);

    const navMat = new THREE.MeshStandardMaterial({
      color: side < 0 ? 0xef4444 : 0x10b981,
      emissive: side < 0 ? 0xef4444 : 0x10b981,
      emissiveIntensity: 3.0,
    });
    const navLight = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 8), navMat);
    navLight.position.set(side * 9.3, 2.62, 3.0);
    bodyGroup.add(navLight);
  };
  makeWing(-1);
  makeWing(1);

  // 4. Vertical Tail Fin & T-Tail Horizontal Stabilizer
  const vFin = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.9, 2.6), accentMat);
  vFin.position.set(0, 3.5, 5.4);
  vFin.rotation.x = 0.28;
  vFin.castShadow = !isSoftwareGl;
  const hStab = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.16, 1.35), hullMat);
  hStab.position.set(0, 4.7, 6.0);
  bodyGroup.add(vFin, hStab);

  // 5. Twin Rear-Mounted Turbofan Engines + Fans + Afterburners
  const afterburners: THREE.Mesh[] = [];
  const turbineFans: THREE.Mesh[] = [];
  const flameMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.85,
  });

  for (const sx of [-1.65, 1.65]) {
    const pylon = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.22, 1.4), darkMetalMat);
    pylon.position.set(sx * 0.65, 2.15, 3.6);
    const nacelle = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.44, 2.9, 14), darkMetalMat);
    nacelle.rotation.x = Math.PI / 2;
    nacelle.position.set(sx, 2.2, 3.7);
    const fan = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.12, 12), hullMat);
    fan.rotation.x = Math.PI / 2;
    fan.position.set(sx, 2.2, 2.3);
    turbineFans.push(fan);

    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.36, 2.4, 12), flameMat);
    flame.rotation.x = Math.PI / 2;
    flame.position.set(sx, 2.2, 6.3);
    flame.visible = false;
    afterburners.push(flame);

    bodyGroup.add(pylon, nacelle, fan, flame);
  }

  // 6. Retractable Tricycle Landing Gear
  const landingGear = new THREE.Group();
  const gearCoords: Array<[number, number]> = [
    [0, -4.8],
    [-1.6, 1.2],
    [1.6, 1.2],
  ];
  for (const [gx, gz] of gearCoords) {
    const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.95, 8), darkMetalMat);
    strut.position.set(gx, 0.55, gz);
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.2, 12), darkMetalMat);
    tire.rotation.z = Math.PI / 2;
    tire.position.set(gx, 0.28, gz);
    landingGear.add(strut, tire);
  }
  bodyGroup.add(landingGear);

  return {
    root,
    bodyGroup,
    landingGear,
    afterburners,
    turbineFans,
  };
}

export function buildMetroTrain(): THREE.Group {
  const train = new THREE.Group();
  const hullMat = new THREE.MeshPhysicalMaterial({ color: 0xf1f5f9, roughness: 0.25, metalness: 0.45, clearcoat: 0.8 });
  const pinkStripeMat = new THREE.MeshStandardMaterial({
    color: 0xdb2777,
    emissive: 0xec4899,
    emissiveIntensity: 0.55,
    roughness: 0.35,
  });
  const winMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.15, metalness: 0.75 });
  const headMat = new THREE.MeshStandardMaterial({ color: 0xfef9c3, emissive: 0xfef08a, emissiveIntensity: 2.8 });

  // 4 articulated Metro coaches running along X axis
  for (let c = 0; c < 4; c++) {
    const cx = (c - 1.5) * 14.5;
    const coach = new THREE.Mesh(new THREE.BoxGeometry(13.6, 3.1, 2.75), hullMat);
    coach.position.set(cx, 1.85, 0);
    const band = new THREE.Mesh(new THREE.BoxGeometry(13.7, 0.42, 2.82), pinkStripeMat);
    band.position.set(cx, 1.1, 0);
    const windows = new THREE.Mesh(new THREE.BoxGeometry(12.2, 0.92, 2.8), winMat);
    windows.position.set(cx, 2.15, 0);
    train.add(coach, band, windows);
  }
  const hlFront = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.45, 1.8), headMat);
  hlFront.position.set(28.65, 1.15, 0);
  const hlBack = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.45, 1.8), headMat);
  hlBack.position.set(-28.65, 1.15, 0);
  train.add(hlFront, hlBack);
  return train;
}

export function buildIndianExpressTrain(): THREE.Group {
  const train = new THREE.Group();
  const locoMat = new THREE.MeshPhysicalMaterial({ color: 0xea580c, roughness: 0.35, metalness: 0.35 });
  const creamMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
  const coachRedMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.4 });
  const coachBlueMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.42 });
  const winMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2, metalness: 0.7 });
  const headMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfacc15, emissiveIntensity: 3.0 });

  // WAP-7 Electric Locomotive at +X nose
  const loco = new THREE.Mesh(new THREE.BoxGeometry(16, 3.6, 3.1), locoMat);
  loco.position.set(28, 2.2, 0);
  const locoStripe = new THREE.Mesh(new THREE.BoxGeometry(16.1, 0.65, 3.16), creamMat);
  locoStripe.position.set(28, 2.1, 0);
  const panto = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.9, 1.4), winMat);
  panto.position.set(28, 4.45, 0);
  const beam = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.5, 1.6), headMat);
  beam.position.set(36.1, 1.6, 0);
  train.add(loco, locoStripe, panto, beam);

  // 4 LHB Coaches
  for (let c = 0; c < 4; c++) {
    const cx = 10 - c * 17.5;
    const mat = c % 2 === 0 ? coachRedMat : coachBlueMat;
    const car = new THREE.Mesh(new THREE.BoxGeometry(16.2, 3.4, 3.05), mat);
    car.position.set(cx, 2.1, 0);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(16.3, 0.45, 2.95), creamMat);
    roof.position.set(cx, 3.9, 0);
    const win = new THREE.Mesh(new THREE.BoxGeometry(14.6, 0.85, 3.1), winMat);
    win.position.set(cx, 2.4, 0);
    train.add(car, roof, win);
  }
  return train;
}



