import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  DEFAULT_CHARACTER_CONFIG,
  DEFAULT_SAVE_DATA,
  type LeaderboardEntry,
  type PlayerSaveData,
} from '../types/game';

const LOCAL_SAVE_KEY = 'bharat_turbo_save_v1';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection on boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
void testConnection();

export function loadLocalSave(): PlayerSaveData {
  try {
    const raw = localStorage.getItem(LOCAL_SAVE_KEY);
    if (!raw) return { ...DEFAULT_SAVE_DATA, characterConfig: { ...DEFAULT_CHARACTER_CONFIG } };
    const parsed = JSON.parse(raw) as Partial<PlayerSaveData>;
    return {
      ...DEFAULT_SAVE_DATA,
      ...parsed,
      characterConfig: {
        ...DEFAULT_CHARACTER_CONFIG,
        ...(parsed.characterConfig || {}),
      },
      unlockedVehicles: Array.isArray(parsed.unlockedVehicles) && parsed.unlockedVehicles.length > 0
        ? parsed.unlockedVehicles
        : DEFAULT_SAVE_DATA.unlockedVehicles,
      unlockedWeapons: Array.isArray(parsed.unlockedWeapons) && parsed.unlockedWeapons.length > 0
        ? parsed.unlockedWeapons
        : DEFAULT_SAVE_DATA.unlockedWeapons,
      selectedWeapon: parsed.selectedWeapon || DEFAULT_SAVE_DATA.selectedWeapon,
      completedMissions: Array.isArray(parsed.completedMissions)
        ? parsed.completedMissions
        : [],
      bankBalance: typeof parsed.bankBalance === 'number' ? parsed.bankBalance : DEFAULT_SAVE_DATA.bankBalance,
      maxHealth: typeof parsed.maxHealth === 'number' ? Math.max(100, Math.min(200, parsed.maxHealth)) : DEFAULT_SAVE_DATA.maxHealth,
      homeLevel: typeof parsed.homeLevel === 'number' ? Math.max(1, Math.min(3, Math.floor(parsed.homeLevel))) : DEFAULT_SAVE_DATA.homeLevel,
    };
  } catch {
    return { ...DEFAULT_SAVE_DATA, characterConfig: { ...DEFAULT_CHARACTER_CONFIG } };
  }
}

export function saveLocal(data: PlayerSaveData): void {
  try {
    localStorage.setItem(LOCAL_SAVE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors
  }
}

function sanitizeForFirestore(userId: string, data: PlayerSaveData) {
  const safeHex = (val: string, fallback: string) =>
    /^#[0-9a-fA-F]{6}$/.test(val) ? val : fallback;

  return {
    userId,
    displayName: (data.displayName || 'Jaipur Driver').trim().slice(0, 48) || 'Jaipur Driver',
    cash: Math.max(0, Math.min(999999999, Math.floor(data.cash || 0))),
    bankBalance: Math.max(0, Math.min(999999999, Math.floor(data.bankBalance ?? DEFAULT_SAVE_DATA.bankBalance))),
    maxHealth: Math.max(100, Math.min(200, Math.floor(data.maxHealth || 100))),
    homeLevel: Math.max(1, Math.min(3, Math.floor(data.homeLevel || 1))),
    reputation: Math.max(0, Math.min(999999999, Math.floor(data.reputation || 0))),
    selectedVehicle: data.selectedVehicle,
    vehicleColor: safeHex(data.vehicleColor, '#d91616'),
    selectedWeapon: data.selectedWeapon || 'pistol',
    unlockedWeapons: Array.from(new Set(data.unlockedWeapons?.length ? data.unlockedWeapons : DEFAULT_SAVE_DATA.unlockedWeapons)).slice(0, 10),
    characterConfig: {
      archetype: data.characterConfig.archetype,
      outfitColor: safeHex(data.characterConfig.outfitColor, '#f59e0b'),
      skinTone: safeHex(data.characterConfig.skinTone, '#c68642'),
      headgear: data.characterConfig.headgear,
      eyewear: data.characterConfig.eyewear,
    },
    unlockedVehicles: Array.from(new Set(data.unlockedVehicles)).slice(0, 20),
    completedMissions: Array.from(new Set(data.completedMissions)).slice(0, 20),
    destructiblesSmashed: Math.max(0, Math.min(10000000, Math.floor(data.destructiblesSmashed || 0))),
    topSpeedKmh: Math.max(0, Math.min(1200, Math.round(data.topSpeedKmh || 0))),
    lastDistrict: data.lastDistrict,
    weatherPref: data.weatherPref,
    graphicsPreset: data.graphicsPreset,
  };
}

export async function signInWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function signOutAccount(): Promise<void> {
  await signOut(auth);
}

export function subscribeAuth(cb: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, cb);
}

export async function loadCloudSave(user: User): Promise<PlayerSaveData> {
  const path = `saves/${user.uid}`;
  try {
    const snap = await getDoc(doc(db, 'saves', user.uid));
    if (snap.exists()) {
      const cloud = snap.data() as PlayerSaveData;
      const merged: PlayerSaveData = {
        ...DEFAULT_SAVE_DATA,
        ...cloud,
        userId: user.uid,
        unlockedWeapons: Array.isArray(cloud.unlockedWeapons) && cloud.unlockedWeapons.length > 0
          ? cloud.unlockedWeapons
          : DEFAULT_SAVE_DATA.unlockedWeapons,
        selectedWeapon: cloud.selectedWeapon || DEFAULT_SAVE_DATA.selectedWeapon,
        bankBalance: typeof cloud.bankBalance === 'number' ? cloud.bankBalance : DEFAULT_SAVE_DATA.bankBalance,
        maxHealth: typeof cloud.maxHealth === 'number' ? Math.max(100, Math.min(200, cloud.maxHealth)) : DEFAULT_SAVE_DATA.maxHealth,
        homeLevel: typeof cloud.homeLevel === 'number' ? Math.max(1, Math.min(3, Math.floor(cloud.homeLevel))) : DEFAULT_SAVE_DATA.homeLevel,
        characterConfig: {
          ...DEFAULT_CHARACTER_CONFIG,
          ...(cloud.characterConfig || {}),
        },
      };
      saveLocal(merged);
      return merged;
    }
    // Bootstrap cloud save from local progress if first login
    const local = loadLocalSave();
    const initial: PlayerSaveData = {
      ...local,
      userId: user.uid,
      displayName: local.displayName === 'Mumbai Driver' && user.displayName
        ? user.displayName.slice(0, 48)
        : local.displayName,
    };
    await saveCloudProgress(user, initial, true);
    return initial;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveCloudProgress(
  user: User,
  data: PlayerSaveData,
  isCreate = false,
): Promise<void> {
  saveLocal(data);
  if (!user.emailVerified) return;

  const savePath = `saves/${user.uid}`;
  const clean = sanitizeForFirestore(user.uid, data);

  try {
    const ref = doc(db, 'saves', user.uid);
    const existingSnap = isCreate ? null : await getDoc(ref);
    if (!existingSnap || !existingSnap.exists()) {
      await setDoc(ref, {
        ...clean,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(
        ref,
        {
          ...clean,
          createdAt: existingSnap.data().createdAt,
          updatedAt: serverTimestamp(),
        },
        { merge: false },
      );
    }
  } catch (error) {
    handleFirestoreError(error, isCreate ? OperationType.CREATE : OperationType.UPDATE, savePath);
  }

  const lbPath = `leaderboard/${user.uid}`;
  try {
    await setDoc(doc(db, 'leaderboard', user.uid), {
      userId: user.uid,
      displayName: clean.displayName,
      reputation: clean.reputation,
      topSpeedKmh: clean.topSpeedKmh,
      destructiblesSmashed: clean.destructiblesSmashed,
      selectedVehicle: clean.selectedVehicle,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, lbPath);
  }
}

export async function fetchLeaderboard(): Promise<LeaderboardEntry[]> {
  if (!auth.currentUser) return [];
  const path = 'leaderboard';
  try {
    const q = query(
      collection(db, 'leaderboard'),
      orderBy('reputation', 'desc'),
      limit(12),
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as LeaderboardEntry);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}
