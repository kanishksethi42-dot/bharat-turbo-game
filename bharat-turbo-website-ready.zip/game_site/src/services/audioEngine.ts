import type { VehicleId } from '../types/game';

interface VehicleSoundProfile {
  wave1: OscillatorType;
  wave2: OscillatorType;
  wave3: OscillatorType;
  baseHz: number;
  maxHz: number;
  ratio2: number;
  ratio3: number;
  cutoffMin: number;
  cutoffMax: number;
  q: number;
  gain: number;
  thumpHz?: number;
  thumpDepth?: number;
  hornFreqs: number[];
  hornWave: OscillatorType;
  hornDur: number;
}

const VEHICLE_SOUND_PROFILES: Record<VehicleId | 'aircraft', VehicleSoundProfile> = {
  ferrari_sf90: {
    wave1: 'sawtooth',
    wave2: 'triangle',
    wave3: 'sawtooth',
    baseHz: 78,
    maxHz: 255,
    ratio2: 1.99,
    ratio3: 3.01,
    cutoffMin: 520,
    cutoffMax: 2400,
    q: 2.8,
    gain: 0.16,
    hornFreqs: [440, 554.37],
    hornWave: 'sawtooth',
    hornDur: 0.24,
  },
  lamborghini_svj: {
    wave1: 'sawtooth',
    wave2: 'sawtooth',
    wave3: 'triangle',
    baseHz: 84,
    maxHz: 280,
    ratio2: 1.5,
    ratio3: 2.98,
    cutoffMin: 600,
    cutoffMax: 2650,
    q: 3.4,
    gain: 0.17,
    hornFreqs: [466.16, 587.33],
    hornWave: 'sawtooth',
    hornDur: 0.26,
  },
  koenigsegg_jesko: {
    wave1: 'sawtooth',
    wave2: 'square',
    wave3: 'triangle',
    baseHz: 72,
    maxHz: 270,
    ratio2: 2.02,
    ratio3: 4.0,
    cutoffMin: 560,
    cutoffMax: 2800,
    q: 3.0,
    gain: 0.16,
    hornFreqs: [523.25, 659.25],
    hornWave: 'triangle',
    hornDur: 0.25,
  },
  bugatti_chiron: {
    wave1: 'sawtooth',
    wave2: 'triangle',
    wave3: 'sine',
    baseHz: 46,
    maxHz: 185,
    ratio2: 1.498,
    ratio3: 2.5,
    cutoffMin: 340,
    cutoffMax: 1650,
    q: 2.0,
    gain: 0.19,
    hornFreqs: [349.23, 440],
    hornWave: 'sawtooth',
    hornDur: 0.3,
  },
  mumbai_taxi: {
    wave1: 'triangle',
    wave2: 'sawtooth',
    wave3: 'sine',
    baseHz: 44,
    maxHz: 118,
    ratio2: 1.97,
    ratio3: 0.5,
    cutoffMin: 320,
    cutoffMax: 920,
    q: 1.8,
    gain: 0.15,
    thumpHz: 14,
    thumpDepth: 0.14,
    hornFreqs: [392, 493.88],
    hornWave: 'square',
    hornDur: 0.22,
  },
  ambassador_classic: {
    wave1: 'triangle',
    wave2: 'square',
    wave3: 'sine',
    baseHz: 38,
    maxHz: 102,
    ratio2: 1.52,
    ratio3: 0.5,
    cutoffMin: 260,
    cutoffMax: 780,
    q: 2.4,
    gain: 0.16,
    thumpHz: 11,
    thumpDepth: 0.18,
    hornFreqs: [277.18, 349.23],
    hornWave: 'sawtooth',
    hornDur: 0.34,
  },
  swift_hatch: {
    wave1: 'triangle',
    wave2: 'sawtooth',
    wave3: 'sine',
    baseHz: 52,
    maxHz: 152,
    ratio2: 2.0,
    ratio3: 3.0,
    cutoffMin: 400,
    cutoffMax: 1280,
    q: 1.4,
    gain: 0.14,
    hornFreqs: [415.3, 523.25],
    hornWave: 'triangle',
    hornDur: 0.2,
  },
  thar_suv: {
    wave1: 'sawtooth',
    wave2: 'square',
    wave3: 'sine',
    baseHz: 36,
    maxHz: 108,
    ratio2: 0.5,
    ratio3: 1.48,
    cutoffMin: 240,
    cutoffMax: 840,
    q: 2.6,
    gain: 0.18,
    thumpHz: 15,
    thumpDepth: 0.16,
    hornFreqs: [246.94, 311.13],
    hornWave: 'sawtooth',
    hornDur: 0.36,
  },
  auto_rickshaw: {
    wave1: 'square',
    wave2: 'sawtooth',
    wave3: 'triangle',
    baseHz: 62,
    maxHz: 162,
    ratio2: 1.33,
    ratio3: 2.66,
    cutoffMin: 460,
    cutoffMax: 1520,
    q: 4.2,
    gain: 0.13,
    thumpHz: 22,
    thumpDepth: 0.26,
    hornFreqs: [659.25, 676],
    hornWave: 'square',
    hornDur: 0.16,
  },
  bullet_350: {
    wave1: 'triangle',
    wave2: 'sawtooth',
    wave3: 'sine',
    baseHz: 32,
    maxHz: 86,
    ratio2: 1.98,
    ratio3: 0.5,
    cutoffMin: 210,
    cutoffMax: 680,
    q: 3.2,
    gain: 0.21,
    thumpHz: 9,
    thumpDepth: 0.42,
    hornFreqs: [329.63, 415.3],
    hornWave: 'sawtooth',
    hornDur: 0.28,
  },
  activa_scooter: {
    wave1: 'sine',
    wave2: 'triangle',
    wave3: 'sawtooth',
    baseHz: 68,
    maxHz: 165,
    ratio2: 2.01,
    ratio3: 3.02,
    cutoffMin: 420,
    cutoffMax: 1200,
    q: 1.2,
    gain: 0.11,
    hornFreqs: [587.33],
    hornWave: 'square',
    hornDur: 0.15,
  },
  duke_390: {
    wave1: 'sawtooth',
    wave2: 'square',
    wave3: 'triangle',
    baseHz: 66,
    maxHz: 225,
    ratio2: 1.5,
    ratio3: 2.99,
    cutoffMin: 520,
    cutoffMax: 2150,
    q: 3.6,
    gain: 0.15,
    thumpHz: 20,
    thumpDepth: 0.12,
    hornFreqs: [493.88, 622.25],
    hornWave: 'sawtooth',
    hornDur: 0.2,
  },
  city_sedan: {
    wave1: 'triangle',
    wave2: 'sine',
    wave3: 'sawtooth',
    baseHz: 48,
    maxHz: 148,
    ratio2: 2.0,
    ratio3: 1.5,
    cutoffMin: 360,
    cutoffMax: 1220,
    q: 1.5,
    gain: 0.14,
    hornFreqs: [415.3, 523.25],
    hornWave: 'triangle',
    hornDur: 0.22,
  },
  fortuner_suv: {
    wave1: 'sawtooth',
    wave2: 'triangle',
    wave3: 'sine',
    baseHz: 34,
    maxHz: 104,
    ratio2: 0.5,
    ratio3: 1.5,
    cutoffMin: 240,
    cutoffMax: 820,
    q: 2.4,
    gain: 0.18,
    thumpHz: 13,
    thumpDepth: 0.15,
    hornFreqs: [261.63, 329.63],
    hornWave: 'sawtooth',
    hornDur: 0.34,
  },
  alto_hatch: {
    wave1: 'triangle',
    wave2: 'sawtooth',
    wave3: 'sine',
    baseHz: 56,
    maxHz: 158,
    ratio2: 2.01,
    ratio3: 3.0,
    cutoffMin: 420,
    cutoffMax: 1350,
    q: 1.3,
    gain: 0.12,
    hornFreqs: [493.88],
    hornWave: 'square',
    hornDur: 0.16,
  },
  jaipur_bus: {
    wave1: 'sawtooth',
    wave2: 'square',
    wave3: 'sine',
    baseHz: 28,
    maxHz: 78,
    ratio2: 0.5,
    ratio3: 1.48,
    cutoffMin: 180,
    cutoffMax: 620,
    q: 2.2,
    gain: 0.2,
    thumpHz: 10,
    thumpDepth: 0.22,
    hornFreqs: [196, 246.94],
    hornWave: 'sawtooth',
    hornDur: 0.45,
  },
  cargo_van: {
    wave1: 'triangle',
    wave2: 'sawtooth',
    wave3: 'sine',
    baseHz: 38,
    maxHz: 106,
    ratio2: 1.49,
    ratio3: 0.5,
    cutoffMin: 250,
    cutoffMax: 800,
    q: 2.0,
    gain: 0.16,
    thumpHz: 14,
    thumpDepth: 0.14,
    hornFreqs: [311.13, 392],
    hornWave: 'square',
    hornDur: 0.25,
  },
  fire_truck: {
    wave1: 'sawtooth',
    wave2: 'square',
    wave3: 'sine',
    baseHz: 30,
    maxHz: 86,
    ratio2: 0.5,
    ratio3: 1.5,
    cutoffMin: 200,
    cutoffMax: 720,
    q: 2.5,
    gain: 0.21,
    thumpHz: 11,
    thumpDepth: 0.2,
    hornFreqs: [220, 277.18],
    hornWave: 'sawtooth',
    hornDur: 0.48,
  },
  e_rickshaw: {
    wave1: 'sine',
    wave2: 'triangle',
    wave3: 'sine',
    baseHz: 120,
    maxHz: 340,
    ratio2: 2.0,
    ratio3: 3.0,
    cutoffMin: 600,
    cutoffMax: 2100,
    q: 1.1,
    gain: 0.08,
    hornFreqs: [783.99, 1046.5],
    hornWave: 'sine',
    hornDur: 0.14,
  },
  aircraft: {
    wave1: 'sawtooth',
    wave2: 'sine',
    wave3: 'triangle',
    baseHz: 96,
    maxHz: 360,
    ratio2: 4.5,
    ratio3: 0.5,
    cutoffMin: 700,
    cutoffMax: 3400,
    q: 1.5,
    gain: 0.16,
    hornFreqs: [523.25, 783.99],
    hornWave: 'sine',
    hornDur: 0.35,
  },
};

export class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineOsc3: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;
  private tireGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private activeProfileKey: VehicleId | 'aircraft' | null = null;
  private lfoPhase = 0;
  private sirenTimer = 0;
  private muted = false;
  private initialized = false;

  init(): void {
    if (this.initialized) {
      if (this.ctx && this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : 0.42;
      this.masterGain.connect(this.ctx.destination);

      // Triple-oscillator + dynamic resonant filter vehicle engine synth
      this.engineGain = this.ctx.createGain();
      this.engineGain.gain.value = 0.0;
      this.engineFilter = this.ctx.createBiquadFilter();
      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.value = 520;
      this.engineFilter.Q.value = 2.0;
      this.engineGain.connect(this.engineFilter);
      this.engineFilter.connect(this.masterGain);

      this.engineOsc1 = this.ctx.createOscillator();
      this.engineOsc1.type = 'sawtooth';
      this.engineOsc1.frequency.value = 58;
      this.engineOsc1.connect(this.engineGain);
      this.engineOsc1.start();

      this.engineOsc2 = this.ctx.createOscillator();
      this.engineOsc2.type = 'triangle';
      this.engineOsc2.frequency.value = 116;
      this.engineOsc2.connect(this.engineGain);
      this.engineOsc2.start();

      this.engineOsc3 = this.ctx.createOscillator();
      this.engineOsc3.type = 'sine';
      this.engineOsc3.frequency.value = 174;
      this.engineOsc3.connect(this.engineGain);
      this.engineOsc3.start();

      // Noise buffer for tire screech and monsoon rain
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuf = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const tireSrc = this.ctx.createBufferSource();
      tireSrc.buffer = noiseBuf;
      tireSrc.loop = true;
      const tireFilter = this.ctx.createBiquadFilter();
      tireFilter.type = 'bandpass';
      tireFilter.frequency.value = 1650;
      tireFilter.Q.value = 5.5;
      this.tireGain = this.ctx.createGain();
      this.tireGain.gain.value = 0;
      tireSrc.connect(tireFilter);
      tireFilter.connect(this.tireGain);
      this.tireGain.connect(this.masterGain);
      tireSrc.start();

      const rainSrc = this.ctx.createBufferSource();
      rainSrc.buffer = noiseBuf;
      rainSrc.loop = true;
      const rainFilter = this.ctx.createBiquadFilter();
      rainFilter.type = 'highpass';
      rainFilter.frequency.value = 950;
      this.rainGain = this.ctx.createGain();
      this.rainGain.gain.value = 0;
      rainSrc.connect(rainFilter);
      rainFilter.connect(this.rainGain);
      this.rainGain.connect(this.masterGain);
      rainSrc.start();

      this.initialized = true;
    } catch {
      // Ignore if AudioContext is blocked
    }
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.42, this.ctx.currentTime, 0.04);
    }
  }

  isMuted(): boolean {
    return this.muted;
  }

  silenceLoops(): void {
    if (!this.initialized || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.engineGain?.gain.setTargetAtTime(0, now, 0.05);
    this.tireGain?.gain.setTargetAtTime(0, now, 0.05);
    this.rainGain?.gain.setTargetAtTime(0, now, 0.12);
  }

  updateLoop(
    dt: number,
    inVehicle: boolean,
    rpmRatio: number,
    nitroActive: boolean,
    driftIntensity: number,
    isMonsoon: boolean,
    wantedLevel: number,
    vehicleId: VehicleId = 'ferrari_sf90',
    inAircraft = false,
  ): void {
    if (
      !this.initialized ||
      !this.ctx ||
      !this.engineGain ||
      !this.engineOsc1 ||
      !this.engineOsc2 ||
      !this.engineOsc3 ||
      !this.engineFilter
    ) {
      return;
    }
    const now = this.ctx.currentTime;

    if (inVehicle || inAircraft) {
      const key: VehicleId | 'aircraft' = inAircraft ? 'aircraft' : vehicleId;
      const profile = VEHICLE_SOUND_PROFILES[key] || VEHICLE_SOUND_PROFILES.ferrari_sf90;

      if (this.activeProfileKey !== key) {
        this.activeProfileKey = key;
        this.lfoPhase = 0;
        this.engineOsc1.type = profile.wave1;
        this.engineOsc2.type = profile.wave2;
        this.engineOsc3.type = profile.wave3;
        this.engineFilter.Q.setTargetAtTime(profile.q, now, 0.05);
      }

      const boostHz = nitroActive ? (inAircraft ? 85 : 36) : 0;
      const baseFreq = profile.baseHz + rpmRatio * (profile.maxHz - profile.baseHz) + boostHz;
      this.engineOsc1.frequency.setTargetAtTime(baseFreq, now, 0.05);
      this.engineOsc2.frequency.setTargetAtTime(baseFreq * profile.ratio2, now, 0.05);
      this.engineOsc3.frequency.setTargetAtTime(baseFreq * profile.ratio3, now, 0.05);

      const cutoff = profile.cutoffMin + rpmRatio * (profile.cutoffMax - profile.cutoffMin) + (nitroActive ? 450 : 0);
      this.engineFilter.frequency.setTargetAtTime(cutoff, now, 0.06);

      let thumpMod = 1.0;
      if (profile.thumpHz && profile.thumpDepth) {
        const pulseRate = profile.thumpHz * (0.7 + rpmRatio * 1.6);
        this.lfoPhase = (this.lfoPhase + dt * pulseRate * Math.PI * 2) % (Math.PI * 2);
        thumpMod = 1.0 - profile.thumpDepth * (0.5 + 0.5 * Math.sin(this.lfoPhase));
      }

      const targetGain = (profile.gain * (0.52 + rpmRatio * 0.65) + (nitroActive ? 0.05 : 0)) * thumpMod;
      this.engineGain.gain.setTargetAtTime(targetGain, now, 0.05);
    } else {
      this.engineGain.gain.setTargetAtTime(0, now, 0.08);
    }

    if (this.tireGain) {
      this.tireGain.gain.setTargetAtTime(
        inVehicle && !inAircraft ? Math.min(0.16, driftIntensity * 0.14) : 0,
        now,
        0.05,
      );
    }
    if (this.rainGain) {
      this.rainGain.gain.setTargetAtTime(isMonsoon ? 0.08 : 0, now, 0.35);
    }

    if (wantedLevel > 0) {
      this.sirenTimer += dt;
      if (this.sirenTimer >= 0.72) {
        this.sirenTimer = 0;
        this.playSirenChirp();
      }
    }
  }

  private playSirenChirp(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(640, now);
    osc.frequency.linearRampToValueAtTime(980, now + 0.32);
    osc.frequency.linearRampToValueAtTime(640, now + 0.64);
    g.gain.setValueAtTime(0.035, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.66);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.68);
  }

  playCrash(intensity = 1): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(135 * Math.max(0.6, intensity), now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.24);
    g.gain.setValueAtTime(Math.min(0.32, 0.14 * intensity), now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.28);
  }

  playHorn(vehicleId: VehicleId = 'ferrari_sf90', inAircraft = false): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const key: VehicleId | 'aircraft' = inAircraft ? 'aircraft' : vehicleId;
    const profile = VEHICLE_SOUND_PROFILES[key] || VEHICLE_SOUND_PROFILES.ferrari_sf90;

    for (const freq of profile.hornFreqs) {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = profile.hornWave;
      osc.frequency.setValueAtTime(freq, now);
      g.gain.setValueAtTime(profile.hornFreqs.length > 1 ? 0.08 : 0.12, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + profile.hornDur);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + profile.hornDur + 0.03);
    }
  }

  playThunder(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(68, now);
    osc.frequency.exponentialRampToValueAtTime(24, now + 1.1);
    g.gain.setValueAtTime(0.22, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 1.15);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 1.2);
  }

  playMissionStinger(success: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const notes = success ? [523.25, 659.25, 783.99, 1046.5] : [349.23, 311.13, 261.63];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);
      g.gain.setValueAtTime(0.14, now + idx * 0.09);
      g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.3);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.32);
    });
  }

  playGunshot(weaponId: 'fists' | 'pistol' | 'smg' | 'shotgun' | 'ak47' | 'rpg'): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();

    if (weaponId === 'fists') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(160, now);
      osc.frequency.exponentialRampToValueAtTime(48, now + 0.11);
      g.gain.setValueAtTime(0.18, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    } else if (weaponId === 'rpg') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(210, now);
      osc.frequency.exponentialRampToValueAtTime(55, now + 0.34);
      g.gain.setValueAtTime(0.24, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
    } else if (weaponId === 'shotgun') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(190, now);
      osc.frequency.exponentialRampToValueAtTime(36, now + 0.2);
      g.gain.setValueAtTime(0.25, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    } else {
      const startFreq = weaponId === 'ak47' ? 280 : weaponId === 'smg' ? 420 : 340;
      const dur = weaponId === 'smg' ? 0.08 : 0.13;
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(startFreq, now);
      osc.frequency.exponentialRampToValueAtTime(62, now + dur);
      g.gain.setValueAtTime(weaponId === 'ak47' ? 0.22 : 0.16, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + dur + 0.02);
    }

    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.38);
  }

  playExplosion(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(115, now);
    osc.frequency.exponentialRampToValueAtTime(22, now + 0.65);
    g.gain.setValueAtTime(0.36, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.68);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.7);
  }

  playWaterHose(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(420, now);
    osc.frequency.linearRampToValueAtTime(280, now + 0.14);
    g.gain.setValueAtTime(0.055, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  playCashRegister(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    [987.77, 1318.5].forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);
      g.gain.setValueAtTime(0.14, now + idx * 0.08);
      g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.24);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.25);
    });
  }

  playRobberyAlarm(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(880, now + i * 0.22);
      osc.frequency.setValueAtTime(660, now + i * 0.22 + 0.11);
      g.gain.setValueAtTime(0.09, now + i * 0.22);
      g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.22 + 0.2);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + i * 0.22);
      osc.stop(now + i * 0.22 + 0.21);
    }
  }

  playFuelPump(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.linearRampToValueAtTime(520, now + 0.32);
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.38);
  }

  playTrainHorn(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    [164.81, 207.65, 246.94].forEach((freq) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);
      g.gain.setValueAtTime(0.055, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.58);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.6);
    });
  }

  playFireSirenChirp(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.linearRampToValueAtTime(840, now + 0.28);
    osc.frequency.linearRampToValueAtTime(520, now + 0.56);
    g.gain.setValueAtTime(0.04, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.58);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.6);
  }

  dispose(): void {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
    this.initialized = false;
  }
}
