import type {
  CharacterConfig,
  ChatMessage,
  LobbySummary,
  RemotePeerState,
  VehicleId,
} from '../types/game';

export interface ShardStateUpdate {
  shardId: string;
  shardPlayers: number;
  totalConcurrent: number;
  peers: RemotePeerState[];
}

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private reconnectTimer: number | null = null;
  private disposed = false;
  private playerId: string;
  private name = 'Mumbai Driver';
  private shardId = 'IN-GLOBAL-01';
  private lastJoinPayload: Record<string, unknown> = {};

  onShardState: ((state: ShardStateUpdate) => void) | null = null;
  onChatMessage: ((msg: ChatMessage) => void) | null = null;
  onPropSmashed: ((propId: number, vx: number, vz: number) => void) | null = null;
  onConnectionChange: ((connected: boolean, shardId: string) => void) | null = null;

  constructor(playerId?: string) {
    this.playerId = playerId || `drv_${Math.random().toString(36).slice(2, 10)}`;
  }

  connect(params: {
    playerId?: string;
    name: string;
    shardId?: string;
    x: number;
    y: number;
    z: number;
    yaw: number;
    vehicleId: VehicleId;
    vehicleColor: string;
    onFoot: boolean;
    wantedLevel: number;
    characterConfig: CharacterConfig;
  }): void {
    if (params.playerId) this.playerId = params.playerId;
    this.name = params.name;
    if (params.shardId) this.shardId = params.shardId;
    this.lastJoinPayload = { ...params, playerId: this.playerId, shardId: this.shardId };

    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      if (this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'lobby:join', ...this.lastJoinPayload }));
      }
      return;
    }

    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'lobby:join', ...this.lastJoinPayload }));
    };

    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(String(ev.data)) as Record<string, unknown>;
        const type = String(msg.type || '');
        if (type === 'lobby:joined') {
          this.shardId = String(msg.shardId || this.shardId);
          this.onConnectionChange?.(true, this.shardId);
        } else if (type === 'shard:state') {
          this.onShardState?.({
            shardId: String(msg.shardId || this.shardId),
            shardPlayers: Number(msg.shardPlayers) || 1,
            totalConcurrent: Number(msg.totalConcurrent) || 1,
            peers: (msg.peers as RemotePeerState[]) || [],
          });
        } else if (type === 'chat:message') {
          this.onChatMessage?.({
            id: String(msg.id || ''),
            senderId: String(msg.senderId || ''),
            senderName: String(msg.senderName || 'Driver'),
            text: String(msg.text || ''),
            timestamp: Number(msg.timestamp) || Date.now(),
          });
        } else if (type === 'prop:smashed') {
          this.onPropSmashed?.(
            Number(msg.propId),
            Number(msg.vx) || 0,
            Number(msg.vz) || 0,
          );
        }
      } catch {
        // Ignore malformed packets
      }
    };

    ws.onclose = () => {
      this.onConnectionChange?.(false, this.shardId);
      if (!this.disposed && this.reconnectTimer === null) {
        this.reconnectTimer = window.setTimeout(() => {
          this.reconnectTimer = null;
          if (!this.disposed) {
            this.connect(this.lastJoinPayload as Parameters<MultiplayerClient['connect']>[0]);
          }
        }, 2500);
      }
    };

    ws.onerror = () => {
      ws.close();
    };
  }

  switchShard(shardId: string): void {
    this.shardId = shardId;
    this.lastJoinPayload.shardId = shardId;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'lobby:join', ...this.lastJoinPayload }));
    }
  }

  sendPlayerState(state: {
    name: string;
    x: number;
    y: number;
    z: number;
    yaw: number;
    speed: number;
    vehicleId: VehicleId;
    vehicleColor: string;
    onFoot: boolean;
    wantedLevel: number;
    characterConfig: CharacterConfig;
  }): void {
    this.lastJoinPayload = { ...this.lastJoinPayload, ...state };
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'player:update', ...state }));
    }
  }

  sendChat(text: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'chat:send', text }));
    }
  }

  sendPropSmash(propId: number, vx: number, vz: number): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'prop:smash', propId, vx, vz }));
    }
  }

  async fetchLobbies(): Promise<{ totalConcurrentPlayers: number; lobbies: LobbySummary[] }> {
    const res = await fetch('/api/lobbies');
    if (!res.ok) throw new Error('Failed to fetch lobbies');
    return (await res.json()) as { totalConcurrentPlayers: number; lobbies: LobbySummary[] };
  }

  dispose(): void {
    this.disposed = true;
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.ws?.close();
    this.ws = null;
  }
}
