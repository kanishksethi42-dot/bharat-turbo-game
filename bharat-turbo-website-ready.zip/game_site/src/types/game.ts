export type VehicleId =
  | 'ferrari_sf90'
  | 'lamborghini_svj'
  | 'koenigsegg_jesko'
  | 'bugatti_chiron'
  | 'city_sedan'
  | 'ambassador_classic'
  | 'mumbai_taxi'
  | 'swift_hatch'
  | 'alto_hatch'
  | 'thar_suv'
  | 'fortuner_suv'
  | 'jaipur_bus'
  | 'cargo_van'
  | 'fire_truck'
  | 'auto_rickshaw'
  | 'e_rickshaw'
  | 'bullet_350'
  | 'activa_scooter'
  | 'duke_390';

export type WeaponId = 'fists' | 'pistol' | 'smg' | 'shotgun' | 'ak47' | 'rpg';

export interface WeaponSpec {
  id: WeaponId;
  name: string;
  category: string;
  damage: number;
  fireRateSec: number;
  range: number;
  projectileSpeed: number;
  pellets: number;
  spread: number;
  explosiveRadius: number;
  price: number;
  color: string;
  description: string;
}

export const WEAPONS_CATALOG: Record<WeaponId, WeaponSpec> = {
  fists: {
    id: 'fists',
    name: 'Street Combat',
    category: 'Melee',
    damage: 26,
    fireRateSec: 0.35,
    range: 4.5,
    projectileSpeed: 28,
    pellets: 1,
    spread: 0,
    explosiveRadius: 0,
    price: 0,
    color: '#94a3b8',
    description: 'Close-quarters street punch for brawling on foot.',
  },
  pistol: {
    id: 'pistol',
    name: '9mm Service Pistol',
    category: 'Handgun',
    damage: 30,
    fireRateSec: 0.28,
    range: 120,
    projectileSpeed: 135,
    pellets: 1,
    spread: 0.015,
    explosiveRadius: 0,
    price: 0,
    color: '#f59e0b',
    description: 'Reliable semi-auto sidearm usable on foot or during drive-by chases.',
  },
  smg: {
    id: 'smg',
    name: 'MP-5 Tactical SMG',
    category: 'Submachine Gun',
    damage: 18,
    fireRateSec: 0.095,
    range: 115,
    projectileSpeed: 145,
    pellets: 1,
    spread: 0.045,
    explosiveRadius: 0,
    price: 0,
    color: '#38bdf8',
    description: 'High-RPM compact submachine gun built for spraying highway interceptors.',
  },
  shotgun: {
    id: 'shotgun',
    name: '12-Gauge Sweeper',
    category: 'Shotgun',
    damage: 22,
    fireRateSec: 0.72,
    range: 75,
    projectileSpeed: 120,
    pellets: 6,
    spread: 0.11,
    explosiveRadius: 0,
    price: 28000,
    color: '#ef4444',
    description: 'Devastating 6-pellet spread that shreds vehicles and low-flying choppers.',
  },
  ak47: {
    id: 'ak47',
    name: 'AK-47 Assault Rifle',
    category: 'Assault Rifle',
    damage: 34,
    fireRateSec: 0.125,
    range: 175,
    projectileSpeed: 175,
    pellets: 1,
    spread: 0.025,
    explosiveRadius: 0,
    price: 35000,
    color: '#eab308',
    description: 'Long-range 7.62mm rifle capable of downing police helicopters from the road.',
  },
  rpg: {
    id: 'rpg',
    name: 'AT-4 Rocket Launcher',
    category: 'Heavy Ordnance',
    damage: 140,
    fireRateSec: 1.25,
    range: 240,
    projectileSpeed: 88,
    pellets: 1,
    spread: 0.006,
    explosiveRadius: 12,
    price: 85000,
    color: '#f97316',
    description: 'Guided anti-armor rocket that obliterates police SUVs and choppers in one blast.',
  },
};

export type DistrictId =
  | 'jaipur'
  | 'jaipur_rural'
  | 'jodhpur'
  | 'udaipur'
  | 'jaisalmer'
  | 'bikaner'
  | 'kota'
  | 'ajmer'
  | 'mumbai'
  | 'delhi'
  | 'bengaluru';

export type JaipurZone =
  | 'Walled Pink City'
  | 'Central · MI Road'
  | 'North · Amer'
  | 'South · JLN & Airport'
  | 'West · Vaishali'
  | 'East · Agra Rd';

export type WeatherMode = 'sunset' | 'monsoon' | 'night' | 'clear' | 'sandstorm';

export type GraphicsPreset = 'ultra4k' | 'high' | 'mobile';

export type CameraMode = 'chase' | 'action' | 'hood' | 'cinematic';

export type CharacterArchetype = 'racer' | 'royal' | 'cyber' | 'maverick';
export type CharacterHeadgear = 'fade' | 'helmet' | 'turban' | 'cap';
export type CharacterEyewear = 'none' | 'aviators' | 'visor' | 'bandana';

export interface CharacterConfig {
  archetype: CharacterArchetype;
  outfitColor: string;
  skinTone: string;
  headgear: CharacterHeadgear;
  eyewear: CharacterEyewear;
}

export type VehicleFilterClass =
  | 'All'
  | 'Hypercars'
  | 'Sedans'
  | 'Hatchbacks'
  | 'SUVs'
  | 'Bus & Vans'
  | 'Emergency'
  | '2 & 3 Wheelers';

export interface VehicleSpec {
  id: VehicleId;
  name: string;
  brand: string;
  category: string;
  filterClass: Exclude<VehicleFilterClass, 'All'>;
  topSpeedKmh: number;
  accel: number;
  handling: number;
  driftGrip: number;
  mass: number;
  defaultColor: string;
  price: number;
  description: string;
  isTwoWheeler?: boolean;
}

export const VEHICLE_CATALOG: Record<VehicleId, VehicleSpec> = {
  ferrari_sf90: {
    id: 'ferrari_sf90',
    name: 'SF90 Stradale',
    brand: 'Ferrari',
    category: 'Hybrid Hypercar',
    filterClass: 'Hypercars',
    topSpeedKmh: 340,
    accel: 54,
    handling: 3.1,
    driftGrip: 0.88,
    mass: 1570,
    defaultColor: '#d91616',
    price: 0,
    description: 'Twin-turbo V8 + triple e-motor Italian precision built for JLN Marg & Tonk Road.',
  },
  lamborghini_svj: {
    id: 'lamborghini_svj',
    name: 'Aventador SVJ',
    brand: 'Lamborghini',
    category: 'V12 Track Beast',
    filterClass: 'Hypercars',
    topSpeedKmh: 355,
    accel: 56,
    handling: 2.95,
    driftGrip: 0.84,
    mass: 1525,
    defaultColor: '#f5b800',
    price: 0,
    description: 'Naturally aspirated V12 fury tearing past Hawa Mahal and Amer Road straights.',
  },
  koenigsegg_jesko: {
    id: 'koenigsegg_jesko',
    name: 'Jesko Absolut',
    brand: 'Koenigsegg',
    category: 'Megacar',
    filterClass: 'Hypercars',
    topSpeedKmh: 480,
    accel: 64,
    handling: 3.25,
    driftGrip: 0.9,
    mass: 1390,
    defaultColor: '#f8fafc',
    price: 250000,
    description: 'Ultra-low-drag Swedish megacar engineered to shatter Jaipur Ring Road speed traps.',
  },
  bugatti_chiron: {
    id: 'bugatti_chiron',
    name: 'Chiron Super Sport',
    brand: 'Bugatti',
    category: 'W16 Grand Tourer',
    filterClass: 'Hypercars',
    topSpeedKmh: 440,
    accel: 62,
    handling: 2.85,
    driftGrip: 0.87,
    mass: 1995,
    defaultColor: '#1d4ed8',
    price: 200000,
    description: 'Quad-turbo W16 heavyweight that blasts down 200 Ft Bypass and Airport Expressway.',
  },
  city_sedan: {
    id: 'city_sedan',
    name: 'City i-VTEC Touring',
    brand: 'Honda',
    category: 'Executive Sedan',
    filterClass: 'Sedans',
    topSpeedKmh: 235,
    accel: 43,
    handling: 3.35,
    driftGrip: 0.86,
    mass: 1180,
    defaultColor: '#e2e8f0',
    price: 22000,
    description: 'Jaipur’s quintessential smooth executive sedan built for C-Scheme and MI Road cruising.',
  },
  ambassador_classic: {
    id: 'ambassador_classic',
    name: 'Ambassador Grand',
    brand: 'Hindustan Heritage',
    category: 'Heritage Sedan',
    filterClass: 'Sedans',
    topSpeedKmh: 195,
    accel: 34,
    handling: 2.9,
    driftGrip: 0.82,
    mass: 1280,
    defaultColor: '#f1f5f9',
    price: 25000,
    description: 'Timeless Indian steel sedan with chrome bumpers and royal Secretariat presence.',
  },
  mumbai_taxi: {
    id: 'mumbai_taxi',
    name: 'Pink City Cab Dzire',
    brand: 'Maruti Custom',
    category: 'City Cab Sedan',
    filterClass: 'Sedans',
    topSpeedKmh: 245,
    accel: 45,
    handling: 3.4,
    driftGrip: 0.82,
    mass: 1090,
    defaultColor: '#eab308',
    price: 0,
    description: 'Turbocharged Jaipur commercial taxi ready for high-speed fare runs across town.',
  },
  swift_hatch: {
    id: 'swift_hatch',
    name: 'Swift RS Urban',
    brand: 'Maruti Suzuki',
    category: 'Sport Hatchback',
    filterClass: 'Hatchbacks',
    topSpeedKmh: 215,
    accel: 40,
    handling: 3.55,
    driftGrip: 0.86,
    mass: 940,
    defaultColor: '#dc2626',
    price: 0,
    description: 'Nimble Indian city hatchback built to dart effortlessly through Johari Bazaar.',
  },
  alto_hatch: {
    id: 'alto_hatch',
    name: 'Alto K10 City Pocket',
    brand: 'Maruti Suzuki',
    category: 'Compact Hatchback',
    filterClass: 'Hatchbacks',
    topSpeedKmh: 178,
    accel: 35,
    handling: 3.85,
    driftGrip: 0.88,
    mass: 760,
    defaultColor: '#38bdf8',
    price: 12000,
    description: 'Ultra-light everyday Jaipur hatchback that squeezes through narrow Walled City lanes.',
  },
  thar_suv: {
    id: 'thar_suv',
    name: 'Thar 4x4 Roxx',
    brand: 'Mahindra',
    category: 'Off-Road 4x4 SUV',
    filterClass: 'SUVs',
    topSpeedKmh: 225,
    accel: 42,
    handling: 2.8,
    driftGrip: 0.84,
    mass: 1750,
    defaultColor: '#b91c1c',
    price: 45000,
    description: 'High-stance Indian 4x4 icon built to conquer Nahargarh hill passes and city traffic.',
  },
  fortuner_suv: {
    id: 'fortuner_suv',
    name: 'Fortuner Legender 4x4',
    brand: 'Toyota',
    category: 'Full-Size VIP SUV',
    filterClass: 'SUVs',
    topSpeedKmh: 248,
    accel: 46,
    handling: 2.75,
    driftGrip: 0.85,
    mass: 2180,
    defaultColor: '#f8fafc',
    price: 68000,
    description: 'Commanding Jaipur VIP convoy SUV with twin-beam LEDs and massive road presence.',
  },
  jaipur_bus: {
    id: 'jaipur_bus',
    name: 'JCTSL City Low-Floor Bus',
    brand: 'JCTSL · Tata Marcopolo',
    category: 'City Transit Bus',
    filterClass: 'Bus & Vans',
    topSpeedKmh: 142,
    accel: 26,
    handling: 2.15,
    driftGrip: 0.86,
    mass: 9500,
    defaultColor: '#dc2626',
    price: 35000,
    description: 'Official Jaipur AC Low-Floor city bus serving Badi Chaupar to Sitapura routes.',
  },
  cargo_van: {
    id: 'cargo_van',
    name: 'Eeco & Bolero Cargo Van',
    brand: 'Maruti · Mahindra',
    category: 'Utility & Delivery Van',
    filterClass: 'Bus & Vans',
    topSpeedKmh: 172,
    accel: 34,
    handling: 2.75,
    driftGrip: 0.82,
    mass: 1580,
    defaultColor: '#f8fafc',
    price: 18000,
    description: 'Versatile Jaipur delivery & bank bullion transport van built for cargo shifts.',
  },
  fire_truck: {
    id: 'fire_truck',
    name: 'Jaipur Fire Tender',
    brand: 'Nagar Nigam Fire Dept',
    category: 'Fire Brigade Engine',
    filterClass: 'Emergency',
    topSpeedKmh: 165,
    accel: 33,
    handling: 2.3,
    driftGrip: 0.85,
    mass: 8400,
    defaultColor: '#dc2626',
    price: 52000,
    description: 'Heavy fire brigade engine equipped with rooftop water cannon [E / Click] to douse city fires.',
  },
  auto_rickshaw: {
    id: 'auto_rickshaw',
    name: 'Pink-City Tuk-Tuk',
    brand: 'Bajaj Classic',
    category: 'CNG 3-Wheeler',
    filterClass: '2 & 3 Wheelers',
    topSpeedKmh: 145,
    accel: 34,
    handling: 3.85,
    driftGrip: 0.72,
    mass: 420,
    defaultColor: '#eab308',
    price: 0,
    description: 'Tuned Indian 3-wheeler auto-rickshaw that weaves through Choti & Badi Chaupar.',
  },
  e_rickshaw: {
    id: 'e_rickshaw',
    name: 'Metro Pink E-Rickshaw',
    brand: 'Jaipur EV Mobility',
    category: 'Electric 3-Wheeler',
    filterClass: '2 & 3 Wheelers',
    topSpeedKmh: 105,
    accel: 30,
    handling: 4.1,
    driftGrip: 0.8,
    mass: 310,
    defaultColor: '#10b981',
    price: 9000,
    description: 'Whisper-quiet battery rickshaw connecting Metro stations and Pink City bazaars.',
  },
  bullet_350: {
    id: 'bullet_350',
    name: 'Classic 350 Cruiser',
    brand: 'Royal Enfield',
    category: '2-Wheeler Cruiser',
    filterClass: '2 & 3 Wheelers',
    topSpeedKmh: 195,
    accel: 44,
    handling: 3.7,
    driftGrip: 0.86,
    mass: 195,
    defaultColor: '#1e293b',
    price: 0,
    description: 'Thumping single-cylinder cruiser motorcycle built for MI Road and Amer Ridge.',
    isTwoWheeler: true,
  },
  activa_scooter: {
    id: 'activa_scooter',
    name: 'Activa 125 Glide',
    brand: 'Honda',
    category: '2-Wheeler Scooter',
    filterClass: '2 & 3 Wheelers',
    topSpeedKmh: 145,
    accel: 36,
    handling: 4.0,
    driftGrip: 0.88,
    mass: 112,
    defaultColor: '#0284c7',
    price: 15000,
    description: 'Everyday Jaipur urban scooter tuned for razor-sharp bazaar lane filtering and deliveries.',
    isTwoWheeler: true,
  },
  duke_390: {
    id: 'duke_390',
    name: 'Duke 390 Street',
    brand: 'KTM',
    category: '2-Wheeler Sportbike',
    filterClass: '2 & 3 Wheelers',
    topSpeedKmh: 260,
    accel: 58,
    handling: 4.1,
    driftGrip: 0.9,
    mass: 168,
    defaultColor: '#ea580c',
    price: 40000,
    description: 'Aggressive naked streetfighter bike that rockets between Jaipur chaupars.',
    isTwoWheeler: true,
  },
};

// ============================================================================
// AUTHENTIC FULL-SCALE JAIPUR ROAD GRID, CIRCLES, SIGNALS, METRO & RAIL
// ============================================================================
export const JAIPUR_EW_ROADS = [-1220, -960, -760, -560, -380, -210, -40, 140, 340, 580, 840, 1060] as const;
export const JAIPUR_NS_ROADS = [-1220, -1020, -760, -480, -240, -60, 160, 420, 760, 1040, 1260] as const;

export interface JaipurCircleDef {
  id: string;
  name: string;
  x: number;
  z: number;
  radius: number;
  monument: 'chhatri' | 'statue' | 'fountain' | 'patrika' | 'pillar' | 'clock';
  accent: string;
}

export const JAIPUR_CIRCLES: JaipurCircleDef[] = [
  { id: 'c_badi_chaupar', name: 'Badi Chaupar', x: 160, z: -210, radius: 22, monument: 'fountain', accent: '#ec4899' },
  { id: 'c_choti_chaupar', name: 'Choti Chaupar', x: -240, z: -210, radius: 22, monument: 'fountain', accent: '#f472b6' },
  { id: 'c_statue_circle', name: 'Statue Circle', x: -240, z: 140, radius: 24, monument: 'statue', accent: '#38bdf8' },
  { id: 'c_panch_batti', name: 'Panch Batti · MI Rd', x: -60, z: 140, radius: 19, monument: 'clock', accent: '#f59e0b' },
  { id: 'c_albert_circle', name: 'Ram Niwas · Albert Circle', x: 160, z: 140, radius: 22, monument: 'chhatri', accent: '#eab308' },
  { id: 'c_rambagh', name: 'Rambagh Circle', x: 160, z: 340, radius: 23, monument: 'fountain', accent: '#34d399' },
  { id: 'c_trimurti', name: 'Trimurti Circle', x: 160, z: 580, radius: 20, monument: 'pillar', accent: '#fb923c' },
  { id: 'c_ajmeri_gate', name: 'Ajmeri Gate Circle', x: -60, z: -40, radius: 19, monument: 'pillar', accent: '#f97316' },
  { id: 'c_sanganeri_gate', name: 'Sanganeri Gate Circle', x: 160, z: -40, radius: 19, monument: 'chhatri', accent: '#ec4899' },
  { id: 'c_tonk_phatak', name: 'Gandhi Nagar · Tonk Phatak', x: -60, z: 340, radius: 20, monument: 'clock', accent: '#a855f7' },
  { id: 'c_jawahar', name: 'Jawahar Circle (Patrika)', x: 160, z: 840, radius: 36, monument: 'patrika', accent: '#f43f5e' },
  { id: 'c_b2_bypass', name: 'B2 Bypass Circle', x: -60, z: 840, radius: 22, monument: 'pillar', accent: '#22d3ee' },
  { id: 'c_200ft', name: '200 Ft Bypass Circle', x: -1020, z: 140, radius: 25, monument: 'pillar', accent: '#60a5fa' },
  { id: 'c_transport', name: 'Transport Nagar Circle', x: 760, z: -40, radius: 21, monument: 'clock', accent: '#10b981' },
];

export interface TrafficLightNode {
  id: string;
  label: string;
  x: number;
  z: number;
}

export const JAIPUR_TRAFFIC_LIGHTS: TrafficLightNode[] = [
  { id: 'tl_sindhi', label: 'Sindhi Camp Signal', x: -480, z: -40 },
  { id: 'tl_jaipur_jn', label: 'Railway Station Crossing', x: -480, z: 140 },
  { id: 'tl_vaishali', label: 'Vaishali Amrapali Signal', x: -760, z: 140 },
  { id: 'tl_queens', label: 'Queens Road Signal', x: -760, z: 340 },
  { id: 'tl_mansarovar', label: 'Mansarovar Metro Signal', x: -480, z: 580 },
  { id: 'tl_new_sanganer', label: 'New Sanganer Signal', x: -480, z: 840 },
  { id: 'tl_sodala', label: 'Sodala Flyover Signal', x: -240, z: 340 },
  { id: 'tl_civil', label: 'Civil Lines Signal', x: -240, z: 580 },
  { id: 'tl_lalkothi', label: 'Lal Kothi Tonk Rd Signal', x: -60, z: 580 },
  { id: 'tl_raja_park', label: 'Raja Park Panchwati', x: 420, z: 140 },
  { id: 'tl_adarsh', label: 'Adarsh Nagar Signal', x: 420, z: -40 },
  { id: 'tl_malviya', label: 'WTP Malviya Signal', x: 420, z: 580 },
  { id: 'tl_jagatpura', label: 'Jagatpura Signal', x: 760, z: 580 },
  { id: 'tl_airport', label: 'Airport Terminal Signal', x: 160, z: 1060 },
  { id: 'tl_sitapura', label: 'Sitapura JECC Signal', x: 760, z: 1060 },
  { id: 'tl_amer_turn', label: 'Jal Mahal Signal', x: 160, z: -560 },
  { id: 'tl_vidyadhar', label: 'Vidyadhar Nagar Signal', x: -480, z: -560 },
  { id: 'tl_surajpole', label: 'Surajpole Gate Signal', x: 420, z: -210 },
];

export interface MetroStationDef {
  id: string;
  name: string;
  line: 'Pink Line' | 'Orange Line';
  x: number;
  z: number;
}

export const JAIPUR_METRO_STATIONS: MetroStationDef[] = [
  { id: 'metro_mansarovar', name: 'Mansarovar Metro', line: 'Pink Line', x: -760, z: 112 },
  { id: 'metro_civil_lines', name: 'Civil Lines Metro', line: 'Pink Line', x: -580, z: 112 },
  { id: 'metro_railway', name: 'Railway Station Metro', line: 'Pink Line', x: -420, z: 112 },
  { id: 'metro_sindhi', name: 'Sindhi Camp Metro', line: 'Pink Line', x: -300, z: 112 },
  { id: 'metro_chandpole', name: 'Chandpole Metro', line: 'Pink Line', x: -240, z: -120 },
  { id: 'metro_choti_chaupar', name: 'Choti Chaupar Metro', line: 'Pink Line', x: -165, z: -236 },
  { id: 'metro_badi_chaupar', name: 'Badi Chaupar Metro', line: 'Pink Line', x: 120, z: -236 },
  { id: 'metro_ambabari', name: 'Vidyadhar · Ambabari Metro', line: 'Orange Line', x: -240, z: -560 },
];

export interface RailStationDef {
  id: string;
  name: string;
  x: number;
  z: number;
}

export const JAIPUR_RAIL_STATIONS: RailStationDef[] = [
  { id: 'rail_kanakpura', name: 'Kanakpura Railway Station', x: -940, z: 248 },
  { id: 'rail_jaipur_jn', name: 'Jaipur Junction Terminus', x: -480, z: 248 },
  { id: 'rail_gandhinagar', name: 'Gandhinagar Jaipur Station', x: 260, z: 248 },
  { id: 'rail_jagatpura', name: 'Jagatpura Railway Station', x: 760, z: 248 },
];

export type BuildingCategory =
  | 'house'
  | 'hotel'
  | 'paan'
  | 'grocery'
  | 'dmart'
  | 'decathlon'
  | 'school'
  | 'office'
  | 'showroom'
  | 'petrol'
  | 'ammunation'
  | 'cloth'
  | 'barber'
  | 'jewelry'
  | 'sweet_shop'
  | 'electronics'
  | 'pharmacy'
  | 'chai_tapri'
  | 'fire_station'
  | 'metro'
  | 'railway'
  | 'stadium';

export interface EnterableBuildingInfo {
  id: string;
  name: string;
  category: BuildingCategory;
  localityName: string;
  x: number;
  z: number;
  entryX: number;
  entryZ: number;
  accent: string;
  brand?: string;
  lootCash: number;
  canRob: boolean;
}

export type JobType =
  | 'cab_driver'
  | 'food_delivery'
  | 'bus_driver'
  | 'firefighter'
  | 'ambulance'
  | 'police_bounty'
  | 'cash_escort'
  | 'office_teacher';

export interface JobDef {
  id: JobType;
  title: string;
  role: string;
  vehicleHint: string;
  rewardCash: number;
  rewardRep: number;
  timeLimitSec: number;
  description: string;
  accent: string;
}

export const JOBS_CATALOG: JobDef[] = [
  {
    id: 'cab_driver',
    title: 'Pink City Cab & Auto Ride',
    role: 'Taxi / Auto Driver',
    vehicleHint: 'Pink Cab Dzire, City Sedan, Auto or E-Rickshaw',
    rewardCash: 16000,
    rewardRep: 320,
    timeLimitSec: 110,
    description: 'Pick up passengers from MI Road / Jaipur Junction and drop them at Hawa Mahal or WTP.',
    accent: '#eab308',
  },
  {
    id: 'food_delivery',
    title: 'Swiggy / Zomato Express',
    role: 'Delivery Rider',
    vehicleHint: 'Activa, Duke 390, Bullet 350 or Hatchback',
    rewardCash: 13500,
    rewardRep: 260,
    timeLimitSec: 95,
    description: 'Pick up hot kachoris & rations from LMB / DMart and deliver to 2 Jaipur homes.',
    accent: '#f97316',
  },
  {
    id: 'bus_driver',
    title: 'JCTSL City Bus Corridor',
    role: 'Bus Captain',
    vehicleHint: 'Auto-spawns JCTSL AC Low-Floor City Bus',
    rewardCash: 24000,
    rewardRep: 480,
    timeLimitSec: 150,
    description: 'Operate the busy Badi Chaupar -> Albert Hall -> Rambagh -> Patrika Gate bus corridor.',
    accent: '#ef4444',
  },
  {
    id: 'firefighter',
    title: 'Jaipur Fire Brigade Rescue',
    role: 'Firefighter',
    vehicleHint: 'Auto-spawns Jaipur Fire Tender (Press E / Click to spray water)',
    rewardCash: 28000,
    rewardRep: 550,
    timeLimitSec: 130,
    description: 'Drive the Fire Tender to an active blaze in Jaipur and douse it with your water cannon!',
    accent: '#dc2626',
  },
  {
    id: 'ambulance',
    title: 'SMS Trauma Runner',
    role: 'Emergency Paramedic',
    vehicleHint: 'Fast SUV / Sedan / Van',
    rewardCash: 22000,
    rewardRep: 440,
    timeLimitSec: 105,
    description: 'Pick up an injured citizen across town and rush them to SMS Medical Hospital.',
    accent: '#fb7185',
  },
  {
    id: 'police_bounty',
    title: 'Commissioner Bounty Takedown',
    role: 'Bounty Enforcer',
    vehicleHint: 'Any Car + Weapons [E]',
    rewardCash: 34000,
    rewardRep: 700,
    timeLimitSec: 135,
    description: 'Track down and wreck the fleeing Highway Gangster sedan tearing through Jaipur.',
    accent: '#3b82f6',
  },
  {
    id: 'cash_escort',
    title: 'Armored Cash & Fuel Escort',
    role: 'Logistics Courier',
    vehicleHint: 'Auto-spawns Cargo Van',
    rewardCash: 26000,
    rewardRep: 520,
    timeLimitSec: 125,
    description: 'Haul secure bank bullion crates from State Bank MI Road to WTP Commercial Vault.',
    accent: '#10b981',
  },
  {
    id: 'office_teacher',
    title: 'Jaipur Metro Audit & Office Run',
    role: 'Corporate / Educator',
    vehicleHint: 'Any Sedan, SUV or Two-Wheeler',
    rewardCash: 18500,
    rewardRep: 360,
    timeLimitSec: 100,
    description: 'Deliver exam papers & tech dossiers between SMS Public School, Secretariat & WTP Office.',
    accent: '#a855f7',
  },
];

export interface GpsPoint {
  x: number;
  z: number;
}

function clampToGridX(x: number): number {
  return Math.max(-1500, Math.min(1500, x));
}

function clampToGridZ(z: number): number {
  return Math.max(-1500, Math.min(1500, z));
}

function nearestRoadCoord(val: number, roads: readonly number[]): number {
  let best = roads[0];
  let bestDist = Math.abs(val - best);
  for (let i = 1; i < roads.length; i++) {
    const d = Math.abs(val - roads[i]);
    if (d < bestDist) {
      bestDist = d;
      best = roads[i];
    }
  }
  return best;
}

/**
 * Computes an orthogonal street-following GPS path along Jaipur's EW & NS avenues
 * from `(startX, startZ)` to `(destX, destZ)` via Dijkstra on the street intersection graph.
 */
export function computeJaipurGpsRoute(
  startX: number,
  startZ: number,
  destX: number,
  destZ: number,
): GpsPoint[] {
  const directDist = Math.hypot(destX - startX, destZ - startZ);
  if (directDist < 36) {
    return [
      { x: startX, z: startZ },
      { x: destX, z: destZ },
    ];
  }

  const nodes: GpsPoint[] = [];
  const adj: Array<Array<{ to: number; cost: number }>> = [];

  const addNode = (x: number, z: number): number => {
    nodes.push({ x, z });
    adj.push([]);
    return nodes.length - 1;
  };
  const addEdge = (a: number, b: number, penalty = 1) => {
    if (a === b) return;
    const w = Math.hypot(nodes[a].x - nodes[b].x, nodes[a].z - nodes[b].z) * penalty;
    adj[a].push({ to: b, cost: w });
    adj[b].push({ to: a, cost: w });
  };

  const rows = JAIPUR_EW_ROADS.length;
  const cols = JAIPUR_NS_ROADS.length;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      addNode(JAIPUR_NS_ROADS[c], JAIPUR_EW_ROADS[r]);
    }
  }

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const idx = r * cols + c;
      if (c + 1 < cols) addEdge(idx, r * cols + (c + 1));
      if (r + 1 < rows) addEdge(idx, (r + 1) * cols + c);
    }
  }

  const connectEndpointToGrid = (ex: number, ez: number) => {
    const id = addNode(ex, ez);
    const cx = clampToGridX(ex);
    const cz = clampToGridZ(ez);
    const ewZ = nearestRoadCoord(cz, JAIPUR_EW_ROADS);
    const nsX = nearestRoadCoord(cx, JAIPUR_NS_ROADS);

    const ewProj = addNode(cx, ewZ);
    const nsProj = addNode(nsX, cz);

    addEdge(id, ewProj, 1.05);
    addEdge(id, nsProj, 1.05);

    const ewRow = (JAIPUR_EW_ROADS as readonly number[]).indexOf(ewZ);
    let leftCol = -1;
    let rightCol = -1;
    for (let c = 0; c < cols; c++) {
      if (JAIPUR_NS_ROADS[c] <= cx) leftCol = c;
      if (JAIPUR_NS_ROADS[c] >= cx && rightCol === -1) rightCol = c;
    }
    if (leftCol >= 0) addEdge(ewProj, ewRow * cols + leftCol);
    if (rightCol >= 0) addEdge(ewProj, ewRow * cols + rightCol);

    const nsCol = (JAIPUR_NS_ROADS as readonly number[]).indexOf(nsX);
    let topRow = -1;
    let botRow = -1;
    for (let r = 0; r < rows; r++) {
      if (JAIPUR_EW_ROADS[r] <= cz) topRow = r;
      if (JAIPUR_EW_ROADS[r] >= cz && botRow === -1) botRow = r;
    }
    if (topRow >= 0) addEdge(nsProj, topRow * cols + nsCol);
    if (botRow >= 0) addEdge(nsProj, botRow * cols + nsCol);

    return { id, ewProj, nsProj, ewZ, nsX };
  };

  const sInfo = connectEndpointToGrid(startX, startZ);
  const dInfo = connectEndpointToGrid(destX, destZ);

  if (sInfo.ewZ === dInfo.ewZ) addEdge(sInfo.ewProj, dInfo.ewProj);
  if (sInfo.nsX === dInfo.nsX) addEdge(sInfo.nsProj, dInfo.nsProj);

  const n = nodes.length;
  const dist = new Float64Array(n).fill(Infinity);
  const prev = new Int32Array(n).fill(-1);
  const visited = new Uint8Array(n);
  dist[sInfo.id] = 0;

  for (let step = 0; step < n; step++) {
    let u = -1;
    let best = Infinity;
    for (let i = 0; i < n; i++) {
      if (!visited[i] && dist[i] < best) {
        best = dist[i];
        u = i;
      }
    }
    if (u === -1 || u === dInfo.id) break;
    visited[u] = 1;

    const edges = adj[u];
    for (let j = 0; j < edges.length; j++) {
      const e = edges[j];
      if (visited[e.to]) continue;
      const nd = dist[u] + e.cost;
      if (nd < dist[e.to]) {
        dist[e.to] = nd;
        prev[e.to] = u;
      }
    }
  }

  const rawPath: GpsPoint[] = [];
  let cur = dInfo.id;
  while (cur !== -1) {
    rawPath.push(nodes[cur]);
    cur = prev[cur];
  }
  rawPath.reverse();

  if (rawPath.length < 2) {
    return [
      { x: startX, z: startZ },
      { x: destX, z: destZ },
    ];
  }

  const cleaned: GpsPoint[] = [rawPath[0]];
  for (let i = 1; i < rawPath.length; i++) {
    const last = cleaned[cleaned.length - 1];
    if (Math.hypot(rawPath[i].x - last.x, rawPath[i].z - last.z) > 2.0) {
      cleaned.push(rawPath[i]);
    }
  }
  if (cleaned.length === 1) {
    cleaned.push({ x: destX, z: destZ });
  }
  return cleaned;
}

// ============================================================================
// JAIPUR CITY LOCALITIES & LANDMARKS
// ============================================================================
export interface JaipurLocalityInfo {
  id: string;
  name: string;
  subtitle: string;
  zone: JaipurZone;
  majorHub?: boolean;
  x: number;
  z: number;
  mapX: number;
  mapY: number;
  accent: string;
}

export function worldToJaipurMapPct(wx: number, wz: number): { mapX: number; mapY: number } {
  return {
    mapX: Math.round((6 + ((wx + 1500) / 3000) * 88) * 10) / 10,
    mapY: Math.round((6 + ((wz + 1500) / 3000) * 88) * 10) / 10,
  };
}

function makeLocality(
  id: string,
  name: string,
  subtitle: string,
  zone: JaipurZone,
  x: number,
  z: number,
  accent: string,
  majorHub = false,
): JaipurLocalityInfo {
  const { mapX, mapY } = worldToJaipurMapPct(x, z);
  return { id, name, subtitle, zone, majorHub, x, z, mapX, mapY, accent };
}

export const JAIPUR_LOCALITIES: JaipurLocalityInfo[] = [
  makeLocality('hawa_mahal', 'Hawa Mahal · Badi Chaupar', 'Palace of Winds & Pink Metro Terminus', 'Walled Pink City', 160, -210, '#ec4899', true),
  makeLocality('city_palace', 'City Palace & Jantar Mantar', 'Chandra Mahal & Samrat Yantra Sundial', 'Walled Pink City', 42, -250, '#f43f5e', true),
  makeLocality('tripolia', 'Tripolia Bazaar & Gate', 'Copper Market & Royal Heritage Axis', 'Walled Pink City', -40, -210, '#fb7185'),
  makeLocality('choti_chaupar', 'Choti Chaupar · Chandpole', 'Western Walled Gate & Metro Plaza', 'Walled Pink City', -240, -210, '#f472b6', true),
  makeLocality('johari_bazaar', 'Johari & Bapu Bazaar', 'LMB Sweets, Jewelry & Sanganeri Gate', 'Walled Pink City', 160, -90, '#f59e0b', true),
  makeLocality('ramganj', 'Ramganj & Surajpole', 'Eastern Pink City Gate & Heritage Havelis', 'Walled Pink City', 420, -210, '#ec4899'),
  makeLocality('ghat_gate', 'Ghat Gate · Fire Brigade HQ', 'Jaipur Fire Tenders & Central Market', 'Walled Pink City', 485, -15, '#ef4444', true),
  makeLocality('ajmeri_gate', 'Ajmeri Gate · New Colony', 'Walled City Main Entry & Cloth Houses', 'Walled Pink City', -60, -40, '#f97316'),
  makeLocality('albert_hall', 'Albert Hall & Ram Niwas', 'Indo-Saracenic Museum & Zoo Park', 'Central · MI Road', 160, 140, '#eab308', true),
  makeLocality('mi_road', 'MI Road · Panch Batti', 'Raj Mandir Cinema, Ammu-Nation & Showrooms', 'Central · MI Road', -60, 140, '#f59e0b', true),
  makeLocality('statue_circle', 'Statue Circle · C-Scheme', 'Sawai Jai Singh Monument, Barber & Cafes', 'Central · MI Road', -240, 140, '#38bdf8', true),
  makeLocality('civil_lines', 'Civil Lines · Raj Bhawan', 'Governor House & Tree-Lined Avenue', 'Central · MI Road', -400, 180, '#22c55e'),
  makeLocality('jaipur_junction', 'Jaipur Junction Railway', 'Main Rail Terminus & Express Trains', 'Central · MI Road', -480, 248, '#60a5fa', true),
  makeLocality('central_park', 'Central Park · Birla Mandir', 'Polo Lawn, Jogging Track & Marble Temple', 'Central · MI Road', 85, 455, '#34d399', true),
  makeLocality('sms_stadium', 'SMS Cricket Stadium', 'Sawai Mansingh Stadium & Floodlights', 'Central · MI Road', 290, 455, '#22c55e', true),
  makeLocality('vidhan_sabha', 'Vidhan Sabha · Lal Kothi', 'Rajasthan Assembly Dome & Tonk Phatak', 'Central · MI Road', -60, 440, '#a855f7'),
  makeLocality('jal_mahal', 'Jal Mahal · Man Sagar Lake', 'Water Palace & Amer Road Promenade', 'North · Amer', 220, -760, '#06b6d4', true),
  makeLocality('amer_fort', 'Amer Fort & Maota Ridge', 'Amber Citadel & Stepwell Ascent', 'North · Amer', 190, -960, '#f59e0b', true),
  makeLocality('nahargarh', 'Nahargarh Fort Ridge', 'Skyline Hilltop Bastion overlooking Jaipur', 'North · Amer', -160, -960, '#fb923c', true),
  makeLocality('vidyadhar', 'Vidyadhar Nagar · Stadium', 'Planned Northern Sectors, Schools & DMart', 'North · Amer', -480, -560, '#38bdf8'),
  makeLocality('bani_park', 'Bani Park', 'Heritage Haveli Hotels & Collectorate', 'West · Vaishali', -480, -210, '#818cf8'),
  makeLocality('jhotwara', 'Jhotwara & VKI Industrial', 'Western Ring, Factories & Showrooms', 'West · Vaishali', -760, -560, '#94a3b8'),
  makeLocality('vaishali_nagar', 'Vaishali Nagar · Chitrakoot', 'Chitrakoot Stadium, Decathlon & Shopping', 'West · Vaishali', -760, 140, '#3b82f6', true),
  makeLocality('bypass_200ft', '200 Ft Bypass · Ajmer Rd', 'Western Expressway Circle & Transport Hub', 'West · Vaishali', -1020, 140, '#60a5fa'),
  makeLocality('mansarovar', 'Mansarovar · City Park', 'Wide Grid Avenues, Metro & DMart', 'West · Vaishali', -480, 740, '#14b8a6', true),
  makeLocality('raja_park', 'Raja Park & Adarsh Nagar', 'Fashion Street, Cloth Stores & Food', 'East · Agra Rd', 420, 140, '#fb7185', true),
  makeLocality('galtaji', 'Galtaji Monkey Pass · Agra Rd', 'Aravalli Gorge Temple & Transport Nagar', 'East · Agra Rd', 760, -210, '#f97316'),
  makeLocality('malviya_wtp', 'Malviya Nagar & WTP', 'World Trade Park, JKK & Gaurav Tower', 'South · JLN & Airport', 420, 580, '#0ea5e9', true),
  makeLocality('dravyavati', 'Dravyavati Cable Flyover', 'Elevated Tonk Rd Riverfront Bridge', 'South · JLN & Airport', -60, 710, '#22d3ee', true),
  makeLocality('jawahar_circle', 'Jawahar Circle · Patrika Gate', 'Rainbow Archways & Asia’s Largest Circular Park', 'South · JLN & Airport', 160, 840, '#f43f5e', true),
  makeLocality('sanganer_airport', "Jaipur Int'l Airport (JAI)", 'Sanganer Runway 09/27 & Private Jet', 'South · JLN & Airport', 240, 1110, '#0284c7', true),
  makeLocality('jagatpura', 'Jagatpura · Mahal Rd', 'Southeast Ring Expressway & Tech Colleges', 'South · JLN & Airport', 760, 580, '#10b981'),
  makeLocality('sitapura', 'Sitapura Industrial & JECC', 'Southern Tech Park, Showrooms & Convention Center', 'South · JLN & Airport', 760, 1060, '#8b5cf6'),
];

export function getNearestJaipurLocality(x: number, z: number): JaipurLocalityInfo {
  let best = JAIPUR_LOCALITIES[0];
  let bestD2 = Infinity;
  for (let i = 0; i < JAIPUR_LOCALITIES.length; i++) {
    const loc = JAIPUR_LOCALITIES[i];
    const d2 = (x - loc.x) ** 2 + (z - loc.z) ** 2;
    if (d2 < bestD2) {
      bestD2 = d2;
      best = loc;
    }
  }
  return best;
}

export interface DistrictInfo {
  id: DistrictId;
  name: string;
  subtitle: string;
  division: string;
  x: number;
  z: number;
  accent: string;
}

export const JAIPUR_DISTRICT_INFO: DistrictInfo = {
  id: 'jaipur',
  name: 'Little Jaipur',
  subtitle: 'Pink City · Amer to Sanganer · A to Z',
  division: 'Jaipur Metro',
  x: 160,
  z: -140,
  accent: '#ec4899',
};

export function resolveRajasthanDistrict(_id?: string): DistrictInfo {
  return JAIPUR_DISTRICT_INFO;
}

export type MissionType = 'race' | 'smash' | 'stunt' | 'survival';

export interface MissionDef {
  id: string;
  title: string;
  district: DistrictId;
  type: MissionType;
  briefing: string;
  rewardCash: number;
  rewardRep: number;
  timeLimitSec: number;
  targetCount: number;
  waypoints: Array<{ x: number; z: number; label: string }>;
}

export const MISSIONS_CATALOG: MissionDef[] = [
  {
    id: 'jaipur_stunt',
    title: 'Pink City Chaupar Run',
    district: 'jaipur',
    type: 'stunt',
    briefing: 'Circle through Ajmeri Gate, Sanganeri Gate, Badi Chaupar & Surajpole Gate in one Pink City run.',
    rewardCash: 95000,
    rewardRep: 1850,
    timeLimitSec: 115,
    targetCount: 4,
    waypoints: [
      { x: -60, z: -40, label: 'Ajmeri Gate Circle' },
      { x: 160, z: -40, label: 'Sanganeri Gate Circle' },
      { x: 160, z: -210, label: 'Hawa Mahal · Badi Chaupar' },
      { x: 420, z: -210, label: 'Surajpole Gate' },
    ],
  },
  {
    id: 'jaisalmer_gold',
    title: 'Amer Fort & Jal Mahal Sprint',
    district: 'jaipur',
    type: 'race',
    briefing: 'Carve north up Amer Road past Jal Mahal & Man Sagar Lake to Amer Fort and Nahargarh Ridge.',
    rewardCash: 135000,
    rewardRep: 2400,
    timeLimitSec: 135,
    targetCount: 4,
    waypoints: [
      { x: 160, z: -380, label: 'Zorawar Singh Gate' },
      { x: 160, z: -760, label: 'Jal Mahal Lakeside' },
      { x: 160, z: -960, label: 'Amer Fort Plaza' },
      { x: -160, z: -960, label: 'Nahargarh Ridge Finish' },
    ],
  },
  {
    id: 'kota_smash',
    title: 'Johari Bazaar Demolition Blitz',
    district: 'jaipur',
    type: 'smash',
    briefing: 'Smash 12 bazaar stalls, streetlamps, or bollards around Johari & Bapu Bazaar.',
    rewardCash: 85000,
    rewardRep: 1500,
    timeLimitSec: 95,
    targetCount: 12,
    waypoints: [{ x: 160, z: -120, label: 'Johari Bazaar' }],
  },
  {
    id: 'udaipur_lake',
    title: 'JLN Marg, SMS Stadium & WTP Circuit',
    district: 'jaipur',
    type: 'race',
    briefing: 'Race past Albert Hall, SMS Cricket Stadium, World Trade Park, Patrika Gate & Jaipur Airport.',
    rewardCash: 120000,
    rewardRep: 2100,
    timeLimitSec: 140,
    targetCount: 4,
    waypoints: [
      { x: 160, z: 140, label: 'Albert Hall Circle' },
      { x: 290, z: 455, label: 'SMS Cricket Stadium' },
      { x: 420, z: 580, label: 'World Trade Park (WTP)' },
      { x: 160, z: 840, label: 'Patrika Gate · Jawahar Circle' },
    ],
  },
  {
    id: 'rajasthan_cannonball',
    title: 'Grand Jaipur Ring Cannonball',
    district: 'jaipur',
    type: 'race',
    briefing: 'Circle all of Little Jaipur: Jaipur Junction -> 200 Ft Bypass -> Mansarovar -> WTP -> Amer!',
    rewardCash: 280000,
    rewardRep: 5500,
    timeLimitSec: 210,
    targetCount: 5,
    waypoints: [
      { x: -480, z: 140, label: 'Jaipur Junction' },
      { x: -1020, z: 140, label: '200 Ft Bypass Circle' },
      { x: -480, z: 840, label: 'Mansarovar Ring' },
      { x: 420, z: 580, label: 'Malviya Nagar · WTP' },
      { x: 160, z: -960, label: 'Amer Fort Summit' },
    ],
  },
  {
    id: 'chopper_survival',
    title: 'MI Road Chopper Survival',
    district: 'jaipur',
    type: 'survival',
    briefing: 'Survive a 4-star Jaipur Police Helicopter pursuit during monsoon storm for 45s or shoot it down!',
    rewardCash: 175000,
    rewardRep: 3500,
    timeLimitSec: 45,
    targetCount: 45,
    waypoints: [{ x: -60, z: 140, label: 'MI Road Chase' }],
  },
];

export type FacilityType = 'bank' | 'hospital' | 'home' | 'airport';

export interface FacilityDef {
  id: string;
  type: FacilityType;
  name: string;
  subtitle: string;
  district: DistrictId;
  x: number;
  z: number;
  entryX: number;
  entryZ: number;
  accent: string;
}

export const WORLD_FACILITIES: FacilityDef[] = [
  {
    id: 'home_jaipur',
    type: 'home',
    name: 'C-Scheme Royal Haveli (Home)',
    subtitle: 'Player Home · Rest, Save, Clear Heat & Upgrade Estate',
    district: 'jaipur',
    x: -292,
    z: 200,
    entryX: -264,
    entryZ: 200,
    accent: '#f59e0b',
  },
  {
    id: 'bank_jaipur',
    type: 'bank',
    name: 'State Bank of Jaipur (MI Rd)',
    subtitle: 'Safe Deposit Vault, Withdrawals, Interest & Heist',
    district: 'jaipur',
    x: 24,
    z: 190,
    entryX: 52,
    entryZ: 190,
    accent: '#10b981',
  },
  {
    id: 'bank_vaishali',
    type: 'bank',
    name: 'Amrapali Cooperative Bank',
    subtitle: 'Vaishali Nagar Branch · Vault, Transfers & Heist',
    district: 'jaipur',
    x: -808,
    z: 190,
    entryX: -780,
    entryZ: 190,
    accent: '#10b981',
  },
  {
    id: 'bank_malviya',
    type: 'bank',
    name: 'WTP Commercial Vault Bank',
    subtitle: 'Malviya Nagar Branch · Vault, Transfers & Heist',
    district: 'jaipur',
    x: 372,
    z: 632,
    entryX: 400,
    entryZ: 632,
    accent: '#10b981',
  },
  {
    id: 'hospital_sms',
    type: 'hospital',
    name: 'SMS Medical Hospital (JLN)',
    subtitle: '24x7 Emergency Heal & Max Health Trauma Upgrades',
    district: 'jaipur',
    x: 208,
    z: 205,
    entryX: 180,
    entryZ: 205,
    accent: '#ef4444',
  },
  {
    id: 'hospital_vaishali',
    type: 'hospital',
    name: 'Vaishali Metro Trauma Center',
    subtitle: 'West Jaipur Emergency Care & Max Health Upgrades',
    district: 'jaipur',
    x: -712,
    z: 205,
    entryX: -740,
    entryZ: 205,
    accent: '#ef4444',
  },
  {
    id: 'hospital_malviya',
    type: 'hospital',
    name: 'EHCC Malviya Hospital',
    subtitle: 'South Jaipur Emergency Care & Max Health Upgrades',
    district: 'jaipur',
    x: 372,
    z: 755,
    entryX: 400,
    entryZ: 755,
    accent: '#ef4444',
  },
  {
    id: 'airport_jaipur',
    type: 'airport',
    name: "Jaipur Int'l Airport (JAI)",
    subtitle: 'Sanganer Runway 09/27 · Charter Flights & Flyable Private Jet',
    district: 'jaipur',
    x: 240,
    z: 1125,
    entryX: 240,
    entryZ: 1095,
    accent: '#0ea5e9',
  },
];

export interface PlayerSaveData {
  userId: string;
  displayName: string;
  cash: number;
  bankBalance: number;
  maxHealth: number;
  homeLevel: number;
  reputation: number;
  selectedVehicle: VehicleId;
  vehicleColor: string;
  selectedWeapon: WeaponId;
  unlockedWeapons: WeaponId[];
  characterConfig: CharacterConfig;
  unlockedVehicles: VehicleId[];
  completedMissions: string[];
  destructiblesSmashed: number;
  topSpeedKmh: number;
  lastDistrict: DistrictId;
  weatherPref: WeatherMode;
  graphicsPreset: GraphicsPreset;
}

export interface LeaderboardEntry {
  userId: string;
  displayName: string;
  reputation: number;
  topSpeedKmh: number;
  destructiblesSmashed: number;
  selectedVehicle: VehicleId;
}

export interface LobbySummary {
  shardId: string;
  baseId: string;
  label: string;
  district: string;
  region: string;
  players: number;
  capacity: number;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

export interface RemotePeerState {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  speed: number;
  vehicleId: VehicleId;
  vehicleColor: string;
  onFoot: boolean;
  wantedLevel: number;
  characterConfig: CharacterConfig;
}

export const POLICE_STATION = {
  name: 'Jaipur Police Commissionerate HQ',
  x: -10,
  z: 48,
  gateX: -10,
  gateZ: 82,
  gateYaw: 0,
} as const;

export interface ActiveJobTelemetry {
  type: JobType;
  title: string;
  stageLabel: string;
  rewardCash: number;
  timeLeftSec: number;
  stepProgress: number;
  stepTarget: number;
}

export interface LiveTelemetry {
  speedKmh: number;
  rpmRatio: number;
  gear: number;
  nitro: number;
  fuel: number;
  armor: number;
  onFoot: boolean;
  inAircraft: boolean;
  altitudeM: number;
  wantedLevel: number;
  bustedProgress: number;
  health: number;
  maxHealth: number;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  currentDistrict: DistrictId;
  currentLocalityName: string;
  currentZoneName: string;
  selectedWeapon: WeaponId;
  nearbyFacilityId: string | null;
  nearbyBuilding: EnterableBuildingInfo | null;
  signalState: 'GREEN' | 'AMBER' | 'RED' | null;
  activeMissionId: string | null;
  missionLabel: string | null;
  missionProgress: number;
  missionTarget: number;
  missionTimeLeft: number;
  activeJob: ActiveJobTelemetry | null;
  activeFireCount: number;
  canEnterVehicle: boolean;
  airtimeSec: number;
  driftScore: number;
  policeCount: number;
  helicopterCount: number;
}

export const DEFAULT_CHARACTER_CONFIG: CharacterConfig = {
  archetype: 'royal',
  outfitColor: '#f59e0b',
  skinTone: '#c68642',
  headgear: 'turban',
  eyewear: 'aviators',
};

export const DEFAULT_SAVE_DATA: PlayerSaveData = {
  userId: 'guest',
  displayName: 'Jaipur Driver',
  cash: 150000,
  bankBalance: 50000,
  maxHealth: 100,
  homeLevel: 1,
  reputation: 0,
  selectedVehicle: 'ferrari_sf90',
  vehicleColor: '#d91616',
  selectedWeapon: 'pistol',
  unlockedWeapons: ['fists', 'pistol', 'smg'],
  characterConfig: DEFAULT_CHARACTER_CONFIG,
  unlockedVehicles: [
    'ferrari_sf90',
    'lamborghini_svj',
    'mumbai_taxi',
    'swift_hatch',
    'auto_rickshaw',
    'bullet_350',
  ],
  completedMissions: [],
  destructiblesSmashed: 0,
  topSpeedKmh: 0,
  lastDistrict: 'jaipur',
  weatherPref: 'sunset',
  graphicsPreset: 'ultra4k',
};
