import React from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Car, Crosshair, Flame, RefreshCw, Volume2 } from 'lucide-react';
import type { TouchInputState } from '../engine/GameEngine';

interface TouchControlsProps {
  onFoot: boolean;
  inAircraft?: boolean;
  onTouchChange: (patch: Partial<TouchInputState>) => void;
  onToggleVehicle: () => void;
  onCycleWeapon: () => void;
  onHorn: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onFoot,
  inAircraft = false,
  onTouchChange,
  onToggleVehicle,
  onCycleWeapon,
  onHorn,
}) => {
  return (
    <div className="fixed inset-x-0 bottom-16 z-20 px-4 flex items-end justify-between pointer-events-none">
      {/* Left Hand: Steering Pad */}
      <div className="flex items-center gap-3 pointer-events-auto">
        <button
          onPointerDown={() => onTouchChange({ steer: -1 })}
          onPointerUp={() => onTouchChange({ steer: 0 })}
          onPointerLeave={() => onTouchChange({ steer: 0 })}
          onPointerCancel={() => onTouchChange({ steer: 0 })}
          className="w-16 h-16 rounded-xl bg-slate-900/90 border border-slate-600 active:bg-amber-500 active:text-slate-950 text-white flex items-center justify-center shadow-lg"
          aria-label="Steer Left"
        >
          <ArrowLeft className="w-7 h-7" />
        </button>
        <button
          onPointerDown={() => onTouchChange({ steer: 1 })}
          onPointerUp={() => onTouchChange({ steer: 0 })}
          onPointerLeave={() => onTouchChange({ steer: 0 })}
          onPointerCancel={() => onTouchChange({ steer: 0 })}
          className="w-16 h-16 rounded-xl bg-slate-900/90 border border-slate-600 active:bg-amber-500 active:text-slate-950 text-white flex items-center justify-center shadow-lg"
          aria-label="Steer Right"
        >
          <ArrowRight className="w-7 h-7" />
        </button>
      </div>

      {/* Right Hand: Combat, Action & Pedals */}
      <div className="flex flex-col items-end gap-2.5 pointer-events-auto">
        <div className="flex items-center gap-2">
          <button
            onClick={onHorn}
            className="w-11 h-11 rounded-xl bg-slate-900/90 border border-slate-600 active:bg-slate-700 text-slate-200 flex items-center justify-center"
            aria-label="Horn"
          >
            <Volume2 className="w-4 h-4" />
          </button>
          <button
            onClick={onCycleWeapon}
            className="w-11 h-11 rounded-xl bg-slate-900/90 border border-slate-600 active:bg-slate-700 text-amber-300 flex items-center justify-center"
            aria-label="Cycle Weapon"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onPointerDown={() => onTouchChange({ fire: true })}
            onPointerUp={() => onTouchChange({ fire: false })}
            onPointerLeave={() => onTouchChange({ fire: false })}
            onPointerCancel={() => onTouchChange({ fire: false })}
            className="w-14 h-11 rounded-xl bg-orange-600/95 active:bg-orange-400 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-lg"
            aria-label="Fire Weapon"
          >
            <Crosshair className="w-4 h-4" />
            <span>FIRE</span>
          </button>
          <button
            onClick={onToggleVehicle}
            className="w-11 h-11 rounded-xl bg-slate-900/90 border border-amber-500/60 active:bg-amber-500 text-amber-400 active:text-slate-950 flex items-center justify-center"
            aria-label="Enter or Exit Vehicle"
          >
            <Car className="w-5 h-5" />
          </button>
          {inAircraft && (
            <button
              onPointerDown={() => onTouchChange({ handbrake: true })}
              onPointerUp={() => onTouchChange({ handbrake: false })}
              onPointerLeave={() => onTouchChange({ handbrake: false })}
              onPointerCancel={() => onTouchChange({ handbrake: false })}
              className="w-14 h-11 rounded-xl bg-sky-500/95 active:bg-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center shadow-lg"
              aria-label="Climb Aircraft"
            >
              CLIMB
            </button>
          )}
          <button
            onPointerDown={() => onTouchChange({ nitro: true })}
            onPointerUp={() => onTouchChange({ nitro: false })}
            onPointerLeave={() => onTouchChange({ nitro: false })}
            onPointerCancel={() => onTouchChange({ nitro: false })}
            className="w-14 h-11 rounded-xl bg-cyan-500/90 active:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1"
            aria-label="Nitro Boost"
          >
            <Flame className="w-4 h-4" />
            <span>{onFoot ? 'RUN' : 'NOS'}</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            onPointerDown={() => onTouchChange({ brake: 1 })}
            onPointerUp={() => onTouchChange({ brake: 0 })}
            onPointerLeave={() => onTouchChange({ brake: 0 })}
            onPointerCancel={() => onTouchChange({ brake: 0 })}
            className="w-16 h-16 rounded-xl bg-red-600/90 border border-red-400/50 active:bg-red-500 text-white flex items-center justify-center shadow-lg"
            aria-label="Brake or Reverse"
          >
            <ArrowDown className="w-7 h-7" />
          </button>
          <button
            onPointerDown={() => onTouchChange({ throttle: 1 })}
            onPointerUp={() => onTouchChange({ throttle: 0 })}
            onPointerLeave={() => onTouchChange({ throttle: 0 })}
            onPointerCancel={() => onTouchChange({ throttle: 0 })}
            className="w-16 h-20 rounded-xl bg-emerald-500/90 border border-emerald-300/60 active:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-lg"
            aria-label="Accelerate"
          >
            <ArrowUp className="w-8 h-8" />
          </button>
        </div>
      </div>
    </div>
  );
};
