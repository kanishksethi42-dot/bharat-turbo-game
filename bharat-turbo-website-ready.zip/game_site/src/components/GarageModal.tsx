import React from 'react';
import { Check, Lock, X } from 'lucide-react';
import { VEHICLE_CATALOG, type VehicleId } from '../types/game';

interface GarageModalProps {
  cash: number;
  selectedVehicle: VehicleId;
  vehicleColor: string;
  unlockedVehicles: VehicleId[];
  onSelectOrUnlock: (id: VehicleId) => void;
  onChangeColor: (hex: string) => void;
  onClose: () => void;
}

const PAINT_SWATCHES = [
  { name: 'Rosso Corsa', hex: '#d91616' },
  { name: 'Giallo Orion', hex: '#f5b800' },
  { name: 'French Blue', hex: '#1d4ed8' },
  { name: 'Pearl White', hex: '#f8fafc' },
  { name: 'Stealth Carbon', hex: '#1e293b' },
  { name: 'Emerald Jade', hex: '#059669' },
  { name: 'Saffron Sunset', hex: '#ea580c' },
];

export const GarageModal: React.FC<GarageModalProps> = ({
  cash,
  selectedVehicle,
  vehicleColor,
  unlockedVehicles,
  onSelectOrUnlock,
  onChangeColor,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Garage — Hypercars, Local Cars & 2-Wheelers</h2>
            <p className="text-xs text-slate-400">
              Available Balance: <span className="font-mono-num text-emerald-400 font-semibold">₹{cash.toLocaleString('en-IN')}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Paint Finish Picker */}
          <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs font-semibold text-slate-300">Clearcoat Metallic Paint</span>
            <div className="flex flex-wrap items-center gap-2">
              {PAINT_SWATCHES.map((sw) => (
                <button
                  key={sw.hex}
                  title={sw.name}
                  onClick={() => onChangeColor(sw.hex)}
                  style={{ backgroundColor: sw.hex }}
                  className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center cursor-pointer ${
                    vehicleColor.toLowerCase() === sw.hex.toLowerCase() ? 'border-amber-400 scale-110' : 'border-slate-700'
                  }`}
                >
                  {vehicleColor.toLowerCase() === sw.hex.toLowerCase() && (
                    <Check className="w-4 h-4 text-slate-950 drop-shadow" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Vehicle Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {Object.values(VEHICLE_CATALOG).map((v) => {
              const unlocked = unlockedVehicles.includes(v.id);
              const active = selectedVehicle === v.id;
              const canAfford = cash >= v.price;

              return (
                <div
                  key={v.id}
                  className={`p-4 rounded-lg border flex flex-col justify-between gap-3 ${
                    active
                      ? 'bg-amber-500/12 border-amber-400'
                      : 'bg-slate-950/75 border-slate-800'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-amber-400 font-semibold">{v.brand} · {v.category}</span>
                      <span className="font-mono-num text-xs text-slate-300">{v.topSpeedKmh} km/h</span>
                    </div>
                    <h3 className="font-display text-lg font-bold text-white">{v.name}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">{v.description}</p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <div className="text-xs text-slate-400 font-mono-num">
                      Handling {v.handling.toFixed(1)} · Mass {v.mass}kg
                    </div>
                    <button
                      onClick={() => onSelectOrUnlock(v.id)}
                      disabled={!unlocked && !canAfford}
                      className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                        active
                          ? 'bg-emerald-500 text-slate-950'
                          : unlocked
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          : canAfford
                          ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {!unlocked && <Lock className="w-3.5 h-3.5" />}
                      <span>
                        {active
                          ? 'Equipped'
                          : unlocked
                          ? 'Spawn Car'
                          : `Unlock ₹${v.price.toLocaleString('en-IN')}`}
                      </span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
