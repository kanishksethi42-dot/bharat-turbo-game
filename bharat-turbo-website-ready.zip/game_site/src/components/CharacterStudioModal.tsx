import React from 'react';
import { Check, X } from 'lucide-react';
import type {
  CharacterArchetype,
  CharacterConfig,
  CharacterEyewear,
  CharacterHeadgear,
} from '../types/game';

interface CharacterStudioModalProps {
  displayName: string;
  config: CharacterConfig;
  onChangeName: (name: string) => void;
  onChangeConfig: (cfg: CharacterConfig) => void;
  onClose: () => void;
}

const ARCHETYPES: Array<{ id: CharacterArchetype; label: string; desc: string }> = [
  { id: 'racer', label: 'Mumbai Racer', desc: 'Street bomber jacket & trim' },
  { id: 'royal', label: 'Delhi Royal', desc: 'Modern Bandhgala & gold sash' },
  { id: 'cyber', label: 'Bengaluru Cyber', desc: 'Tactical techwear & glowing pack' },
  { id: 'maverick', label: 'Jaipur Maverick', desc: 'Stealth desert racing suit' },
];

const HEADGEAR: Array<{ id: CharacterHeadgear; label: string }> = [
  { id: 'fade', label: 'Slick Fade' },
  { id: 'helmet', label: 'GT Helmet' },
  { id: 'turban', label: 'Royal Turban' },
  { id: 'cap', label: 'Street Cap' },
];

const EYEWEAR: Array<{ id: CharacterEyewear; label: string }> = [
  { id: 'none', label: 'None' },
  { id: 'aviators', label: 'Gold Aviators' },
  { id: 'visor', label: 'Cyber Visor' },
  { id: 'bandana', label: 'Mask Bandana' },
];

const OUTFIT_COLORS = ['#f59e0b', '#dc2626', '#0ea5e9', '#10b981', '#ec4899', '#f8fafc', '#1e293b'];
const SKIN_TONES = ['#f3d2b3', '#d9a77c', '#c68642', '#8d5524', '#5c3818'];

export const CharacterStudioModal: React.FC<CharacterStudioModalProps> = ({
  displayName,
  config,
  onChangeName,
  onChangeConfig,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Character Customizer</h2>
            <p className="text-xs text-slate-400">Your driver appearance syncs across multiplayer lobbies and cloud saves</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Driver Alias */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1.5">Driver Alias</label>
            <input
              type="text"
              maxLength={32}
              value={displayName}
              onChange={(e) => onChangeName(e.target.value)}
              placeholder="Mumbai Driver"
              className="w-full px-3.5 py-2.5 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Archetype */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-2">Outfit Archetype</label>
            <div className="grid grid-cols-2 gap-2.5">
              {ARCHETYPES.map((a) => (
                <button
                  key={a.id}
                  onClick={() => onChangeConfig({ ...config, archetype: a.id })}
                  className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                    config.archetype === a.id
                      ? 'bg-amber-500/15 border-amber-400 text-white'
                      : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <div className="text-sm font-semibold">{a.label}</div>
                  <div className="text-xs text-slate-400">{a.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Colors: Outfit & Skin Tone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">Outfit Color</label>
              <div className="flex flex-wrap gap-2">
                {OUTFIT_COLORS.map((hex) => (
                  <button
                    key={hex}
                    onClick={() => onChangeConfig({ ...config, outfitColor: hex })}
                    style={{ backgroundColor: hex }}
                    className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center cursor-pointer ${
                      config.outfitColor.toLowerCase() === hex.toLowerCase() ? 'border-white scale-105' : 'border-slate-700'
                    }`}
                  >
                    {config.outfitColor.toLowerCase() === hex.toLowerCase() && (
                      <Check className="w-4 h-4 text-slate-950 drop-shadow" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">Skin Tone</label>
              <div className="flex flex-wrap gap-2">
                {SKIN_TONES.map((hex) => (
                  <button
                    key={hex}
                    onClick={() => onChangeConfig({ ...config, skinTone: hex })}
                    style={{ backgroundColor: hex }}
                    className={`w-8 h-8 rounded-lg border-2 flex items-center justify-center cursor-pointer ${
                      config.skinTone.toLowerCase() === hex.toLowerCase() ? 'border-white scale-105' : 'border-slate-700'
                    }`}
                  >
                    {config.skinTone.toLowerCase() === hex.toLowerCase() && (
                      <Check className="w-4 h-4 text-slate-950" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Headgear & Eyewear */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">Headgear</label>
              <div className="grid grid-cols-2 gap-2">
                {HEADGEAR.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => onChangeConfig({ ...config, headgear: h.id })}
                    className={`px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer ${
                      config.headgear === h.id
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-semibold'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    {h.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-2">Eyewear / Mask</label>
              <div className="grid grid-cols-2 gap-2">
                {EYEWEAR.map((ew) => (
                  <button
                    key={ew.id}
                    onClick={() => onChangeConfig({ ...config, eyewear: ew.id })}
                    className={`px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer ${
                      config.eyewear === ew.id
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-semibold'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    {ew.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold cursor-pointer"
          >
            Save & Apply
          </button>
        </div>
      </div>
    </div>
  );
};
