import React from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  CarFront,
  HeartPulse,
  Home,
  Landmark,
  Plane,
  ShieldCheck,
  Sparkles,
  UserCog,
  X,
} from 'lucide-react';
import { JAIPUR_LOCALITIES, WORLD_FACILITIES, type FacilityDef } from '../types/game';

interface FacilityModalProps {
  facility: FacilityDef;
  cash: number;
  bankBalance: number;
  health: number;
  maxHealth: number;
  homeLevel: number;
  wantedLevel: number;
  onBankDeposit: (amount: number) => void;
  onBankWithdraw: (amount: number) => void;
  onClaimBankInterest: () => void;
  onHospitalHeal: () => void;
  onHospitalUpgradeMaxHp: () => void;
  onHomeRest: () => void;
  onHomeUpgrade: () => void;
  onOpenGarage: () => void;
  onOpenCharacter: () => void;
  onBoardAirportJet: () => void;
  onCharterFlight: (x: number, z: number, label: string, cost: number) => void;
  onClose: () => void;
}

export const FacilityModal: React.FC<FacilityModalProps> = ({
  facility,
  cash,
  bankBalance,
  health,
  maxHealth,
  homeLevel,
  wantedLevel,
  onBankDeposit,
  onBankWithdraw,
  onClaimBankInterest,
  onHospitalHeal,
  onHospitalUpgradeMaxHp,
  onHomeRest,
  onHomeUpgrade,
  onOpenGarage,
  onOpenCharacter,
  onBoardAirportJet,
  onCharterFlight,
  onClose,
}) => {
  const interestYield = Math.max(500, Math.round(bankBalance * 0.025));
  const healCost = cash >= 500 ? 500 : 0;
  const maxHpUpgradeCost = 18000;
  const canUpgradeMaxHp = maxHealth < 200;

  const nextHomeLevel = homeLevel + 1;
  const homeUpgradeCost = homeLevel === 1 ? 65000 : homeLevel === 2 ? 140000 : 0;
  const rentPayout = homeLevel * 7500;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/88">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
              style={{ backgroundColor: `${facility.accent}22`, border: `1px solid ${facility.accent}66` }}
            >
              {facility.type === 'bank' && <Landmark className="w-5 h-5 text-emerald-400" />}
              {facility.type === 'hospital' && <HeartPulse className="w-5 h-5 text-red-400" />}
              {facility.type === 'home' && <Home className="w-5 h-5 text-amber-400" />}
              {facility.type === 'airport' && <Plane className="w-5 h-5 text-sky-400" />}
            </div>
            <div>
              <h2 className="font-display text-lg sm:text-xl font-bold text-white">{facility.name}</h2>
              <p className="text-xs text-slate-400">{facility.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            aria-label="Close Facility"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Balances */}
        <div className="grid grid-cols-3 gap-2 px-6 py-3 bg-slate-950/70 border-b border-slate-800 text-xs">
          <div>
            <div className="text-slate-400">Pocket Cash</div>
            <div className="font-mono-num font-bold text-emerald-400 text-sm">
              ₹{cash.toLocaleString('en-IN')}
            </div>
          </div>
          <div>
            <div className="text-slate-400">Bank Vault</div>
            <div className="font-mono-num font-bold text-cyan-400 text-sm">
              ₹{bankBalance.toLocaleString('en-IN')}
            </div>
          </div>
          <div>
            <div className="text-slate-400">Player Health</div>
            <div className="font-mono-num font-bold text-rose-400 text-sm">
              {health} / {maxHealth} HP
            </div>
          </div>
        </div>

        {/* Body by Facility Type */}
        <div className="p-6 space-y-4">
          {facility.type === 'bank' && (
            <>
              <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-200 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Funds stored in your Bank Vault are 100% protected from police fines and hospital bills.
                </span>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Deposit Cash to Vault</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[10000, 50000].map((amt) => (
                    <button
                      key={`dep-${amt}`}
                      disabled={cash < amt}
                      onClick={() => onBankDeposit(amt)}
                      className="py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-mono-num font-semibold text-white cursor-pointer"
                    >
                      +₹{amt.toLocaleString('en-IN')}
                    </button>
                  ))}
                  <button
                    disabled={cash <= 0}
                    onClick={() => onBankDeposit(cash)}
                    className="py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-xs font-semibold text-white cursor-pointer"
                  >
                    Deposit All
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <ArrowDownLeft className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Withdraw to Pocket</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[10000, 50000].map((amt) => (
                    <button
                      key={`wd-${amt}`}
                      disabled={bankBalance < amt}
                      onClick={() => onBankWithdraw(amt)}
                      className="py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-mono-num font-semibold text-white cursor-pointer"
                    >
                      -₹{amt.toLocaleString('en-IN')}
                    </button>
                  ))}
                  <button
                    disabled={bankBalance <= 0}
                    onClick={() => onBankWithdraw(bankBalance)}
                    className="py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-xs font-semibold text-white cursor-pointer"
                  >
                    Withdraw All
                  </button>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-semibold text-white">Vault Fixed-Deposit Return (+2.5%)</div>
                  <div className="text-[11px] text-slate-400">
                    Collect +₹{interestYield.toLocaleString('en-IN')} directly into your Bank Vault
                  </div>
                </div>
                <button
                  onClick={onClaimBankInterest}
                  className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                >
                  Collect +₹{interestYield.toLocaleString('en-IN')}
                </button>
              </div>
            </>
          )}

          {facility.type === 'hospital' && (
            <>
              <div className="p-4 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-white">Emergency Full Trauma Heal</div>
                  <div className="text-xs text-slate-400">
                    Restore health immediately to {maxHealth} / {maxHealth} HP
                  </div>
                </div>
                <button
                  disabled={health >= maxHealth}
                  onClick={onHospitalHeal}
                  className="px-4 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-45 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                >
                  {health >= maxHealth ? 'Full HP' : healCost > 0 ? `Heal (₹${healCost})` : 'Free Heal'}
                </button>
              </div>

              <div className="p-4 rounded-lg bg-slate-950/70 border border-red-500/35 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Stamina & Armor Boost (+25 Max HP)</span>
                  </div>
                  <div className="text-xs text-slate-400">
                    Permanently increase Max Health from {maxHealth} HP up to 200 HP
                  </div>
                </div>
                <button
                  disabled={!canUpgradeMaxHp || cash < maxHpUpgradeCost}
                  onClick={onHospitalUpgradeMaxHp}
                  className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-45 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                >
                  {canUpgradeMaxHp ? `Upgrade · ₹${maxHpUpgradeCost.toLocaleString('en-IN')}` : 'Maxed (200 HP)'}
                </button>
              </div>
            </>
          )}

          {facility.type === 'home' && (
            <>
              <div className="p-4 rounded-lg bg-slate-950/70 border border-amber-500/35 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-white">
                    Rest in Haveli Safehouse (Tier {homeLevel}/3)
                  </div>
                  <div className="text-xs text-slate-400">
                    Full Heal, Refill Nitro, Cloud Save{wantedLevel > 0 ? ', Clear Police Heat' : ''} & +₹
                    {rentPayout.toLocaleString('en-IN')} Estate Income
                  </div>
                </div>
                <button
                  onClick={onHomeRest}
                  className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                >
                  Rest & Collect
                </button>
              </div>

              <div className="p-4 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-white">
                    {homeLevel < 3
                      ? `Upgrade Estate to Tier ${nextHomeLevel}`
                      : 'Royal Haveli Estate Maxed (Tier 3)'}
                  </div>
                  <div className="text-xs text-slate-400">
                    {homeLevel < 3
                      ? 'Increases passive estate payout (+₹7,500) & grants +25 permanent Max Health'
                      : 'Maximum passive payout & royal safehouse defense active'}
                  </div>
                </div>
                <button
                  disabled={homeLevel >= 3 || cash < homeUpgradeCost}
                  onClick={onHomeUpgrade}
                  className="px-4 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-45 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                >
                  {homeLevel < 3 ? `₹${homeUpgradeCost.toLocaleString('en-IN')}` : 'Tier 3 Max'}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  onClick={onOpenGarage}
                  className="py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CarFront className="w-4 h-4 text-red-400" />
                  <span>Open Home Garage</span>
                </button>
                <button
                  onClick={onOpenCharacter}
                  className="py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center justify-center gap-2 cursor-pointer"
                >
                  <UserCog className="w-4 h-4 text-amber-400" />
                  <span>Wardrobe & Avatar</span>
                </button>
              </div>
            </>
          )}

          {facility.type === 'airport' && (
            <>
              <div className="p-4 rounded-lg bg-sky-950/40 border border-sky-500/40 flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Plane className="w-4 h-4 text-sky-400" />
                    <span>Board & Fly Private Jet (Runway 09/27)</span>
                  </div>
                  <div className="text-xs text-slate-300 mt-0.5">
                    Accelerate with [W], press [Space] to climb over Jaipur, [S] to descend/land, [F] near ground to exit.
                  </div>
                </div>
                <button
                  onClick={onBoardAirportJet}
                  className="px-4 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                >
                  Fly Jet
                </button>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300">
                  Jaipur Express Charter ({cash >= 1500 ? '₹1,500' : 'Free Standby'})
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    {
                      label: 'Jaipur Airport (JAI)',
                      x: WORLD_FACILITIES.find((f) => f.id === 'airport_jaipur')!.entryX,
                      z: WORLD_FACILITIES.find((f) => f.id === 'airport_jaipur')!.entryZ,
                    },
                    ...['hawa_mahal', 'amer_fort', 'nahargarh', 'jal_mahal', 'mi_road', 'malviya_wtp', 'vaishali_nagar', 'mansarovar'].map(
                      (id) => {
                        const loc = JAIPUR_LOCALITIES.find((l) => l.id === id) || JAIPUR_LOCALITIES[0];
                        return {
                          label: loc.name.split(' · ')[0],
                          x: loc.x,
                          z: loc.z,
                        };
                      },
                    ),
                  ].map((dest) => {
                    const fee = cash >= 1500 ? 1500 : 0;
                    return (
                      <button
                        key={dest.label}
                        onClick={() => onCharterFlight(dest.x, dest.z, dest.label, fee)}
                        className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-left text-xs font-medium text-white cursor-pointer border border-slate-700/80"
                      >
                        <div className="truncate font-semibold">{dest.label}</div>
                        <div className="text-[10px] text-sky-400 font-mono-num">
                          {fee > 0 ? `Fly · ₹${fee.toLocaleString('en-IN')}` : 'Fly Free'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
