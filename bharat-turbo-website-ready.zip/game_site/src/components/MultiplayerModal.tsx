import React, { useEffect, useState } from 'react';
import { Cloud, CloudOff, LogOut, RefreshCw, Send, Trophy, Users, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import type { ChatMessage, LeaderboardEntry, LobbySummary } from '../types/game';

interface MultiplayerModalProps {
  user: User | null;
  connected: boolean;
  currentShardId: string;
  shardPlayers: number;
  totalConcurrent: number;
  lobbies: LobbySummary[];
  chatMessages: ChatMessage[];
  leaderboard: LeaderboardEntry[];
  syncStatus: string;
  onRefreshLobbies: () => void;
  onSwitchShard: (shardId: string) => void;
  onSendChat: (text: string) => void;
  onGoogleSignIn: () => void;
  onSignOut: () => void;
  onForceCloudSync: () => void;
  onClose: () => void;
}

export const MultiplayerModal: React.FC<MultiplayerModalProps> = ({
  user,
  connected,
  currentShardId,
  shardPlayers,
  totalConcurrent,
  lobbies,
  chatMessages,
  leaderboard,
  syncStatus,
  onRefreshLobbies,
  onSwitchShard,
  onSendChat,
  onGoogleSignIn,
  onSignOut,
  onForceCloudSync,
  onClose,
}) => {
  const [tab, setTab] = useState<'lobbies' | 'cloud' | 'leaderboard'>('lobbies');
  const [chatText, setChatText] = useState('');

  useEffect(() => {
    onRefreshLobbies();
  }, [onRefreshLobbies]);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatText.trim()) return;
    onSendChat(chatText.trim());
    setChatText('');
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Multiplayer Shards & Cross-Platform Cloud Save</h2>
            <p className="text-xs text-slate-400 font-mono-num">
              {connected ? 'WebSocket Connected' : 'Reconnecting...'} · Shard {currentShardId} ({shardPlayers} here) · {totalConcurrent} Total Concurrent Players
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Segmented Tabs */}
        <div className="px-6 pt-3 pb-2 border-b border-slate-800 flex items-center gap-2">
          <button
            onClick={() => setTab('lobbies')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              tab === 'lobbies' ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-slate-300 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Sharded Lobbies & Chat</span>
          </button>
          <button
            onClick={() => setTab('cloud')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              tab === 'cloud' ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-slate-300 hover:text-white'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>Cross-Platform Save</span>
          </button>
          <button
            onClick={() => setTab('leaderboard')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              tab === 'leaderboard' ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-slate-300 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>Global Rankings</span>
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">
          {tab === 'lobbies' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
              <div className="md:col-span-7 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Regional India Shards (AOI Spatial Sync)</h3>
                  <button
                    onClick={onRefreshLobbies}
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {lobbies.map((l) => {
                    const isCurrent = l.shardId === currentShardId;
                    return (
                      <div
                        key={l.shardId}
                        className={`p-3.5 rounded-lg border flex items-center justify-between gap-3 ${
                          isCurrent ? 'bg-cyan-500/12 border-cyan-400' : 'bg-slate-950/75 border-slate-800'
                        }`}
                      >
                        <div>
                          <div className="text-sm font-semibold text-white">{l.label}</div>
                          <div className="text-xs text-slate-400 font-mono-num">
                            {l.shardId} · {l.region} · {l.players}/{l.capacity} Players
                          </div>
                        </div>
                        <button
                          onClick={() => onSwitchShard(l.shardId)}
                          disabled={isCurrent}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                            isCurrent
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                              : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                          }`}
                        >
                          {isCurrent ? 'Joined' : 'Join Shard'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="md:col-span-5 flex flex-col bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 min-h-[260px]">
                <div className="text-xs font-semibold text-slate-400 pb-2 border-b border-slate-800">
                  Shard Radio Chat ({currentShardId})
                </div>
                <div className="flex-1 overflow-y-auto py-2.5 space-y-2 text-xs">
                  {chatMessages.length === 0 ? (
                    <p className="text-slate-500">No messages in this shard yet. Say hello to nearby drivers!</p>
                  ) : (
                    chatMessages.map((m) => (
                      <div key={m.id} className="leading-snug">
                        <span className="font-semibold text-amber-400">{m.senderName}: </span>
                        <span className="text-slate-200">{m.text}</span>
                      </div>
                    ))
                  )}
                </div>
                <form onSubmit={handleChatSubmit} className="flex items-center gap-2 pt-2 border-t border-slate-800">
                  <input
                    type="text"
                    value={chatText}
                    onChange={(e) => setChatText(e.target.value)}
                    maxLength={140}
                    placeholder="Broadcast to shard..."
                    className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    className="p-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer"
                    aria-label="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          )}

          {tab === 'cloud' && (
            <div className="space-y-4 max-w-xl">
              <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {user ? <Cloud className="w-5 h-5 text-emerald-400" /> : <CloudOff className="w-5 h-5 text-slate-400" />}
                    <div>
                      <div className="text-sm font-semibold text-white">
                        {user ? `Signed in as ${user.displayName || user.email}` : 'Playing in Local Device Mode'}
                      </div>
                      <div className="text-xs text-slate-400">{syncStatus}</div>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Link your Google account to automatically sync your Cash (₹), Hypercars, Custom Character, Completed Missions, and Stats between your phone and PC via Cloud Firestore.
                </p>

                <div className="flex flex-wrap items-center gap-2.5 pt-1">
                  {user ? (
                    <>
                      <button
                        onClick={onForceCloudSync}
                        className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold cursor-pointer"
                      >
                        Sync Save Now
                      </button>
                      <button
                        onClick={onSignOut}
                        className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={onGoogleSignIn}
                      className="px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
                    >
                      Sign In with Google for Cross-Platform Saves
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {tab === 'leaderboard' && (
            <div className="space-y-3">
              {!user ? (
                <div className="p-5 rounded-lg bg-slate-950 border border-slate-800 text-center space-y-3">
                  <p className="text-sm text-slate-300">Sign in with Google to view and compete on the cross-platform India driver leaderboard.</p>
                  <button
                    onClick={onGoogleSignIn}
                    className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
                  >
                    Sign In with Google
                  </button>
                </div>
              ) : leaderboard.length === 0 ? (
                <p className="text-xs text-slate-400">No driver entries synced yet. Complete a mission or sync your save to appear on the board.</p>
              ) : (
                <div className="space-y-2">
                  {leaderboard.map((entry, idx) => (
                    <div
                      key={entry.userId}
                      className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-mono-num text-amber-400 font-bold w-6">#{idx + 1}</span>
                        <span className="font-semibold text-white">{entry.displayName}</span>
                      </div>
                      <div className="font-mono-num text-slate-300">
                        {entry.reputation.toLocaleString('en-IN')} REP · {entry.topSpeedKmh} km/h · {entry.destructiblesSmashed} Smashed
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
