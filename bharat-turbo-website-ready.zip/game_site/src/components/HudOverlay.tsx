import React, { useMemo, useState } from 'react';
import {
  Camera,
  CarFront,
  ChevronDown,
  ChevronUp,
  CloudRain,
  Crosshair,
  Flag,
  Gamepad2,
  Globe2,
  Landmark,
  Map as MapIcon,
  Monitor,
  Pause,
  Star,
  UserCog,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  JAIPUR_EW_ROADS,
  JAIPUR_NS_ROADS,
  POLICE_STATION,
  VEHICLE_CATALOG,
  WEAPONS_CATALOG,
  WORLD_FACILITIES,
  computeJaipurGpsRoute,
  type CameraMode,
  type GraphicsPreset,
  type LiveTelemetry,
  type VehicleId,
  type WeatherMode,
} from '../types/game';
import type { BlueprintBuilding } from '../engine/indiaWorldBuilder';

interface HudOverlayProps {
  telemetry: LiveTelemetry;
  cash: number;
  bankBalance: number;
  reputation: number;
  selectedVehicle: VehicleId;
  weather: WeatherMode;
  graphics: GraphicsPreset;
  cameraMode: CameraMode;
  muted: boolean;
  touchEnabled: boolean;
  shardId: string;
  shardPlayers: number;
  totalConcurrent: number;
  bannerMessage: string | null;
  blueprintBuildings: BlueprintBuilding[];
  activeWaypoint: { x: number; z: number } | null;
  onOpenMap: () => void;
  onOpenMissions: () => void;
  onOpenGarage: () => void;
  onOpenArmory: () => void;
  onOpenCharacter: () => void;
  onOpenMultiplayer: () => void;
  onEnterFacility: (facilityId: string) => void;
  onCycleWeapon: () => void;
  onCycleWeather: () => void;
  onCycleGraphics: () => void;
  onCycleCamera: () => void;
  onToggleMute: () => void;
  onToggleTouch: () => void;
  onToggleVehicle: () => void;
  onPause: () => void;
}

const MINI_RADIUS = 260; // meters visible from center to edge of small map
const MINI_CENTER = 60;
const MINI_SCALE = MINI_CENTER / MINI_RADIUS;

export const HudOverlay: React.FC<HudOverlayProps> = ({
  telemetry,
  cash,
  bankBalance,
  reputation,
  selectedVehicle,
  weather,
  graphics,
  cameraMode,
  muted,
  touchEnabled,
  shardId,
  shardPlayers,
  totalConcurrent,
  bannerMessage,
  blueprintBuildings,
  activeWaypoint,
  onOpenMap,
  onOpenMissions,
  onOpenGarage,
  onOpenArmory,
  onOpenCharacter,
  onOpenMultiplayer,
  onEnterFacility,
  onCycleWeapon,
  onCycleWeather,
  onCycleGraphics,
  onCycleCamera,
  onToggleMute,
  onToggleTouch,
  onToggleVehicle,
  onPause,
}) => {
  const [dockCollapsed, setDockCollapsed] = useState(false);

  const carSpec = VEHICLE_CATALOG[selectedVehicle];
  const weaponSpec = WEAPONS_CATALOG[telemetry.selectedWeapon];
  const nearbyFacility = telemetry.nearbyFacilityId
    ? WORLD_FACILITIES.find((f) => f.id === telemetry.nearbyFacilityId) || null
    : null;

  const px = telemetry.playerX;
  const pz = telemetry.playerZ;
  const toMiniX = (wx: number) => MINI_CENTER + (wx - px) * MINI_SCALE;
  const toMiniY = (wz: number) => MINI_CENTER + (wz - pz) * MINI_SCALE;

  const visibleBuildings = useMemo(() => {
    const cull = MINI_RADIUS + 46;
    return blueprintBuildings.filter(
      (b) => Math.abs(b.x - px) < cull && Math.abs(b.z - pz) < cull,
    );
  }, [blueprintBuildings, px, pz]);

  const gpsRoutePointsStr = useMemo(() => {
    if (!activeWaypoint) return '';
    const pts = computeJaipurGpsRoute(px, pz, activeWaypoint.x, activeWaypoint.z);
    return pts
      .map((p) => `${(MINI_CENTER + (p.x - px) * MINI_SCALE).toFixed(1)},${(MINI_CENTER + (p.z - pz) * MINI_SCALE).toFixed(1)}`)
      .join(' ');
  }, [activeWaypoint, px, pz]);

  // Waypoint marker (clamped to minimap border when off-screen)
  let wpMarker: { x: number; y: number; clamped: boolean } | null = null;
  if (activeWaypoint) {
    const dx = (activeWaypoint.x - px) * MINI_SCALE;
    const dy = (activeWaypoint.z - pz) * MINI_SCALE;
    const dist = Math.hypot(dx, dy);
    if (dist > 51) {
      wpMarker = { x: MINI_CENTER + (dx / dist) * 51, y: MINI_CENTER + (dy / dist) * 51, clamped: true };
    } else {
      wpMarker = { x: MINI_CENTER + dx, y: MINI_CENTER + dy, clamped: false };
    }
  }

  const playerDeg = (-telemetry.playerYaw * 180) / Math.PI;
  const rpmAngle = -125 + telemetry.rpmRatio * 250;
  const isRedline = telemetry.rpmRatio > 0.85;
  const hpPct = Math.max(0, Math.min(100, Math.round((telemetry.health / Math.max(1, telemetry.maxHealth)) * 100)));

  return (
    <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-between p-3 sm:p-4">
      {/* Top Row: Jaipur Street Minimap + Cash/Bank/Weapon (Top-Left) | Wanted + Facility Prompt + Mission (Top-Right) */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <button
            onClick={onOpenMap}
            className="pointer-events-auto w-28 h-28 sm:w-32 sm:h-32 rounded-lg bg-slate-950/95 border border-slate-700 relative overflow-hidden shrink-0 cursor-pointer hover:border-amber-400 transition-colors shadow-xl"
            title="Open Jaipur City Map (M)"
          >
            <svg viewBox="0 0 120 120" className="w-full h-full">
              <defs>
                <clipPath id="miniMapClip">
                  <rect x="0" y="0" width="120" height="120" rx="6" />
                </clipPath>
              </defs>
              <g clipPath="url(#miniMapClip)">
                <rect width="120" height="120" fill="#060d1b" />
                {/* Technical Grid */}
                {[-200, -100, 0, 100, 200].map((off) => (
                  <g key={`grid-${off}`}>
                    <line
                      x1={0}
                      y1={MINI_CENTER + off * MINI_SCALE}
                      x2={120}
                      y2={MINI_CENTER + off * MINI_SCALE}
                      stroke="#0f1e36"
                      strokeWidth="0.6"
                    />
                    <line
                      x1={MINI_CENTER + off * MINI_SCALE}
                      y1={0}
                      x2={MINI_CENTER + off * MINI_SCALE}
                      y2={120}
                      stroke="#0f1e36"
                      strokeWidth="0.6"
                    />
                  </g>
                ))}

                {/* Water Bodies: Man Sagar Lake (Jal Mahal) & Dravyavati Riverfront */}
                <rect
                  x={toMiniX(198)}
                  y={toMiniY(-839)}
                  width={184 * MINI_SCALE}
                  height={178 * MINI_SCALE}
                  rx="3"
                  fill="#0c4a6e"
                  opacity="0.78"
                />
                <rect
                  x={toMiniX(-230)}
                  y={toMiniY(656)}
                  width={340 * MINI_SCALE}
                  height={108 * MINI_SCALE}
                  rx="2"
                  fill="#0c4a6e"
                  opacity="0.72"
                />

                {/* Walled Pink City Parkota Perimeter */}
                <rect
                  x={toMiniX(-240)}
                  y={toMiniY(-380)}
                  width={660 * MINI_SCALE}
                  height={340 * MINI_SCALE}
                  fill="#9d174d"
                  fillOpacity="0.1"
                  stroke="#f472b6"
                  strokeWidth="0.9"
                  opacity="0.7"
                />

                {/* Jawahar Circle Ring */}
                <circle
                  cx={toMiniX(160)}
                  cy={toMiniY(840)}
                  r={36 * MINI_SCALE}
                  fill="none"
                  stroke="#f43f5e"
                  strokeWidth="1.2"
                  opacity="0.7"
                />

                {/* Jaipur EW Avenues */}
                {JAIPUR_EW_ROADS.map((rz) => (
                  <g key={`ew-${rz}`}>
                    <line
                      x1={toMiniX(-1380)}
                      y1={toMiniY(rz)}
                      x2={toMiniX(1380)}
                      y2={toMiniY(rz)}
                      stroke="#1e293b"
                      strokeWidth={20 * MINI_SCALE}
                    />
                    <line
                      x1={toMiniX(-1380)}
                      y1={toMiniY(rz)}
                      x2={toMiniX(1380)}
                      y2={toMiniY(rz)}
                      stroke="#475569"
                      strokeWidth="0.55"
                      strokeDasharray="2 2"
                    />
                  </g>
                ))}

                {/* Jaipur NS Avenues (Tonk Road x=-60 includes Dravyavati Cable Flyover) */}
                {JAIPUR_NS_ROADS.map((rx) => (
                  <g key={`ns-${rx}`}>
                    <line
                      x1={toMiniX(rx)}
                      y1={toMiniY(-1380)}
                      x2={toMiniX(rx)}
                      y2={toMiniY(1380)}
                      stroke="#1e293b"
                      strokeWidth={20 * MINI_SCALE}
                    />
                    <line
                      x1={toMiniX(rx)}
                      y1={toMiniY(-1380)}
                      x2={toMiniX(rx)}
                      y2={toMiniY(1380)}
                      stroke="#475569"
                      strokeWidth="0.55"
                      strokeDasharray="2 2"
                    />
                  </g>
                ))}

                {/* Dravyavati Cable Flyover Deck */}
                <line
                  x1={toMiniX(-60)}
                  y1={toMiniY(610)}
                  x2={toMiniX(-60)}
                  y2={toMiniY(810)}
                  stroke="#38bdf8"
                  strokeWidth={16 * MINI_SCALE}
                  opacity="0.65"
                />

                {/* Sanganer Airport Runway 09/27 */}
                <line
                  x1={toMiniX(60)}
                  y1={toMiniY(1205)}
                  x2={toMiniX(420)}
                  y2={toMiniY(1205)}
                  stroke="#0284c7"
                  strokeWidth={24 * MINI_SCALE}
                  opacity="0.7"
                />

                {/* Building & Runway Footprints */}
                {visibleBuildings.map((b, idx) => {
                  const bw = Math.max(2, b.w * MINI_SCALE);
                  const bd = Math.max(2, b.d * MINI_SCALE);
                  const fill =
                    b.kind === 'bank'
                      ? '#065f46'
                      : b.kind === 'hospital'
                      ? '#7f1d1d'
                      : b.kind === 'home'
                      ? '#78350f'
                      : b.kind === 'police'
                      ? '#1e3a8a'
                      : b.kind === 'airport'
                      ? '#0c4a6e'
                      : b.kind === 'landmark'
                      ? '#475569'
                      : '#1e293b';
                  const stroke =
                    b.kind === 'bank'
                      ? '#10b981'
                      : b.kind === 'hospital'
                      ? '#ef4444'
                      : b.kind === 'home'
                      ? '#f59e0b'
                      : b.kind === 'police'
                      ? '#60a5fa'
                      : b.kind === 'airport'
                      ? '#38bdf8'
                      : b.kind === 'landmark'
                      ? '#fbbf24'
                      : '#38bdf8';
                  return (
                    <rect
                      key={`bp-${idx}`}
                      x={toMiniX(b.x) - bw / 2}
                      y={toMiniY(b.z) - bd / 2}
                      width={bw}
                      height={bd}
                      fill={fill}
                      stroke={stroke}
                      strokeWidth="0.55"
                      opacity="0.9"
                    />
                  );
                })}

                {/* Highlighted Street-Following GPS Route */}
                {gpsRoutePointsStr && (
                  <>
                    <polyline
                      points={gpsRoutePointsStr}
                      fill="none"
                      stroke="#0ea5e9"
                      strokeWidth="3.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.88"
                    />
                    <polyline
                      points={gpsRoutePointsStr}
                      fill="none"
                      stroke="#fbbf24"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeDasharray="3 2"
                    />
                  </>
                )}

                {/* Jaipur Police Commissionerate HQ Icon */}
                <g transform={`translate(${toMiniX(POLICE_STATION.x)}, ${toMiniY(POLICE_STATION.z)})`}>
                  <rect x="-4.5" y="-4.5" width="9" height="9" rx="1.8" fill="#1d4ed8" stroke="#ef4444" strokeWidth="0.9" />
                  <text x="0" y="2.4" textAnchor="middle" fill="#ffffff" fontSize="6.5" fontWeight="800">
                    P
                  </text>
                </g>

                {/* Banks, Hospitals, Airport & Player Home Icons */}
                {WORLD_FACILITIES.map((f) => {
                  const fx = toMiniX(f.x);
                  const fy = toMiniY(f.z);
                  if (fx < -12 || fx > 132 || fy < -12 || fy > 132) return null;
                  const glyph =
                    f.type === 'bank'
                      ? '₹'
                      : f.type === 'hospital'
                      ? '+'
                      : f.type === 'airport'
                      ? '✈'
                      : 'H';
                  const bg =
                    f.type === 'bank'
                      ? '#059669'
                      : f.type === 'hospital'
                      ? '#dc2626'
                      : f.type === 'airport'
                      ? '#0284c7'
                      : '#d97706';
                  return (
                    <g key={f.id} transform={`translate(${fx}, ${fy})`}>
                      <circle r="4.8" fill={bg} stroke="#ffffff" strokeWidth="0.8" />
                      <text x="0" y="2.3" textAnchor="middle" fill="#ffffff" fontSize="6.5" fontWeight="800">
                        {glyph}
                      </text>
                    </g>
                  );
                })}

                {/* Active GPS Waypoint Target */}
                {wpMarker && (
                  <circle
                    cx={wpMarker.x}
                    cy={wpMarker.y}
                    r={wpMarker.clamped ? 4.0 : 4.8}
                    fill="#f59e0b"
                    stroke="#ffffff"
                    strokeWidth="1.1"
                  />
                )}

                {/* Player Directional Arrow */}
                <g transform={`translate(${MINI_CENTER}, ${MINI_CENTER}) rotate(${playerDeg})`}>
                  <polygon points="0,-6.5 4.8,5 0,2.5 -4.8,5" fill="#fbbf24" stroke="#0f172a" strokeWidth="0.9" />
                </g>
              </g>
            </svg>
            <span className="absolute top-1 left-1.5 text-[9px] font-bold text-cyan-300 tracking-wider">N</span>
            <span className="absolute bottom-1 right-1.5 text-[9px] font-bold text-slate-200 bg-slate-950/85 px-1.5 rounded">
              MAP
            </span>
          </button>

          <div className="bg-slate-950/90 border border-slate-800 rounded-lg px-3.5 py-2 space-y-0.5 pointer-events-auto">
            <div className="text-xs font-semibold text-amber-400">
              {telemetry.currentLocalityName} · <span className="text-slate-400 font-normal">{telemetry.currentZoneName}</span>
            </div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="font-mono-num text-sm sm:text-base font-bold text-emerald-400">
                ₹{cash.toLocaleString('en-IN')}
              </div>
              <div className="font-mono-num text-[11px] font-semibold text-cyan-300 flex items-center gap-1">
                <Landmark className="w-3 h-3 text-cyan-400" />
                <span>₹{bankBalance.toLocaleString('en-IN')}</span>
              </div>
            </div>
            <div className="text-[11px] text-slate-400 font-mono-num">
              {reputation.toLocaleString('en-IN')} REP · {shardPlayers} in {shardId} · {totalConcurrent} Online
            </div>
            <button
              onClick={onCycleWeapon}
              className="mt-1 flex items-center gap-1.5 text-[11px] font-semibold text-slate-200 hover:text-amber-300 cursor-pointer"
              title="Cycle Weapon (Q) · Fire (E / Click)"
            >
              <Crosshair className="w-3.5 h-3.5" style={{ color: weaponSpec.color }} />
              <span>{weaponSpec.name}</span>
              <span className="text-slate-500 font-mono-num">[Q/E]</span>
            </button>
          </div>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-2 pointer-events-auto">
            {telemetry.wantedLevel > 0 && (
              <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-950/92 border border-red-500/60">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-4 h-4 ${
                        s <= telemetry.wantedLevel ? 'text-amber-400 fill-amber-400' : 'text-slate-700'
                      }`}
                    />
                  ))}
                </div>
                {telemetry.helicopterCount > 0 && (
                  <span className="text-[10px] font-mono-num font-bold text-red-400 border-l border-slate-700 pl-2">
                    CHOPPERS:{telemetry.helicopterCount}
                  </span>
                )}
              </div>
            )}
            <button
              onClick={onPause}
              className="p-2 rounded-lg bg-slate-950/90 border border-slate-700 hover:border-slate-500 text-slate-200 cursor-pointer"
              title="Pause (Esc)"
              aria-label="Pause Game"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>

          {telemetry.bustedProgress > 0.05 && (
            <div className="bg-slate-950/95 border border-red-500 rounded-lg px-3 py-1.5 w-48 space-y-1">
              <div className="flex items-center justify-between text-[11px] font-bold text-red-400">
                <span>GETTING BUSTED</span>
                <span className="font-mono-num">{Math.round(telemetry.bustedProgress * 100)}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-800 rounded overflow-hidden">
                <div
                  className="h-full bg-red-500 transition-[width] duration-75"
                  style={{ width: `${Math.round(telemetry.bustedProgress * 100)}%` }}
                />
              </div>
            </div>
          )}

          {nearbyFacility && (
            <button
              onClick={() => onEnterFacility(nearbyFacility.id)}
              className="pointer-events-auto px-3.5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg cursor-pointer"
            >
              Enter {nearbyFacility.name} [V]
            </button>
          )}

          {telemetry.missionLabel ? (
            <div className="bg-slate-950/92 border border-amber-500/50 rounded-lg px-3.5 py-2 text-right max-w-xs">
              <div className="text-[11px] font-semibold text-amber-400 font-mono-num">
                ACTIVE CONTRACT · {telemetry.missionTimeLeft}s
              </div>
              <div className="text-xs sm:text-sm font-medium text-white">{telemetry.missionLabel}</div>
            </div>
          ) : telemetry.canEnterVehicle ? (
            <button
              onClick={onToggleVehicle}
              className="pointer-events-auto px-3.5 py-2 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold cursor-pointer"
            >
              Press F / Tap to Enter Vehicle
            </button>
          ) : null}
        </div>
      </div>

      {/* Center-Top Event Toast Banner */}
      {bannerMessage && (
        <div className="mx-auto px-5 py-2.5 rounded-lg bg-slate-950/95 border border-amber-400 text-amber-300 font-display font-bold text-sm sm:text-base shadow-xl">
          {bannerMessage}
        </div>
      )}

      {/* Bottom Row: Supercar Tachometer + Collapsible Control Dock */}
      <div className="flex flex-col items-center gap-2 relative">
        {!touchEnabled && (
          <div className="self-end bg-slate-950/92 border border-slate-800 rounded-xl px-4 py-3 min-w-[215px] flex items-center gap-3.5 shadow-2xl">
            <div className="relative w-20 h-20 shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="#1e293b"
                  strokeWidth="6"
                  strokeDasharray="185 264"
                  strokeDashoffset="-39"
                  transform="rotate(144 50 50)"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="6"
                  strokeDasharray="42 264"
                  strokeDashoffset="-180"
                  transform="rotate(144 50 50)"
                />
                <g transform={`rotate(${rpmAngle} 50 50)`}>
                  <line
                    x1="50"
                    y1="54"
                    x2="50"
                    y2="14"
                    stroke={isRedline ? '#ef4444' : '#f59e0b'}
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  <circle cx="50" cy="50" r="4.5" fill="#f8fafc" />
                </g>
                <text
                  x="50"
                  y="78"
                  textAnchor="middle"
                  fill={telemetry.inAircraft ? '#38bdf8' : isRedline ? '#ef4444' : '#38bdf8'}
                  fontSize="14"
                  fontWeight="700"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {telemetry.onFoot ? 'FT' : telemetry.inAircraft ? 'JET' : `G${telemetry.gear}`}
                </text>
              </svg>
            </div>

            <div className="flex-1 space-y-1.5">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-display font-bold text-3xl text-white font-mono-num leading-none">
                  {telemetry.onFoot ? 'WALK' : telemetry.speedKmh}
                </span>
                <span className="text-[11px] text-slate-400 font-mono-num">
                  {telemetry.onFoot ? 'FOOT' : telemetry.inAircraft ? `ALT ${telemetry.altitudeM}m` : 'KM/H'}
                </span>
              </div>
              <div className="text-[11px] text-slate-300 font-medium truncate">
                {telemetry.inAircraft
                  ? 'Private Jet · Space Climb · S Descend · F Exit Low'
                  : `${carSpec.brand} ${carSpec.name}`}
              </div>
              <div className="space-y-0.5">
                <div className="flex justify-between text-[10px] text-cyan-400 font-mono-num">
                  <span>NITRO</span>
                  <span>{telemetry.nitro}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-[width] duration-75"
                    style={{ width: `${telemetry.nitro}%` }}
                  />
                </div>
              </div>
              <div className="space-y-0.5">
                <div className="flex justify-between text-[10px] text-emerald-400 font-mono-num">
                  <span>HP</span>
                  <span>{telemetry.health}/{telemetry.maxHealth}</span>
                </div>
                <div className="h-1.5 w-full bg-slate-800 rounded overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 transition-[width] duration-75"
                    style={{ width: `${hpPct}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="pointer-events-auto flex flex-col items-center max-w-[96vw]">
          <button
            onClick={() => setDockCollapsed((c) => !c)}
            className="px-3 py-1 rounded-t-lg bg-slate-950/92 border border-b-0 border-slate-700 text-[11px] font-medium text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer"
          >
            {dockCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            <span>{dockCollapsed ? 'Show Controls' : 'Hide Controls'}</span>
          </button>

          {!dockCollapsed && (
            <div className="flex flex-wrap items-center justify-center gap-1.5 px-2.5 py-2 rounded-xl bg-slate-950/92 border border-slate-700 shadow-2xl">
              <button
                onClick={onOpenMap}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <MapIcon className="w-3.5 h-3.5 text-amber-400" />
                <span>Jaipur Map</span>
              </button>

              <button
                onClick={onOpenMissions}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Flag className="w-3.5 h-3.5 text-emerald-400" />
                <span>Missions</span>
              </button>

              <button
                onClick={onOpenGarage}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <CarFront className="w-3.5 h-3.5 text-red-400" />
                <span>Garage</span>
              </button>

              <button
                onClick={onOpenArmory}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Crosshair className="w-3.5 h-3.5 text-orange-400" />
                <span>Weapons</span>
              </button>

              <button
                onClick={onOpenCharacter}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <UserCog className="w-3.5 h-3.5 text-amber-300" />
                <span>Character</span>
              </button>

              <button
                onClick={onOpenMultiplayer}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Globe2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Lobbies</span>
              </button>

              <button
                onClick={onCycleWeather}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <CloudRain className="w-3.5 h-3.5 text-sky-400" />
                <span className="capitalize">{weather}</span>
              </button>

              <button
                onClick={onCycleGraphics}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Monitor className="w-3.5 h-3.5 text-purple-400" />
                <span>{graphics === 'ultra4k' ? 'Ultra 4K' : graphics === 'high' ? 'High' : 'Mobile'}</span>
              </button>

              <button
                onClick={onCycleCamera}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-slate-300" />
                <span className="capitalize">{cameraMode}</span>
              </button>

              <button
                onClick={onToggleTouch}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  touchEnabled ? 'bg-amber-500 text-slate-950 font-semibold' : 'bg-slate-900 hover:bg-slate-800 text-slate-200'
                }`}
              >
                <Gamepad2 className="w-3.5 h-3.5" />
                <span>Touch</span>
              </button>

              <button
                onClick={onToggleMute}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                aria-label="Toggle Sound"
              >
                {muted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
