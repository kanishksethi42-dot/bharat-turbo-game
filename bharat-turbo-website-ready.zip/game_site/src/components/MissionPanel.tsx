import React from 'react';
import { CheckCircle2, Play, X } from 'lucide-react';
import { MISSIONS_CATALOG, resolveRajasthanDistrict, type MissionDef } from '../types/game';

interface MissionPanelProps {
  activeMissionId: string | null;
  completedMissions: string[];
  onStartMission: (m: MissionDef) => void;
  onCancelMission: () => void;
  onClose: () => void;
}

export const MissionPanel: React.FC<MissionPanelProps> = ({
  activeMissionId,
  completedMissions,
  onStartMission,
  onCancelMission,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Jaipur Open-World Contracts</h2>
            <p className="text-xs text-slate-400">Complete contracts across Pink City, Amer Fort, MI Road, JLN Marg &amp; Sanganer Airport to unlock hypercars &amp; ordnance</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5 overflow-y-auto">
          {MISSIONS_CATALOG.map((m) => {
            const isActive = activeMissionId === m.id;
            const isDone = completedMissions.includes(m.id);
            const dist = resolveRajasthanDistrict(m.district);

            return (
              <div
                key={m.id}
                className={`p-4 rounded-lg border flex flex-col justify-between gap-3 ${
                  isActive
                    ? 'bg-amber-500/15 border-amber-400'
                    : 'bg-slate-950/75 border-slate-800'
                }`}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-amber-400">{dist.name} · {m.type.toUpperCase()}</span>
                    {isDone && (
                      <span className="flex items-center gap-1 text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Cleared
                      </span>
                    )}
                  </div>
                  <h3 className="font-display text-lg font-bold text-white">{m.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{m.briefing}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <div className="text-xs font-mono-num text-emerald-400">
                    ₹{m.rewardCash.toLocaleString('en-IN')} · +{m.rewardRep} REP
                  </div>
                  {isActive ? (
                    <button
                      onClick={() => {
                        onCancelMission();
                        onClose();
                      }}
                      className="px-3.5 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-xs font-bold text-white cursor-pointer"
                    >
                      Abort
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        onStartMission(m);
                        onClose();
                      }}
                      className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-xs font-bold text-slate-950 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-slate-950" />
                      <span>Start</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
