import React, { useMemo, useState } from 'react';
import {
  Flag,
  HeartPulse,
  Home,
  Landmark,
  MapPin,
  Navigation,
  Plane,
  Search,
  ShieldAlert,
  X,
} from 'lucide-react';
import {
  JAIPUR_EW_ROADS,
  JAIPUR_LOCALITIES,
  JAIPUR_NS_ROADS,
  MISSIONS_CATALOG,
  POLICE_STATION,
  WORLD_FACILITIES,
  computeJaipurGpsRoute,
  worldToJaipurMapPct,
  type DistrictId,
  type JaipurZone,
  type RemotePeerState,
} from '../types/game';

interface IndiaMapModalProps {
  playerX: number;
  playerZ: number;
  activeMissionId: string | null;
  activeWaypoint: { x: number; z: number } | null;
  peers: RemotePeerState[];
  onFastTravel: (districtId: DistrictId) => void;
  onFastTravelCoords: (x: number, z: number, label: string) => void;
  onSetWaypoint: (x: number, z: number) => void;
  onClose: () => void;
}

const JAIPUR_ZONES: Array<'All' | JaipurZone> = [
  'All',
  'Walled Pink City',
  'Central · MI Road',
  'North · Amer',
  'South · JLN & Airport',
  'West · Vaishali',
  'East · Agra Rd',
];

export const IndiaMapModal: React.FC<IndiaMapModalProps> = ({
  playerX,
  playerZ,
  activeMissionId,
  activeWaypoint,
  peers,
  onFastTravelCoords,
  onSetWaypoint,
  onClose,
}) => {
  const [search, setSearch] = useState('');
  const [zone, setZone] = useState<'All' | JaipurZone>('All');

  const filteredLocalities = useMemo(() => {
    const q = search.trim().toLowerCase();
    return JAIPUR_LOCALITIES.filter((loc) => {
      if (zone !== 'All' && loc.zone !== zone) return false;
      if (!q) return true;
      return (
        loc.name.toLowerCase().includes(q) ||
        loc.subtitle.toLowerCase().includes(q) ||
        loc.zone.toLowerCase().includes(q)
      );
    });
  }, [zone, search]);

  const gpsRoutePts = useMemo(() => {
    if (!activeWaypoint) return '';
    return computeJaipurGpsRoute(playerX, playerZ, activeWaypoint.x, activeWaypoint.z)
      .map((p) => {
        const pt = worldToJaipurMapPct(p.x, p.z);
        return `${pt.mapX},${pt.mapY}`;
      })
      .join(' ');
  }, [activeWaypoint, playerX, playerZ]);

  const playerSvg = worldToJaipurMapPct(playerX, playerZ);
  const policeSvg = worldToJaipurMapPct(POLICE_STATION.x, POLICE_STATION.z);
  const wpSvg = activeWaypoint ? worldToJaipurMapPct(activeWaypoint.x, activeWaypoint.z) : null;

  // Map landmark shapes
  const wallTopLeft = worldToJaipurMapPct(-240, -380);
  const wallBotRight = worldToJaipurMapPct(420, -40);
  const manSagarTL = worldToJaipurMapPct(198, -839);
  const manSagarBR = worldToJaipurMapPct(382, -661);
  const dravyavatiTL = worldToJaipurMapPct(-230, 656);
  const dravyavatiBR = worldToJaipurMapPct(110, 764);
  const ramNiwasTL = worldToJaipurMapPct(45, 0);
  const ramNiwasBR = worldToJaipurMapPct(240, 125);
  const centralParkTL = worldToJaipurMapPct(5, 290);
  const centralParkBR = worldToJaipurMapPct(155, 420);
  const jawaharCenter = worldToJaipurMapPct(160, 840);
  const runwayStart = worldToJaipurMapPct(60, 1205);
  const runwayEnd = worldToJaipurMapPct(420, 1205);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/88">
      <div className="w-full max-w-5xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-xl font-bold text-white">
              Jaipur City Map — Pink City to Sanganer
            </h2>
            <p className="text-xs text-slate-400">
              Click any neighborhood, landmark, or facility to highlight the road GPS route or Fast Travel
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close Map"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-hidden">
          {/* Interactive Authentic Jaipur Street Map */}
          <div className="lg:col-span-6 p-4 flex items-center justify-center bg-slate-950 relative min-h-[340px]">
            <svg viewBox="0 0 100 100" className="w-full max-w-[440px] h-auto">
              <rect x="0" y="0" width="100" height="100" rx="6" fill="#09101d" />

              {/* Aravalli Hills Ridge (North & East) */}
              <path
                d="M 10 18 Q 36 8 64 12 T 92 38 L 92 10 L 10 10 Z"
                fill="#78350f"
                opacity="0.18"
              />
              <text x="50" y="9" textAnchor="middle" fill="#f59e0b" fontSize="2.3" fontWeight="700" opacity="0.65">
                ARAVALLI HILLS · AMER &amp; NAHARGARH RIDGE
              </text>

              {/* Man Sagar Lake (Jal Mahal) */}
              <rect
                x={manSagarTL.mapX}
                y={manSagarTL.mapY}
                width={manSagarBR.mapX - manSagarTL.mapX}
                height={manSagarBR.mapY - manSagarTL.mapY}
                rx="1.5"
                fill="#0284c7"
                opacity="0.38"
              />

              {/* Dravyavati Riverfront */}
              <rect
                x={dravyavatiTL.mapX}
                y={dravyavatiTL.mapY}
                width={dravyavatiBR.mapX - dravyavatiTL.mapX}
                height={dravyavatiBR.mapY - dravyavatiTL.mapY}
                rx="1"
                fill="#0284c7"
                opacity="0.34"
              />

              {/* Ram Niwas Bagh & Central Park */}
              <rect
                x={ramNiwasTL.mapX}
                y={ramNiwasTL.mapY}
                width={ramNiwasBR.mapX - ramNiwasTL.mapX}
                height={ramNiwasBR.mapY - ramNiwasTL.mapY}
                rx="1"
                fill="#10b981"
                opacity="0.18"
              />
              <rect
                x={centralParkTL.mapX}
                y={centralParkTL.mapY}
                width={centralParkBR.mapX - centralParkTL.mapX}
                height={centralParkBR.mapY - centralParkTL.mapY}
                rx="1"
                fill="#10b981"
                opacity="0.18"
              />

              {/* Walled Pink City Parkota */}
              <rect
                x={wallTopLeft.mapX}
                y={wallTopLeft.mapY}
                width={wallBotRight.mapX - wallTopLeft.mapX}
                height={wallBotRight.mapY - wallTopLeft.mapY}
                fill="#be185d"
                fillOpacity="0.13"
                stroke="#f472b6"
                strokeWidth="0.6"
              />
              <text
                x={(wallTopLeft.mapX + wallBotRight.mapX) / 2}
                y={wallTopLeft.mapY + 2.6}
                textAnchor="middle"
                fill="#f9a8d4"
                fontSize="2.2"
                fontWeight="700"
                opacity="0.78"
              >
                WALLED PINK CITY
              </text>

              {/* Jawahar Circle Ring */}
              <circle
                cx={jawaharCenter.mapX}
                cy={jawaharCenter.mapY}
                r="1.9"
                fill="#10b981"
                fillOpacity="0.22"
                stroke="#f43f5e"
                strokeWidth="0.45"
              />

              {/* Jaipur EW Road Grid */}
              {JAIPUR_EW_ROADS.map((rz) => {
                const a = worldToJaipurMapPct(-1300, rz);
                const b = worldToJaipurMapPct(1300, rz);
                return (
                  <line
                    key={`map-ew-${rz}`}
                    x1={a.mapX}
                    y1={a.mapY}
                    x2={b.mapX}
                    y2={b.mapY}
                    stroke="#334155"
                    strokeWidth="0.55"
                  />
                );
              })}

              {/* Jaipur NS Road Grid */}
              {JAIPUR_NS_ROADS.map((rx) => {
                const a = worldToJaipurMapPct(rx, -1300);
                const b = worldToJaipurMapPct(rx, 1300);
                return (
                  <line
                    key={`map-ns-${rx}`}
                    x1={a.mapX}
                    y1={a.mapY}
                    x2={b.mapX}
                    y2={b.mapY}
                    stroke="#334155"
                    strokeWidth="0.55"
                  />
                );
              })}

              {/* Sanganer Airport Runway 09/27 */}
              <line
                x1={runwayStart.mapX}
                y1={runwayStart.mapY}
                x2={runwayEnd.mapX}
                y2={runwayEnd.mapY}
                stroke="#38bdf8"
                strokeWidth="1.2"
                opacity="0.75"
              />

              {/* Highlighted Road-Following GPS Route */}
              {gpsRoutePts && (
                <>
                  <polyline
                    points={gpsRoutePts}
                    fill="none"
                    stroke="#0ea5e9"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    opacity="0.9"
                  />
                  <polyline
                    points={gpsRoutePts}
                    fill="none"
                    stroke="#fbbf24"
                    strokeWidth="0.75"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeDasharray="1.6 1.1"
                  />
                </>
              )}

              {/* Remote Multiplayer Peers */}
              {peers.map((peer) => {
                const pos = worldToJaipurMapPct(peer.x, peer.z);
                return (
                  <circle
                    key={peer.id}
                    cx={pos.mapX}
                    cy={pos.mapY}
                    r="1.0"
                    fill="#22d3ee"
                    opacity="0.85"
                  />
                );
              })}

              {/* Jaipur Neighborhoods & Landmarks */}
              {JAIPUR_LOCALITIES.map((loc) => {
                const matchesFilter = zone === 'All' || loc.zone === zone;
                return (
                  <g
                    key={loc.id}
                    onClick={() => {
                      onSetWaypoint(loc.x, loc.z);
                      onClose();
                    }}
                    className="cursor-pointer"
                    opacity={matchesFilter ? 1 : 0.25}
                  >
                    <circle
                      cx={loc.mapX}
                      cy={loc.mapY}
                      r={loc.majorHub ? 1.85 : 1.15}
                      fill={loc.accent}
                      stroke="#0f172a"
                      strokeWidth="0.4"
                    />
                    {loc.majorHub && (
                      <text
                        x={loc.mapX + 2.1}
                        y={loc.mapY + 0.7}
                        fill="#f8fafc"
                        fontSize="2.2"
                        fontWeight="700"
                      >
                        {loc.name.split(' · ')[0]}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Jaipur Police Commissionerate HQ */}
              <g
                transform={`translate(${policeSvg.mapX}, ${policeSvg.mapY})`}
                onClick={() => {
                  onSetWaypoint(POLICE_STATION.gateX, POLICE_STATION.gateZ);
                  onClose();
                }}
                className="cursor-pointer"
              >
                <rect x="-1.9" y="-1.9" width="3.8" height="3.8" rx="0.7" fill="#1d4ed8" stroke="#ef4444" strokeWidth="0.5" />
                <text x="0" y="0.95" textAnchor="middle" fill="#ffffff" fontSize="2.2" fontWeight="700">
                  P
                </text>
              </g>

              {/* Airport, Banks, Hospitals & Player Haveli */}
              {WORLD_FACILITIES.map((f) => {
                const pos = worldToJaipurMapPct(f.entryX, f.entryZ);
                const glyph =
                  f.type === 'bank'
                    ? '₹'
                    : f.type === 'hospital'
                    ? '+'
                    : f.type === 'airport'
                    ? '✈'
                    : 'H';
                const fill =
                  f.type === 'bank'
                    ? '#059669'
                    : f.type === 'hospital'
                    ? '#dc2626'
                    : f.type === 'airport'
                    ? '#0284c7'
                    : '#d97706';
                return (
                  <g
                    key={f.id}
                    transform={`translate(${pos.mapX}, ${pos.mapY})`}
                    onClick={() => {
                      onSetWaypoint(f.entryX, f.entryZ);
                      onClose();
                    }}
                    className="cursor-pointer"
                  >
                    <circle r="1.8" fill={fill} stroke="#ffffff" strokeWidth="0.4" />
                    <text x="0" y="0.85" textAnchor="middle" fill="#ffffff" fontSize="2.1" fontWeight="800">
                      {glyph}
                    </text>
                  </g>
                );
              })}

              {/* Highlighted GPS Destination Target */}
              {wpSvg && (
                <g transform={`translate(${wpSvg.mapX}, ${wpSvg.mapY})`}>
                  <circle r="3.1" fill="none" stroke="#fbbf24" strokeWidth="0.7" />
                  <circle r="1.4" fill="#f59e0b" stroke="#ffffff" strokeWidth="0.4" />
                </g>
              )}

              {/* Active Player Marker */}
              <g transform={`translate(${playerSvg.mapX}, ${playerSvg.mapY})`}>
                <circle r="2.8" fill="none" stroke="#22d3ee" strokeWidth="0.6" />
                <circle r="1.35" fill="#ffffff" />
              </g>
            </svg>
          </div>

          {/* Searchable Jaipur Neighborhoods & Landmarks Panel */}
          <div className="lg:col-span-6 p-5 flex flex-col gap-3 border-t lg:border-t-0 lg:border-l border-slate-800 overflow-hidden">
            <div className="flex items-center gap-2 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search Jaipur (Hawa Mahal, Amer, MI Road, Vaishali, WTP...)"
                className="w-full bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {JAIPUR_ZONES.map((z) => (
                <button
                  key={z}
                  onClick={() => setZone(z)}
                  className={`px-2 py-1 rounded text-[11px] font-semibold cursor-pointer ${
                    zone === z
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {z}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {/* Jaipur Police Commissionerate HQ */}
              <div className="p-2.5 rounded-lg bg-slate-950/75 border border-blue-500/40 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-blue-400 shrink-0" />
                  <div>
                    <div className="text-xs font-semibold text-white">{POLICE_STATION.name}</div>
                    <div className="text-[11px] text-slate-400">MI Road Gate &amp; Helipad · Busted Respawn</div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    onSetWaypoint(POLICE_STATION.gateX, POLICE_STATION.gateZ);
                    onClose();
                  }}
                  className="px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <Navigation className="w-3.5 h-3.5 text-cyan-400" />
                  <span>GPS</span>
                </button>
              </div>

              {/* Player Haveli, Banks, Hospitals & Sanganer Airport */}
              {WORLD_FACILITIES.map((f) => (
                <div
                  key={f.id}
                  className="p-2.5 rounded-lg bg-slate-950/75 border border-slate-700/80 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {f.type === 'home' && <Home className="w-4 h-4 text-amber-400 shrink-0" />}
                    {f.type === 'bank' && <Landmark className="w-4 h-4 text-emerald-400 shrink-0" />}
                    {f.type === 'hospital' && <HeartPulse className="w-4 h-4 text-red-400 shrink-0" />}
                    {f.type === 'airport' && <Plane className="w-4 h-4 text-sky-400 shrink-0" />}
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">{f.name}</div>
                      <div className="text-[11px] text-slate-400 truncate">{f.subtitle}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        onSetWaypoint(f.entryX, f.entryZ);
                        onClose();
                      }}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Navigation className="w-3 h-3 text-cyan-400" />
                      <span>GPS</span>
                    </button>
                    <button
                      onClick={() => {
                        onFastTravelCoords(f.entryX, f.entryZ, f.name);
                        onClose();
                      }}
                      className="px-2 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-[11px] font-semibold text-slate-950 flex items-center gap-1 cursor-pointer"
                    >
                      <MapPin className="w-3 h-3" />
                      <span>Go</span>
                    </button>
                  </div>
                </div>
              ))}

              {filteredLocalities.map((loc) => (
                <div
                  key={loc.id}
                  className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                      <span
                        className="w-2 h-2 rounded-full inline-block shrink-0"
                        style={{ backgroundColor: loc.accent }}
                      />
                      <span className="truncate">{loc.name}</span>
                      <span className="text-[10px] text-slate-500 font-normal">({loc.zone})</span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">{loc.subtitle}</div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        onSetWaypoint(loc.x, loc.z);
                        onClose();
                      }}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Navigation className="w-3 h-3 text-cyan-400" />
                      <span>GPS</span>
                    </button>
                    <button
                      onClick={() => {
                        onFastTravelCoords(loc.x, loc.z, loc.name);
                        onClose();
                      }}
                      className="px-2 py-1 rounded bg-amber-500 hover:bg-amber-400 text-[11px] font-semibold text-slate-950 flex items-center gap-1 cursor-pointer"
                    >
                      <MapPin className="w-3 h-3" />
                      <span>Travel</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-1.5 shrink-0">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Jaipur Open-World Contracts
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-[11px] text-slate-300">
                {MISSIONS_CATALOG.slice(0, 4).map((m) => (
                  <div key={m.id} className="flex items-center justify-between bg-slate-950/70 px-2 py-1 rounded">
                    <span className="flex items-center gap-1 truncate">
                      <Flag className={`w-3 h-3 shrink-0 ${activeMissionId === m.id ? 'text-amber-400' : 'text-slate-500'}`} />
                      <span className="truncate">{m.title}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
