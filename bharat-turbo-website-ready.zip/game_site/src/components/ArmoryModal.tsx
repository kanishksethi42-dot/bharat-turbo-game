import React from 'react';
import { Crosshair, Check, Lock, X } from 'lucide-react';
import { WEAPONS_CATALOG, type WeaponId } from '../types/game';

interface ArmoryModalProps {
  cash: number;
  selectedWeapon: WeaponId;
  unlockedWeapons: WeaponId[];
  onSelectOrUnlock: (id: WeaponId) => void;
  onClose: () => void;
}

export const ArmoryModal: React.FC<ArmoryModalProps> = ({
  cash,
  selectedWeapon,
  unlockedWeapons,
  onSelectOrUnlock,
  onClose,
}) => {
  const weapons = Object.values(WEAPONS_CATALOG);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
              <Crosshair className="w-5 h-5 text-amber-400" />
              <span>Rajasthan Black-Market Armory</span>
            </h2>
            <p className="text-xs text-slate-400">
              Equip weapons for on-foot combat & vehicle drive-bys · Shoot down Police Choppers · Press E / Click to Fire, Q to Cycle
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono-num text-sm font-bold text-emerald-400">
              ₹{cash.toLocaleString('en-IN')}
            </span>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              aria-label="Close Armory"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto">
          {weapons.map((w) => {
            const isUnlocked = unlockedWeapons.includes(w.id);
            const isSelected = selectedWeapon === w.id;
            const canAfford = cash >= w.price;

            return (
              <div
                key={w.id}
                className={`p-4 rounded-xl border flex flex-col justify-between gap-3 ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-400'
                    : 'bg-slate-950/80 border-slate-800'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span
                      className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-900 border border-slate-700"
                      style={{ color: w.color }}
                    >
                      {w.category}
                    </span>
                    {isSelected && (
                      <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        Equipped
                      </span>
                    )}
                  </div>

                  <h3 className="font-display text-lg font-bold text-white">{w.name}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{w.description}</p>

                  <div className="grid grid-cols-3 gap-2 pt-2 text-[11px] font-mono-num">
                    <div className="bg-slate-900 rounded px-2 py-1">
                      <div className="text-slate-500">DMG</div>
                      <div className="text-white font-bold">{w.damage * w.pellets}</div>
                    </div>
                    <div className="bg-slate-900 rounded px-2 py-1">
                      <div className="text-slate-500">RANGE</div>
                      <div className="text-white font-bold">{w.range}m</div>
                    </div>
                    <div className="bg-slate-900 rounded px-2 py-1">
                      <div className="text-slate-500">BLAST</div>
                      <div className="text-white font-bold">
                        {w.explosiveRadius > 0 ? `${w.explosiveRadius}m` : 'Single'}
                      </div>
                    </div>
                  </div>
                </div>

                {isUnlocked ? (
                  <button
                    onClick={() => onSelectOrUnlock(w.id)}
                    className={`w-full py-2.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                  >
                    {isSelected ? 'Equipped' : 'Equip Weapon'}
                  </button>
                ) : (
                  <button
                    disabled={!canAfford}
                    onClick={() => onSelectOrUnlock(w.id)}
                    className={`w-full py-2.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                      canAfford
                        ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                        : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Unlock · ₹{w.price.toLocaleString('en-IN')}</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
