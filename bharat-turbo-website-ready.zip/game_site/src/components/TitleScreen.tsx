import React, { useEffect } from 'react';
import { Cloud, Globe2, Play, ShieldCheck, UserCog, CarFront } from 'lucide-react';
import type { User } from 'firebase/auth';

interface TitleScreenProps {
  user: User | null;
  displayName: string;
  totalConcurrent: number;
  shardId: string;
  webglError: string | null;
  onStart: () => void;
  onOpenGarage: () => void;
  onOpenCharacter: () => void;
  onOpenMultiplayer: () => void;
  onGoogleSignIn: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  user,
  displayName,
  totalConcurrent,
  shardId,
  webglError,
  onStart,
  onOpenGarage,
  onOpenCharacter,
  onOpenMultiplayer,
  onGoogleSignIn,
}) => {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        if (e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement) return;
        e.preventDefault();
        onStart();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onStart]);

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between p-5 sm:p-10 pointer-events-none">
      {/* Fallback key-art if WebGL failed */}
      {webglError && (
        <img
          src="/src/assets/images/bharat_turbo_keyart_1794844019212.jpg"
          alt="Bharat Turbo Sunset in Jaipur"
          referrerPolicy="no-referrer"
          className="fixed inset-0 w-full h-full object-cover -z-10 opacity-75"
        />
      )}

      {/* Subtle left-side scrim for crisp typography contrast over the live 3D India panorama */}
      <div className="fixed inset-0 bg-gradient-to-r from-slate-950/88 via-slate-950/40 to-transparent -z-10" />

      {/* Top Strip: Bespoke SVG Brand Lockup + Cloud Sync Action */}
      <div className="flex items-start justify-between gap-4">
        <div className="pointer-events-auto">
          <svg
            viewBox="0 0 420 96"
            className="w-72 sm:w-96 h-auto drop-shadow-[0_6px_24px_rgba(0,0,0,0.65)]"
            aria-label="Bharat Turbo GTA India"
          >
            <defs>
              <linearGradient id="bt-saffron" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#f97316" />
                <stop offset="50%" stopColor="#fbbf24" />
                <stop offset="100%" stopColor="#ef4444" />
              </linearGradient>
            </defs>
            <polygon points="8,16 34,16 24,40 0,40" fill="url(#bt-saffron)" />
            <polygon points="39,16 53,16 43,40 29,40" fill="#10b981" />
            <text
              x="62"
              y="40"
              fill="#ffffff"
              fontFamily="Chakra Petch, sans-serif"
              fontWeight="700"
              fontSize="36"
              letterSpacing="2"
            >
              BHARAT TURBO
            </text>
            <rect x="62" y="50" width="290" height="2" fill="url(#bt-saffron)" />
            <text
              x="62"
              y="74"
              fill="#cbd5e1"
              fontFamily="Plus Jakarta Sans, sans-serif"
              fontWeight="600"
              fontSize="14"
              letterSpacing="3.5"
            >
              OPEN-WORLD INDIA EDITION
            </text>
          </svg>
        </div>

        <div className="pointer-events-auto flex items-center gap-3">
          {user ? (
            <button
              onClick={onOpenMultiplayer}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-slate-900/95 border border-emerald-500/40 text-xs sm:text-sm font-medium text-emerald-300 hover:bg-slate-800 transition-colors whitespace-nowrap"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Cloud Synced · {displayName}</span>
            </button>
          ) : (
            <button
              onClick={onGoogleSignIn}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-slate-900/95 border border-slate-700 text-xs sm:text-sm font-medium text-slate-200 hover:border-amber-400 hover:text-white transition-colors whitespace-nowrap"
            >
              <Cloud className="w-4 h-4 text-amber-400" />
              <span>Sign In for Cross-Platform Save</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Title Action Block (Left-aligned, leaving 40%+ clean viewport space) */}
      <div className="max-w-lg pointer-events-auto space-y-5 my-auto">
        <div className="space-y-2">
          <p className="text-xs sm:text-sm font-medium text-amber-400 tracking-wide">
            All of Jaipur · Hawa Mahal · Amer Fort · MI Road · Jal Mahal · Sanganer Airport
          </p>
          <h1 className="font-display text-3xl sm:text-5xl font-bold text-white leading-tight text-balance">
            Rule the Pink City
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-md">
            Drive hypercars, autos &amp; motorcycles past Hawa Mahal, City Palace, Jal Mahal, World Trade Park, and Amer Fort. Equip heavy weapons, fly out of Sanganer Airport, and sync saves between phone and PC.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onStart}
            className="flex items-center gap-2.5 px-7 py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-base tracking-wide transition-transform active:scale-95 shadow-lg shadow-amber-500/20 whitespace-nowrap cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>Enter Jaipur Roam</span>
          </button>

          <button
            onClick={onOpenCharacter}
            className="flex items-center gap-2 px-4 py-3.5 rounded-lg bg-slate-900/92 border border-slate-700 hover:border-slate-500 text-white text-sm font-medium transition-colors whitespace-nowrap cursor-pointer"
          >
            <UserCog className="w-4 h-4 text-amber-400" />
            <span>Character</span>
          </button>

          <button
            onClick={onOpenGarage}
            className="flex items-center gap-2 px-4 py-3.5 rounded-lg bg-slate-900/92 border border-slate-700 hover:border-slate-500 text-white text-sm font-medium transition-colors whitespace-nowrap cursor-pointer"
          >
            <CarFront className="w-4 h-4 text-amber-400" />
            <span>Hypercars</span>
          </button>

          <button
            onClick={onOpenMultiplayer}
            className="flex items-center gap-2 px-4 py-3.5 rounded-lg bg-slate-900/92 border border-slate-700 hover:border-slate-500 text-white text-sm font-medium transition-colors whitespace-nowrap cursor-pointer"
          >
            <Globe2 className="w-4 h-4 text-cyan-400" />
            <span className="font-mono-num">{totalConcurrent} Online · {shardId}</span>
          </button>
        </div>
      </div>

      {/* Bottom single flat control-hint line */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300/90">
        <p className="font-medium tracking-wide">
          WASD / Touch Drive · E / Click Fire Weapon · Q Cycle Weapon · F Exit / Enter Car · M Jaipur Map · Esc Pause
        </p>
      </div>
    </div>
  );
};
