import { useCallback, useEffect, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import { GameEngine, type TouchInputState } from './engine/GameEngine';
import { SoundEngine } from './services/audioEngine';
import { MultiplayerClient } from './services/multiplayerClient';
import {
  fetchLeaderboard,
  loadCloudSave,
  loadLocalSave,
  saveCloudProgress,
  saveLocal,
  signInWithGoogle,
  signOutAccount,
  subscribeAuth,
} from './services/firebaseService';
import {
  DEFAULT_SAVE_DATA,
  VEHICLE_CATALOG,
  WEAPONS_CATALOG,
  WORLD_FACILITIES,
  resolveRajasthanDistrict,
  type CameraMode,
  type CharacterConfig,
  type ChatMessage,
  type DistrictId,
  type GraphicsPreset,
  type LeaderboardEntry,
  type LiveTelemetry,
  type LobbySummary,
  type MissionDef,
  type PlayerSaveData,
  type RemotePeerState,
  type VehicleId,
  type WeaponId,
  type WeatherMode,
} from './types/game';
import type { BlueprintBuilding } from './engine/indiaWorldBuilder';
import { TitleScreen } from './components/TitleScreen';
import { HudOverlay } from './components/HudOverlay';
import { TouchControls } from './components/TouchControls';
import { IndiaMapModal } from './components/IndiaMapModal';
import { CharacterStudioModal } from './components/CharacterStudioModal';
import { GarageModal } from './components/GarageModal';
import { ArmoryModal } from './components/ArmoryModal';
import { MissionPanel } from './components/MissionPanel';
import { MultiplayerModal } from './components/MultiplayerModal';
import { FacilityModal } from './components/FacilityModal';

type ActiveModal =
  | 'none'
  | 'map'
  | 'missions'
  | 'garage'
  | 'armory'
  | 'character'
  | 'multiplayer'
  | 'facility'
  | 'pause';

const INITIAL_TELEMETRY: LiveTelemetry = {
  speedKmh: 0,
  rpmRatio: 0.15,
  gear: 1,
  nitro: 100,
  onFoot: false,
  inAircraft: false,
  altitudeM: 0,
  wantedLevel: 0,
  bustedProgress: 0,
  health: 100,
  maxHealth: 100,
  playerX: 160,
  playerZ: -80,
  playerYaw: 0,
  currentDistrict: 'jaipur',
  currentLocalityName: 'Johari & Bapu Bazaar',
  currentZoneName: 'Walled Pink City',
  selectedWeapon: 'pistol',
  nearbyFacilityId: null,
  activeMissionId: null,
  missionLabel: null,
  missionProgress: 0,
  missionTarget: 0,
  missionTimeLeft: 0,
  canEnterVehicle: false,
  airtimeSec: 0,
  driftScore: 0,
  policeCount: 0,
  helicopterCount: 0,
};

const WEATHER_ORDER: WeatherMode[] = ['sunset', 'monsoon', 'night', 'clear', 'sandstorm'];
const GRAPHICS_ORDER: GraphicsPreset[] = ['ultra4k', 'high', 'mobile'];

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const soundRef = useRef<SoundEngine | null>(null);
  const mpRef = useRef<MultiplayerClient | null>(null);

  const [saveData, setSaveData] = useState<PlayerSaveData>(() => loadLocalSave());
  const saveRef = useRef<PlayerSaveData>(saveData);
  saveRef.current = saveData;

  const [user, setUser] = useState<User | null>(null);
  const userRef = useRef<User | null>(null);
  userRef.current = user;

  const [isPlaying, setIsPlaying] = useState(false);
  const [activeModal, setActiveModal] = useState<ActiveModal>('none');
  const [activeFacilityId, setActiveFacilityId] = useState<string | null>(null);
  const [blueprintBuildings, setBlueprintBuildings] = useState<BlueprintBuilding[]>([]);
  const [cameraMode, setCameraMode] = useState<CameraMode>('chase');
  const [muted, setMuted] = useState(false);
  const [touchEnabled, setTouchEnabled] = useState(() =>
    typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches,
  );
  const [webglError, setWebglError] = useState<string | null>(null);
  const [bannerMessage, setBannerMessage] = useState<string | null>(null);
  const [telemetry, setTelemetry] = useState<LiveTelemetry>(INITIAL_TELEMETRY);
  const nearbyFacilityRef = useRef<string | null>(null);
  nearbyFacilityRef.current = telemetry.nearbyFacilityId;

  // Multiplayer & Cloud state
  const [mpConnected, setMpConnected] = useState(false);
  const [currentShardId, setCurrentShardId] = useState('IN-GLOBAL-01');
  const [shardPlayers, setShardPlayers] = useState(1);
  const [totalConcurrent, setTotalConcurrent] = useState(1);
  const [lobbies, setLobbies] = useState<LobbySummary[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [remotePeers, setRemotePeers] = useState<RemotePeerState[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [syncStatus, setSyncStatus] = useState('Local browser storage active');

  const showBanner = useCallback((msg: string) => {
    setBannerMessage(msg);
    window.setTimeout(() => {
      setBannerMessage((curr) => (curr === msg ? null : curr));
    }, 3600);
  }, []);

  const persistProgress = useCallback((next: PlayerSaveData, immediateCloud = false) => {
    setSaveData(next);
    saveRef.current = next;
    saveLocal(next);
    if (immediateCloud && userRef.current) {
      setSyncStatus('Syncing to Cloud Firestore...');
      void saveCloudProgress(userRef.current, next)
        .then(() => setSyncStatus(`Synced at ${new Date().toLocaleTimeString()}`))
        .catch(() => setSyncStatus('Cloud sync queued locally'));
    }
  }, []);

  // Initialize Sound, Three.js GameEngine, and WebSocket Multiplayer once
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;

    const sound = new SoundEngine();
    soundRef.current = sound;

    const mp = new MultiplayerClient();
    mpRef.current = mp;

    const initialSave = saveRef.current;
    const engine = new GameEngine(
      mount,
      sound,
      {
        vehicleId: initialSave.selectedVehicle,
        vehicleColor: initialSave.vehicleColor,
        weaponId: initialSave.selectedWeapon,
        characterConfig: initialSave.characterConfig,
        weather: initialSave.weatherPref,
        graphics: initialSave.graphicsPreset,
        district: initialSave.lastDistrict,
        totalSmashed: initialSave.destructiblesSmashed,
        bestSpeedKmh: initialSave.topSpeedKmh,
        maxHealth: initialSave.maxHealth,
      },
      {
        onTelemetry: (t) => setTelemetry(t),
        onMissionComplete: (mission) => {
          const curr = saveRef.current;
          const completed = curr.completedMissions.includes(mission.id)
            ? curr.completedMissions
            : [...curr.completedMissions, mission.id];
          const updated: PlayerSaveData = {
            ...curr,
            cash: curr.cash + mission.rewardCash,
            reputation: curr.reputation + mission.rewardRep,
            completedMissions: completed,
          };
          persistProgress(updated, true);
          showBanner(`Mission Cleared: +₹${mission.rewardCash.toLocaleString('en-IN')} · +${mission.rewardRep} REP`);
        },
        onMissionFailed: (mission, reason) => {
          showBanner(`${mission.title} Failed — ${reason}`);
        },
        onPlayerBusted: (fineAmount, wantedStars) => {
          const curr = saveRef.current;
          const deducted = Math.min(curr.cash, fineAmount);
          const updated: PlayerSaveData = {
            ...curr,
            cash: Math.max(0, curr.cash - deducted),
          };
          persistProgress(updated, true);
          showBanner(
            `BUSTED (${wantedStars}★)! Teleported to Central Thana Gate · -₹${deducted.toLocaleString('en-IN')}`,
          );
        },
        onPlayerWasted: (billAmount, hospitalName) => {
          const curr = saveRef.current;
          const deducted = Math.min(curr.cash, billAmount);
          const updated: PlayerSaveData = {
            ...curr,
            cash: Math.max(0, curr.cash - deducted),
          };
          persistProgress(updated, true);
          showBanner(
            `WASTED! Discharged from ${hospitalName} · Medical Bill -₹${deducted.toLocaleString('en-IN')}`,
          );
        },
        onPropSmashed: (propId, vx, vz, totalCount) => {
          mp.sendPropSmash(propId, vx, vz);
          const curr = saveRef.current;
          const next: PlayerSaveData = {
            ...curr,
            destructiblesSmashed: totalCount,
            reputation: curr.reputation + 15,
            cash: curr.cash + 500,
          };
          saveRef.current = next;
          setSaveData(next);
          saveLocal(next);
        },
        onCombatReward: (rewardCash, rewardRep, label) => {
          const curr = saveRef.current;
          const next: PlayerSaveData = {
            ...curr,
            cash: curr.cash + rewardCash,
            reputation: curr.reputation + rewardRep,
          };
          persistProgress(next, true);
          showBanner(label);
        },
        onTopSpeedRecord: (speedKmh) => {
          const curr = saveRef.current;
          if (speedKmh > curr.topSpeedKmh) {
            const next = { ...curr, topSpeedKmh: speedKmh };
            saveRef.current = next;
            setSaveData(next);
            saveLocal(next);
          }
        },
        onWebglError: (msg) => setWebglError(msg),
      },
    );
    engineRef.current = engine;
    setBlueprintBuildings(engine.getBlueprintBuildings());

    // Multiplayer callbacks
    mp.onConnectionChange = (connected, sid) => {
      setMpConnected(connected);
      setCurrentShardId(sid);
    };
    mp.onShardState = (state) => {
      setCurrentShardId(state.shardId);
      setShardPlayers(state.shardPlayers);
      setTotalConcurrent(state.totalConcurrent);
      setRemotePeers(state.peers);
      engine.syncRemotePeers(state.peers);
    };
    mp.onChatMessage = (msg) => {
      setChatMessages((prev) => [...prev.slice(-30), msg]);
    };
    mp.onPropSmashed = (propId, vx, vz) => {
      engine.applyRemotePropSmash(propId, vx, vz);
    };

    const snap = engine.getNetworkSnapshot();
    mp.connect({
      name: initialSave.displayName,
      shardId: 'IN-GLOBAL-01',
      ...snap,
    });

    // Periodic 15Hz state upload to multiplayer shard
    const netTimer = window.setInterval(() => {
      if (!engineRef.current || !mpRef.current) return;
      const s = engineRef.current.getNetworkSnapshot();
      mpRef.current.sendPlayerState({
        name: saveRef.current.displayName,
        ...s,
      });
    }, 66);

    // Periodic auto-save to Cloud Firestore every 25s when signed in
    const cloudTimer = window.setInterval(() => {
      if (userRef.current) {
        void saveCloudProgress(userRef.current, saveRef.current).catch(() => {});
      }
    }, 25000);

    return () => {
      clearInterval(netTimer);
      clearInterval(cloudTimer);
      mp.dispose();
      engine.dispose();
      sound.dispose();
    };
  }, [persistProgress, showBanner]);

  // Firebase Auth listener for Cross-Platform Cloud Saves
  useEffect(() => {
    const unsub = subscribeAuth(async (fbUser) => {
      setUser(fbUser);
      if (fbUser) {
        setSyncStatus('Loading Cross-Platform Cloud Save...');
        try {
          const cloudData = await loadCloudSave(fbUser);
          setSaveData(cloudData);
          saveRef.current = cloudData;
          engineRef.current?.setVehicle(cloudData.selectedVehicle, cloudData.vehicleColor);
          engineRef.current?.setWeapon(cloudData.selectedWeapon);
          engineRef.current?.setCharacterConfig(cloudData.characterConfig);
          engineRef.current?.setWeather(cloudData.weatherPref);
          engineRef.current?.setGraphicsPreset(cloudData.graphicsPreset);
          engineRef.current?.setMaxHealth(cloudData.maxHealth);
          engineRef.current?.healPlayer();
          setSyncStatus('Cross-Platform Save Synced');
          const lb = await fetchLeaderboard();
          setLeaderboard(lb);
        } catch {
          setSyncStatus('Using local cache (Cloud sync retrying)');
        }
      } else {
        setSyncStatus('Local browser storage active');
      }
    });
    return () => unsub();
  }, []);

  // Passive Bank Interest Yield (+1% every 60s of active play)
  useEffect(() => {
    if (!isPlaying) return;
    const interestTimer = window.setInterval(() => {
      const curr = saveRef.current;
      if (curr.bankBalance > 0) {
        const gain = Math.max(250, Math.round(curr.bankBalance * 0.01));
        persistProgress({ ...curr, bankBalance: curr.bankBalance + gain }, false);
      }
    }, 60000);
    return () => clearInterval(interestTimer);
  }, [isPlaying, persistProgress]);

  // Pause simulation when modal open
  useEffect(() => {
    engineRef.current?.setPaused(activeModal !== 'none');
  }, [activeModal]);

  const handleCycleWeapon = useCallback(() => {
    const curr = saveRef.current;
    const unlocked = curr.unlockedWeapons.length ? curr.unlockedWeapons : (['fists', 'pistol', 'smg'] as WeaponId[]);
    const idx = unlocked.indexOf(curr.selectedWeapon);
    const nextW = unlocked[(idx + 1) % unlocked.length];
    engineRef.current?.setWeapon(nextW);
    persistProgress({ ...curr, selectedWeapon: nextW }, false);
    showBanner(`Equipped: ${WEAPONS_CATALOG[nextW].name}`);
  }, [persistProgress, showBanner]);

  // Global hotkeys (M, G, B, Q, 1-6, Esc)
  useEffect(() => {
    const weaponSlots: WeaponId[] = ['fists', 'pistol', 'smg', 'shotgun', 'ak47', 'rpg'];
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (!isPlaying) return;
      if (e.code === 'Escape') {
        setActiveModal((curr) => (curr === 'none' ? 'pause' : 'none'));
      } else if (e.code === 'KeyM') {
        setActiveModal((curr) => (curr === 'map' ? 'none' : 'map'));
      } else if (e.code === 'KeyG') {
        setActiveModal((curr) => (curr === 'garage' ? 'none' : 'garage'));
      } else if (e.code === 'KeyB') {
        setActiveModal((curr) => (curr === 'armory' ? 'none' : 'armory'));
      } else if (e.code === 'KeyV' && activeModal === 'none' && nearbyFacilityRef.current) {
        setActiveFacilityId(nearbyFacilityRef.current);
        setActiveModal('facility');
      } else if (e.code === 'KeyQ' && activeModal === 'none') {
        handleCycleWeapon();
      } else if (e.code.startsWith('Digit') && activeModal === 'none') {
        const slot = Number(e.code.replace('Digit', '')) - 1;
        const w = weaponSlots[slot];
        if (w && saveRef.current.unlockedWeapons.includes(w)) {
          engineRef.current?.setWeapon(w);
          persistProgress({ ...saveRef.current, selectedWeapon: w }, false);
          showBanner(`Equipped: ${WEAPONS_CATALOG[w].name}`);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isPlaying, activeModal, handleCycleWeapon, persistProgress, showBanner]);

  const handleStartGame = useCallback(() => {
    soundRef.current?.init();
    engineRef.current?.setTitleShowcase(false);
    setIsPlaying(true);
    setActiveModal('none');
  }, []);

  const handleGoogleSignIn = useCallback(async () => {
    try {
      await signInWithGoogle();
      showBanner('Google Account Connected — Cross-Platform Save Active');
    } catch {
      showBanner('Sign-in cancelled or blocked by popup settings');
    }
  }, [showBanner]);

  const handleSignOut = useCallback(async () => {
    await signOutAccount();
    setSaveData((prev) => ({ ...prev, userId: 'guest' }));
    showBanner('Signed out — Switched to local save');
  }, [showBanner]);

  const handleRefreshLobbies = useCallback(async () => {
    if (!mpRef.current) return;
    try {
      const data = await mpRef.current.fetchLobbies();
      setLobbies(data.lobbies);
      setTotalConcurrent(data.totalConcurrentPlayers);
      if (userRef.current) {
        const lb = await fetchLeaderboard();
        setLeaderboard(lb);
      }
    } catch {
      // Ignore transient network errors
    }
  }, []);

  const handleSelectOrUnlockVehicle = (id: VehicleId) => {
    const spec = VEHICLE_CATALOG[id];
    const curr = saveRef.current;
    const isUnlocked = curr.unlockedVehicles.includes(id);

    if (!isUnlocked) {
      if (curr.cash < spec.price) return;
      const next: PlayerSaveData = {
        ...curr,
        cash: curr.cash - spec.price,
        unlockedVehicles: [...curr.unlockedVehicles, id],
        selectedVehicle: id,
        vehicleColor: spec.defaultColor,
      };
      persistProgress(next, true);
      engineRef.current?.setVehicle(id, spec.defaultColor);
      showBanner(`Unlocked ${spec.brand} ${spec.name}`);
    } else {
      const next: PlayerSaveData = {
        ...curr,
        selectedVehicle: id,
        vehicleColor: spec.defaultColor,
      };
      persistProgress(next, true);
      engineRef.current?.setVehicle(id, spec.defaultColor);
    }
    setActiveModal('none');
  };

  const handleSelectOrUnlockWeapon = (id: WeaponId) => {
    const spec = WEAPONS_CATALOG[id];
    const curr = saveRef.current;
    const isUnlocked = curr.unlockedWeapons.includes(id);

    if (!isUnlocked) {
      if (curr.cash < spec.price) return;
      const next: PlayerSaveData = {
        ...curr,
        cash: curr.cash - spec.price,
        unlockedWeapons: [...curr.unlockedWeapons, id],
        selectedWeapon: id,
      };
      persistProgress(next, true);
      engineRef.current?.setWeapon(id);
      showBanner(`Unlocked ${spec.name}`);
    } else {
      const next: PlayerSaveData = {
        ...curr,
        selectedWeapon: id,
      };
      persistProgress(next, true);
      engineRef.current?.setWeapon(id);
    }
    setActiveModal('none');
  };

  const handleChangeVehicleColor = (hex: string) => {
    engineRef.current?.setPaintColor(hex);
    persistProgress({ ...saveRef.current, vehicleColor: hex }, true);
  };

  const handleChangeCharacter = (cfg: CharacterConfig) => {
    engineRef.current?.setCharacterConfig(cfg);
    persistProgress({ ...saveRef.current, characterConfig: cfg }, false);
  };

  const handleCycleWeather = () => {
    const next = WEATHER_ORDER[(WEATHER_ORDER.indexOf(saveData.weatherPref) + 1) % WEATHER_ORDER.length];
    engineRef.current?.setWeather(next);
    persistProgress({ ...saveData, weatherPref: next }, false);
    showBanner(`Weather: ${next.toUpperCase()}`);
  };

  const handleCycleGraphics = () => {
    const next = GRAPHICS_ORDER[(GRAPHICS_ORDER.indexOf(saveData.graphicsPreset) + 1) % GRAPHICS_ORDER.length];
    engineRef.current?.setGraphicsPreset(next);
    persistProgress({ ...saveData, graphicsPreset: next }, false);
    showBanner(`Graphics Preset: ${next === 'ultra4k' ? 'ULTRA 4K + REFLECTIONS' : next.toUpperCase()}`);
  };

  const handleCycleCamera = () => {
    if (!engineRef.current) return;
    const next = engineRef.current.cycleCamera();
    setCameraMode(next);
  };

  const handleToggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundRef.current?.setMuted(next);
  };

  const handleTouchChange = useCallback((patch: Partial<TouchInputState>) => {
    soundRef.current?.init();
    engineRef.current?.setTouchInput(patch);
  }, []);

  const handleOpenFacility = useCallback((facilityId: string) => {
    setActiveFacilityId(facilityId);
    setActiveModal('facility');
  }, []);

  const activeFacility = activeFacilityId
    ? WORLD_FACILITIES.find((f) => f.id === activeFacilityId) || null
    : null;

  const activeWaypoint = engineRef.current?.getActiveWaypoint() || null;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950">
      {/* Isolated 3D WebGL Mount Container */}
      <div ref={canvasMountRef} className="fixed inset-0 w-full h-full" />

      {/* Title Screen */}
      {!isPlaying && activeModal === 'none' && (
        <TitleScreen
          user={user}
          displayName={saveData.displayName}
          totalConcurrent={totalConcurrent}
          shardId={currentShardId}
          webglError={webglError}
          onStart={handleStartGame}
          onOpenGarage={() => setActiveModal('garage')}
          onOpenCharacter={() => setActiveModal('character')}
          onOpenMultiplayer={() => setActiveModal('multiplayer')}
          onGoogleSignIn={handleGoogleSignIn}
        />
      )}

      {/* Playing HUD & Phone Touch Controls */}
      {isPlaying && (
        <>
          <HudOverlay
            telemetry={telemetry}
            cash={saveData.cash}
            bankBalance={saveData.bankBalance}
            reputation={saveData.reputation}
            selectedVehicle={saveData.selectedVehicle}
            weather={saveData.weatherPref}
            graphics={saveData.graphicsPreset}
            cameraMode={cameraMode}
            muted={muted}
            touchEnabled={touchEnabled}
            shardId={currentShardId}
            shardPlayers={shardPlayers}
            totalConcurrent={totalConcurrent}
            bannerMessage={bannerMessage}
            blueprintBuildings={blueprintBuildings}
            activeWaypoint={activeWaypoint}
            onOpenMap={() => setActiveModal('map')}
            onOpenMissions={() => setActiveModal('missions')}
            onOpenGarage={() => setActiveModal('garage')}
            onOpenArmory={() => setActiveModal('armory')}
            onOpenCharacter={() => setActiveModal('character')}
            onOpenMultiplayer={() => setActiveModal('multiplayer')}
            onEnterFacility={handleOpenFacility}
            onCycleWeapon={handleCycleWeapon}
            onCycleWeather={handleCycleWeather}
            onCycleGraphics={handleCycleGraphics}
            onCycleCamera={handleCycleCamera}
            onToggleMute={handleToggleMute}
            onToggleTouch={() => setTouchEnabled((t) => !t)}
            onToggleVehicle={() => engineRef.current?.toggleOnFoot()}
            onPause={() => setActiveModal('pause')}
          />

          {touchEnabled && activeModal === 'none' && (
            <TouchControls
              onFoot={telemetry.onFoot}
              inAircraft={telemetry.inAircraft}
              onTouchChange={handleTouchChange}
              onToggleVehicle={() => engineRef.current?.toggleOnFoot()}
              onCycleWeapon={handleCycleWeapon}
              onHorn={() => engineRef.current?.playPlayerHorn()}
            />
          )}
        </>
      )}

      {/* Modals */}
      {activeModal === 'map' && (
        <IndiaMapModal
          playerX={telemetry.playerX}
          playerZ={telemetry.playerZ}
          activeMissionId={telemetry.activeMissionId}
          activeWaypoint={activeWaypoint}
          peers={remotePeers}
          onFastTravel={(distId: DistrictId) => {
            const dist = resolveRajasthanDistrict(distId);
            engineRef.current?.teleportToDistrict(distId);
            persistProgress({ ...saveData, lastDistrict: dist.id }, false);
            showBanner(`Fast Traveled to ${dist.name}`);
          }}
          onFastTravelCoords={(wx, wz, label) => {
            engineRef.current?.teleportToCoords(wx, wz);
            showBanner(`Arrived at ${label}`);
          }}
          onSetWaypoint={(wx, wz) => {
            engineRef.current?.setCustomWaypoint(wx, wz);
            showBanner('GPS Waypoint Beam Activated');
          }}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'missions' && (
        <MissionPanel
          activeMissionId={telemetry.activeMissionId}
          completedMissions={saveData.completedMissions}
          onStartMission={(m: MissionDef) => {
            engineRef.current?.startMission(m);
            showBanner(`Mission Started: ${m.title}`);
          }}
          onCancelMission={() => {
            engineRef.current?.cancelMission();
            showBanner('Mission Aborted');
          }}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'garage' && (
        <GarageModal
          cash={saveData.cash}
          selectedVehicle={saveData.selectedVehicle}
          vehicleColor={saveData.vehicleColor}
          unlockedVehicles={saveData.unlockedVehicles}
          onSelectOrUnlock={handleSelectOrUnlockVehicle}
          onChangeColor={handleChangeVehicleColor}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'armory' && (
        <ArmoryModal
          cash={saveData.cash}
          selectedWeapon={saveData.selectedWeapon}
          unlockedWeapons={saveData.unlockedWeapons}
          onSelectOrUnlock={handleSelectOrUnlockWeapon}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'character' && (
        <CharacterStudioModal
          displayName={saveData.displayName}
          config={saveData.characterConfig}
          onChangeName={(name) => persistProgress({ ...saveData, displayName: name || 'Jaipur Driver' }, false)}
          onChangeConfig={handleChangeCharacter}
          onClose={() => {
            persistProgress(saveRef.current, true);
            setActiveModal('none');
          }}
        />
      )}

      {activeModal === 'multiplayer' && (
        <MultiplayerModal
          user={user}
          connected={mpConnected}
          currentShardId={currentShardId}
          shardPlayers={shardPlayers}
          totalConcurrent={totalConcurrent}
          lobbies={lobbies}
          chatMessages={chatMessages}
          leaderboard={leaderboard}
          syncStatus={syncStatus}
          onRefreshLobbies={handleRefreshLobbies}
          onSwitchShard={(sid) => mpRef.current?.switchShard(sid)}
          onSendChat={(text) => mpRef.current?.sendChat(text)}
          onGoogleSignIn={handleGoogleSignIn}
          onSignOut={handleSignOut}
          onForceCloudSync={() => {
            if (userRef.current) persistProgress(saveRef.current, true);
          }}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'facility' && activeFacility && (
        <FacilityModal
          facility={activeFacility}
          cash={saveData.cash}
          bankBalance={saveData.bankBalance}
          health={telemetry.health}
          maxHealth={saveData.maxHealth}
          homeLevel={saveData.homeLevel}
          wantedLevel={telemetry.wantedLevel}
          onBankDeposit={(amt) => {
            const curr = saveRef.current;
            const deposit = Math.min(curr.cash, amt);
            if (deposit <= 0) return;
            persistProgress(
              { ...curr, cash: curr.cash - deposit, bankBalance: curr.bankBalance + deposit },
              true,
            );
            showBanner(`Deposited ₹${deposit.toLocaleString('en-IN')} to Vault`);
          }}
          onBankWithdraw={(amt) => {
            const curr = saveRef.current;
            const wd = Math.min(curr.bankBalance, amt);
            if (wd <= 0) return;
            persistProgress(
              { ...curr, cash: curr.cash + wd, bankBalance: curr.bankBalance - wd },
              true,
            );
            showBanner(`Withdrew ₹${wd.toLocaleString('en-IN')} to Pocket`);
          }}
          onClaimBankInterest={() => {
            const curr = saveRef.current;
            const gain = Math.max(500, Math.round(curr.bankBalance * 0.025));
            persistProgress({ ...curr, bankBalance: curr.bankBalance + gain }, true);
            showBanner(`Vault Interest Collected: +₹${gain.toLocaleString('en-IN')}`);
          }}
          onHospitalHeal={() => {
            const curr = saveRef.current;
            const cost = curr.cash >= 500 ? 500 : 0;
            engineRef.current?.healPlayer();
            if (cost > 0) {
              persistProgress({ ...curr, cash: curr.cash - cost }, true);
            }
            showBanner('Restored to Full Health');
          }}
          onHospitalUpgradeMaxHp={() => {
            const curr = saveRef.current;
            const cost = 18000;
            if (curr.maxHealth >= 200 || curr.cash < cost) return;
            const nextHp = Math.min(200, curr.maxHealth + 25);
            engineRef.current?.healPlayer(undefined, nextHp);
            persistProgress({ ...curr, cash: curr.cash - cost, maxHealth: nextHp }, true);
            showBanner(`Max Health Increased to ${nextHp} HP!`);
          }}
          onHomeRest={() => {
            const curr = saveRef.current;
            const rent = curr.homeLevel * 7500;
            engineRef.current?.restAtHome();
            persistProgress({ ...curr, cash: curr.cash + rent }, true);
            showBanner(`Rested at Royal Haveli · Heat Cleared · +₹${rent.toLocaleString('en-IN')}`);
          }}
          onHomeUpgrade={() => {
            const curr = saveRef.current;
            const cost = curr.homeLevel === 1 ? 65000 : curr.homeLevel === 2 ? 140000 : 0;
            if (curr.homeLevel >= 3 || cost === 0 || curr.cash < cost) return;
            const nextLevel = curr.homeLevel + 1;
            const nextHp = Math.min(200, curr.maxHealth + 25);
            engineRef.current?.healPlayer(undefined, nextHp);
            persistProgress(
              { ...curr, cash: curr.cash - cost, homeLevel: nextLevel, maxHealth: nextHp },
              true,
            );
            showBanner(`Haveli Upgraded to Tier ${nextLevel} · Max Health ${nextHp} HP!`);
          }}
          onOpenGarage={() => setActiveModal('garage')}
          onOpenCharacter={() => setActiveModal('character')}
          onBoardAirportJet={() => {
            soundRef.current?.init();
            engineRef.current?.boardAirportJet(activeFacility.id);
            setActiveModal('none');
            showBanner('Private Jet Cleared for Takeoff · [W] Throttle · [Space] Climb');
          }}
          onCharterFlight={(wx, wz, label, cost) => {
            const curr = saveRef.current;
            if (cost > 0 && curr.cash >= cost) {
              persistProgress({ ...curr, cash: curr.cash - cost }, true);
            }
            engineRef.current?.teleportToCoords(wx, wz);
            setActiveModal('none');
            showBanner(`Charter Flight Landed at ${label}`);
          }}
          onClose={() => setActiveModal('none')}
        />
      )}

      {activeModal === 'pause' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/85">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-xl p-6 space-y-4 shadow-2xl">
            <div>
              <h2 className="font-display text-2xl font-bold text-white">Game Paused</h2>
              <p className="text-xs text-slate-400">Bharat Turbo · {currentShardId}</p>
            </div>
            <div className="space-y-2.5">
              <button
                onClick={() => setActiveModal('none')}
                className="w-full py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm cursor-pointer"
              >
                Resume Driving
              </button>
              {telemetry.wantedLevel > 0 && saveData.cash >= 10000 && (
                <button
                  onClick={() => {
                    engineRef.current?.clearWanted();
                    persistProgress({ ...saveData, cash: saveData.cash - 10000 }, true);
                    setActiveModal('none');
                    showBanner('Police Heat Cleared (-₹10,000)');
                  }}
                  className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs cursor-pointer"
                >
                  Clear Wanted Level (₹10,000)
                </button>
              )}
              <button
                onClick={() => {
                  const fresh = { ...DEFAULT_SAVE_DATA, userId: saveData.userId, displayName: saveData.displayName };
                  persistProgress(fresh, true);
                  engineRef.current?.setVehicle(fresh.selectedVehicle, fresh.vehicleColor);
                  engineRef.current?.setCharacterConfig(fresh.characterConfig);
                  engineRef.current?.setWeapon(fresh.selectedWeapon);
                  engineRef.current?.setMaxHealth(fresh.maxHealth);
                  engineRef.current?.healPlayer();
                  setActiveModal('none');
                }}
                className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs cursor-pointer"
              >
                Reset Career Progress
              </button>
              <button
                onClick={() => {
                  setActiveModal('none');
                  setIsPlaying(false);
                  engineRef.current?.setTitleShowcase(true);
                }}
                className="w-full py-2.5 rounded-lg bg-slate-950 border border-slate-700 hover:border-slate-500 text-slate-300 font-semibold text-xs cursor-pointer"
              >
                Return to Title Screen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
