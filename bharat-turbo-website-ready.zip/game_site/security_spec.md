# Firestore Security Specification — Bharat Turbo (GTA India)

## 1. Data Invariants
1. **Strict Ownership (`/saves/{userId}`)**: A save document can only be created, read, updated, or deleted by the authenticated, email-verified user whose `request.auth.uid == userId` and `incoming().userId == userId`.
2. **No PII Storage**: Neither `/saves` nor `/leaderboard` stores email, phone, or physical addresses.
3. **Immutable Identity & Creation Timestamp**: On update, `userId` and `createdAt` must remain strictly equal to `existing().userId` and `existing().createdAt`.
4. **Server Timestamps**: `createdAt` (on create) and `updatedAt` (on create & update) must equal `request.time`.
5. **Bounded Arrays & Strings**: `unlockedVehicles` size `<= 20`, `completedMissions` size `<= 20`, `displayName` length `1..48`, `vehicleColor` matches `^#[0-9a-fA-F]{6}$`, numeric stats bounded to sane positive limits.
6. **Verified Accounts**: All mutations require `request.auth.token.email_verified == true`.

## 2. Adversarial "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Unauthenticated Read on `/saves/uid1`**: `auth = null` -> DENIED.
2. **Cross-User Read on `/saves/uid2` by `uid1`**: `auth.uid = 'uid1'` -> DENIED.
3. **Identity Spoof on Create `/saves/uid1`**: `auth.uid = 'uid1'`, payload `userId: 'uid2'` -> DENIED.
4. **Shadow/Ghost Field on Create `/saves/uid1`**: Extra field `isAdmin: true` -> DENIED by `keys().hasOnly(...)`.
5. **Unverified Email Mutation**: `auth.token.email_verified = false` -> DENIED.
6. **Invalid Document ID Poisoning**: `/saves/invalid!id$with*chars` -> DENIED by `isValidId(userId)`.
7. **Oversized `displayName` (> 48 chars)**: `displayName: "A".repeat(200)` -> DENIED.
8. **Malformed Paint Hex**: `vehicleColor: "javascript:alert(1)"` -> DENIED by regex guard.
9. **Unbounded Array Injection**: `unlockedVehicles` with 15 items -> DENIED (`size() <= 10`).
10. **Client Timestamp Forgery**: `updatedAt: new Date(2099, 0, 1)` -> DENIED (`updatedAt == request.time`).
11. **Immortal Field Tampering on Update**: Modifying `createdAt` or `userId` during update -> DENIED.
12. **Blanket List Scraping on `/saves`**: `list` query on `/saves` by `uid1` without `where('userId', '==', 'uid1')` -> DENIED by `resource.data.userId == request.auth.uid`.
